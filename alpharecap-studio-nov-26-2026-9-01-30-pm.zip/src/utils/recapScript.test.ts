import test from 'node:test';
import assert from 'node:assert/strict';
import { buildFullRecapBeats, computeLockedVideoRecapSchedule, computeVoiceSyncedVideoRecapSchedule } from './audioSync';
import {
  auditRecapCharacterConsistency,
  buildCharacterRegistry,
  buildRecapAutoExpansionPrompt,
  buildRecapCharacterConsistencyPrompt,
  buildRecapDurationAdjustmentPrompt,
  buildRecapMixedNarrationPrompt,
  buildRecapSceneMappings,
  cleanRecapSpokenText,
  countSpokenUnits,
  distributeEditedScriptAcrossBeats,
  estimateMyanmarTextDurationSeconds,
  estimateRecapNarrationCoverage,
  extractVerifiedCharacterClues,
  findBannedGenericCharacterLabels,
  formatCharacterRegistryPromptBlock,
  formatTimestampedTranscriptContext,
  isBannedGenericCharacterLabel,
  selectRecapBeatsForAutoExpansion,
  STRICT_RECAP_SCENE_MATCH_THRESHOLD,
  validateAndRefineRecapSegments,
  validateRecapQuality,
} from './recapScript';

test('buildRecapMixedNarrationPrompt enforces MIXED narration+dialogue, TARGET_WORDS (not MAX_WORDS), timestamped transcript, and 90% duration', () => {
  const timestampedSegments = [
    { start: 1.2, end: 4.5, text: 'Where did you hide the ledger?' },
    { start: 4.8, end: 8.4, text: 'If you step closer, nobody leaves alive!' },
    { start: 4.8, end: 8.4, text: 'If you step closer, nobody leaves alive!' }, // duplicate echo
  ];

  const { systemInstruction, prompt, targetDurationSeconds } = buildRecapMixedNarrationPrompt({
    durationSeconds: 60,
    transcript: 'Where did you hide the ledger? If you step closer, nobody leaves alive!',
    timestampedSegments,
    voiceStyleName: 'Street Bro',
    voiceStyleTag: 'Natural',
    voiceStyleDesc: 'Conversational',
    speedNote: 'Use TARGET_WORDS per beat.',
    beatListText: '- Beat id="beat_1" [0.00s -> 30.00s, TARGET_WORDS=65]: "Warehouse confrontation"',
    beatCount: 1,
    scenes: [
      {
        index: 0,
        timestamp: 2.0,
        imageUrl: '/api/session/s1/file/scene_000.jpg',
        descriptionMy: 'ဂိုဒေါင်ထဲမှာ လူနှစ်ယောက် ထိပ်တိုက်တွေ့နေကြသည်',
      },
    ],
    storyAnalysisMy: 'စာရင်းစာအုပ်လုယူမှုနှင့် ခြိမ်းခြောက်ခန်း',
  });

  assert.equal(targetDurationSeconds, 54);
  assert.ok(systemInstruction.includes('MIXED'));
  assert.ok(systemInstruction.includes('TARGET_WORDS'));
  assert.ok(prompt.includes('54.00 seconds (~90%'));
  assert.ok(prompt.includes('[00:01.20 -> 00:04.50] "Where did you hide the ledger?"'));
  assert.ok(prompt.includes('[00:04.80 -> 00:08.40] "If you step closer, nobody leaves alive!"'));
  assert.equal(prompt.includes('MAX_WORDS'), false);
  assert.ok(prompt.includes('DO NOT invent'));
  assert.ok(prompt.includes('Never copy or reuse phrasing from prompt instructions'));
});

test('formatTimestampedTranscriptContext deduplicates consecutive echoes and sorts chronologically', () => {
  const formatted = formatTimestampedTranscriptContext(
    [
      { start: 6.0, end: 8.0, text: 'Second line' },
      { start: 1.0, end: 3.0, text: 'First line' },
      { start: 1.5, end: 3.5, text: 'First line' },
    ],
    10
  );
  const lines = formatted.split('\n');
  assert.equal(lines.length, 2);
  assert.ok(lines[0].startsWith('[00:01.00 -> 00:03.50] "First line"'));
  assert.ok(lines[1].startsWith('[00:06.00 -> 00:08.00] "Second line"'));
});

test('countSpokenUnits & estimateMyanmarTextDurationSeconds count Burmese syllables accurately including conjuncts and speed', () => {
  const units = countSpokenUnits('မိုးရွာနေတဲ့ တံတားပေါ်မှာ စုံထောက်ကြီး သတ္တိရှိရှိ စောင့်နေတယ်။');
  assert.ok(units.myanmarSyllables >= 19 && units.myanmarSyllables <= 23);

  const normal = estimateMyanmarTextDurationSeconds(
    'စုံထောက်ကြီးက တရားခံကို မေးခွန်းထုတ်လိုက်ပြီး အမှန်တရားကို ဖော်ထုတ်ဖို့ ကြိုးစားနေပါတယ်။',
    'normal'
  );
  const fast = estimateMyanmarTextDurationSeconds(
    'စုံထောက်ကြီးက တရားခံကို မေးခွန်းထုတ်လိုက်ပြီး အမှန်တရားကို ဖော်ထုတ်ဖို့ ကြိုးစားနေပါတယ်။',
    'fast'
  );
  const slow = estimateMyanmarTextDurationSeconds(
    'စုံထောက်ကြီးက တရားခံကို မေးခွန်းထုတ်လိုက်ပြီး အမှန်တရားကို ဖော်ထုတ်ဖို့ ကြိုးစားနေပါတယ်။',
    'slow'
  );

  assert.ok(normal.estimatedSeconds > 3.5);
  assert.ok(fast.estimatedSeconds < normal.estimatedSeconds);
  assert.ok(slow.estimatedSeconds > normal.estimatedSeconds);
});

test('selectRecapBeatsForAutoExpansion targets ONLY underfilled beats with transcript/scene evidence and never invents when evidence is absent', () => {
  const rawSegments = [
    { start: 0.5, end: 5.5, text: 'Where did you hide the key? Tell me now!' },
    { start: 6.5, end: 11.5, text: 'If you open that door, the whole building explodes!' },
  ];
  const beats = buildFullRecapBeats(rawSegments, 24, 'normal');
  assert.ok(beats.length >= 4);

  // Make beat_1 richly detailed, leave remaining beats super short/underfilled
  const sparseSegments = beats.map((b, idx) => ({
    id: b.id,
    myanmarText:
      idx === 0
        ? "အခန်းထဲဝင်လာတဲ့ စုံထောက်က တရားခံကို စူးစိုက်ကြည့်ပြီး 'သော့ကို ဘယ်မှာဖွက်ထားလဲ အခုပြောစမ်း' လို့ ဒေါသတကြီး မေးလိုက်ပါတယ်။"
        : 'ဆက်ပြောတယ်။',
    emoji: '🎬',
  }));

  const expansion = selectRecapBeatsForAutoExpansion({
    beats,
    segments: sparseSegments,
    videoDurationSeconds: 24,
    voiceSpeed: 'normal',
    timestampedSegments: rawSegments,
    transcript: rawSegments.map((s) => s.text).join(' '),
  });

  assert.equal(expansion.shouldExpand, true);
  assert.ok(expansion.estimate.coverageRatio < 0.78);
  // beat_1 is already full, so it must NOT be selected for expansion
  assert.equal(
    expansion.candidates.some((c) => c.beat.id === 'beat_1'),
    false
  );
  assert.ok(expansion.candidates.length >= 1);

  const expandPrompt = buildRecapAutoExpansionPrompt({
    durationSeconds: 24,
    targetDurationSeconds: expansion.estimate.targetDurationSeconds,
    currentEstimatedSeconds: expansion.estimate.estimatedDurationSeconds,
    candidates: expansion.candidates,
  });
  assert.ok(expandPrompt.prompt.includes('DO NOT repeat its content'));
  assert.ok(expandPrompt.prompt.includes('NEVER fabricate dialogue'));

  // Without transcript or visual scenes, auto-expansion MUST NOT invent content
  const noEvidenceBeats = buildFullRecapBeats([], 24, 'normal');
  const noEvidenceExpansion = selectRecapBeatsForAutoExpansion({
    beats: noEvidenceBeats,
    segments: noEvidenceBeats.map((b) => ({ id: b.id, myanmarText: 'တိုတို', emoji: '🎬' })),
    videoDurationSeconds: 24,
    voiceSpeed: 'normal',
    timestampedSegments: [],
    scenes: [],
    transcript: '',
  });
  assert.equal(noEvidenceExpansion.shouldExpand, false);
  assert.equal(noEvidenceExpansion.candidates.length, 0);
});

test('validateAndRefineRecapSegments cleans labels, deduplicates repeated dialogue, and tracks coverage & quotes', () => {
  const beats = buildFullRecapBeats(
    [
      { start: 0.5, end: 5.0, text: 'Who sent you here?' },
      { start: 5.5, end: 11.5, text: 'You cannot stop what is coming.' },
    ],
    12,
    'normal'
  );

  assert.equal(
    cleanRecapSpokenText("Narration: ကောင်လေးက ဝင်လာပြီး Dialogue: 'မင်းဘာလို့လာတာလဲ' လို့မေးတယ်။"),
    "ကောင်လေးက ဝင်လာပြီး 'မင်းဘာလို့လာတာလဲ' လို့မေးတယ်။"
  );

  const repeatedClause = "သူက 'မင်းဒီကနေ ထွက်ပြေးလို့ မလွတ်ဘူး' လို့ ခြိမ်းခြောက်လိုက်တယ်။";
  const validation = validateAndRefineRecapSegments({
    beats,
    rawSegments: beats.map((b, idx) => ({
      id: b.id,
      myanmarText:
        idx === 0
          ? `Narration: အစပိုင်းမှာတော့ သူတို့နှစ်ယောက် ထိပ်တိုက်တွေ့ကြတယ်။ ${repeatedClause}`
          : idx === 1
            ? `${repeatedClause} နောက်တော့ သူလည်း ကြောက်လန့်ပြီး နောက်ဆုတ်သွားခဲ့တယ်။`
            : 'နောက်ဆုံးမှာတော့ အမှန်တရားတစ်ခုလုံး ပေါ်ပေါက်သွားပါတော့တယ်။',
      emoji: '🔥',
    })),
    videoDurationSeconds: 12,
    voiceSpeed: 'normal',
  });

  assert.equal(validation.segments.length, beats.length);
  assert.equal(validation.removedDuplicateCount, 1);
  assert.equal(validation.dialogueLineCount, 1);
  assert.equal(validation.segments[0].myanmarText.includes('Narration:'), false);
  assert.equal(validation.segments[1].myanmarText.includes('မင်းဒီကနေ ထွက်ပြေးလို့ မလွတ်ဘူး'), false);

  const coverage = estimateRecapNarrationCoverage(beats, validation.segments, 12, 'normal');
  assert.equal(coverage.targetDurationSeconds, 10.8);
  assert.ok(coverage.estimatedDurationSeconds > 4);
});

test('extractVerifiedCharacterClues identifies speaker turns, titles/ranks, and vocatives while filtering non-names', () => {
  const clues = extractVerifiedCharacterClues({
    transcript: [
      'Detective Miller: Where did you hide the ledger, Marcus?',
      'Marcus: Wait, please! Ask Dr. Chen if you do not believe me.',
      'Elena: Run, Marcus!',
    ].join('\n'),
    timestampedSegments: [
      { start: 0.5, end: 4.0, text: 'Detective Miller: Where did you hide the ledger, Marcus?' },
      { start: 4.2, end: 8.5, text: 'Marcus: Wait, please! Ask Dr. Chen if you do not believe me.' },
    ],
  });

  const names = clues.map((c) => c.canonicalName);
  assert.ok(names.includes('Detective Miller'));
  assert.ok(names.includes('Marcus'));
  assert.ok(names.includes('Dr. Chen'));
  assert.ok(names.includes('Elena'));
  assert.equal(names.some((n) => /^(Wait|Please|Run|Ask)$/i.test(n)), false);

  // When no character names exist in transcript/scenes, return empty roster (never invent)
  const emptyClues = extractVerifiedCharacterClues({
    transcript: 'Someone walks down the street at night without saying any names.',
  });
  assert.equal(emptyClues.length, 0);
});

test('auditRecapCharacterConsistency & prompts enforce real names over generic pronouns and trigger pre-final check only when needed', () => {
  const timestampedSegments = [
    { start: 0.5, end: 5.0, text: 'Captain Park: Stay back, Mina!' },
    { start: 5.5, end: 11.0, text: 'Mina: Captain Park, the vault is already open!' },
  ];
  const verifiedCharacters = extractVerifiedCharacterClues({ timestampedSegments });
  const beats = buildFullRecapBeats(timestampedSegments, 12, 'normal');

  const promptBundle = buildRecapMixedNarrationPrompt({
    durationSeconds: 12,
    transcript: timestampedSegments.map((s) => s.text).join(' '),
    timestampedSegments,
    voiceStyleName: 'Street Bro',
    voiceStyleTag: 'Natural',
    voiceStyleDesc: 'Conversational',
    speedNote: 'Use TARGET_WORDS',
    beatListText: beats.map((b) => `- Beat id="${b.id}"`).join('\n'),
    beatCount: beats.length,
    verifiedCharacters,
  });

  assert.ok(promptBundle.prompt.includes('Captain Park'));
  assert.ok(promptBundle.prompt.includes('Mina'));
  assert.ok(promptBundle.prompt.includes('CHARACTER NAME & IDENTITY CONSISTENCY'));
  assert.ok(promptBundle.prompt.includes('ရဲအရာရှိ'));

  // Draft relying heavily on generic pronouns & missing Mina triggers consistency pass
  const pronounHeavyDraft = [
    { id: beats[0].id, myanmarText: 'သူက အဲဒီလူကို ကြည့်ပြီး သူမကို နောက်ဆုတ်ဖို့ ပြောလိုက်တယ်။', emoji: '🎬' },
    { id: beats[1].id, myanmarText: 'သူမက သူ့ကို ကြည့်ပြီး တံခါးပွင့်နေပြီလို့ ပြန်ပြောတယ်။', emoji: '😱' },
    { id: beats[2].id, myanmarText: 'သူတို့နှစ်ယောက် အထဲကို ပြေးဝင်သွားကြတယ်။', emoji: '🔥' },
  ];
  const badAudit = auditRecapCharacterConsistency(pronounHeavyDraft, verifiedCharacters);
  assert.equal(badAudit.needsConsistencyPass, true);
  assert.ok(badAudit.missedKnownNames.includes('Captain Park'));
  assert.ok(badAudit.missedKnownNames.includes('Mina'));

  const consistencyPrompt = buildRecapCharacterConsistencyPrompt({
    beats,
    segments: pronounHeavyDraft,
    verifiedCharacters,
    audit: badAudit,
    timestampedSegments,
  });
  assert.ok(consistencyPrompt.prompt.includes('Captain Park'));
  assert.ok(consistencyPrompt.prompt.includes('Mina'));

  // Once names are consistently preserved across beats, consistency pass is not needed
  const cleanDraft = [
    { id: beats[0].id, myanmarText: "Captain Park က Mina ကို 'နောက်ဆုတ်နေပါ' လို့ သတိပေးလိုက်တယ်။", emoji: '🎬' },
    { id: beats[1].id, myanmarText: "Mina က Captain Park ကို 'ဘဏ်တိုက်တံခါးက ပွင့်နေပြီ' လို့ ထိတ်လန့်တကြီး ပြန်ပြောတယ်။", emoji: '😱' },
    { id: beats[2].id, myanmarText: 'Captain Park နဲ့ Mina တို့ အထဲကို သတိကြီးကြီးနဲ့ ဝင်သွားကြတယ်။', emoji: '🔥' },
  ];
  const cleanAudit = auditRecapCharacterConsistency(cleanDraft, verifiedCharacters);
  assert.equal(cleanAudit.needsConsistencyPass, false);
  assert.equal(cleanAudit.missedKnownNames.length, 0);
});

test('buildRecapMixedNarrationPrompt enforces 9 narrative stages, FULL ENDING, and AI Voice-Synced scene-to-voice parity', () => {
  const { systemInstruction, prompt } = buildRecapMixedNarrationPrompt({
    durationSeconds: 173,
    transcript: 'Captain Park: "Hold the gate!"',
    timestampedSegments: [{ start: 1.0, end: 5.0, text: 'Captain Park: Hold the gate!' }],
    voiceStyleName: 'Street Bro',
    voiceStyleTag: 'Natural',
    voiceStyleDesc: 'Conversational',
    speedNote: 'Natural pacing',
    beatListText: '- Beat id="beat_1" (scene_1) [0.00s -> 15.00s, STAGE=1. Opening Hook, TARGET_WORDS=34]: "Gate tension"',
    beatCount: 1,
    scenes: [
      {
        index: 0,
        sceneId: 'scene_1',
        timestamp: 2.0,
        startTime: 0,
        endTime: 15,
        characters: ['Captain Park'],
        actions: ['Guards the vault'],
        dialogueRef: 'Hold the gate!',
        storyEvent: 'Captain Park defends the vault entrance.',
        imageUrl: '/scene_000.jpg',
        descriptionMy: 'Captain Park က တံခါးဝကို စောင့်ကြပ်နေသည်။',
      },
    ],
  });

  assert.ok(systemInstruction.includes('AI Voice-Synced, NOT 1.0x locked'));
  assert.ok(prompt.includes('Recap Style = DETAILED | Ending Style = FULL ENDING'));
  assert.ok(prompt.includes('1. Opening Hook'));
  assert.ok(prompt.includes('9. Full Ending and Resolution'));
  assert.ok(prompt.includes('Video Speed = AI Voice-Synced per scene'));
  assert.ok(prompt.includes('SCENE-TO-VOICE CONTENT PARITY'));
  assert.ok(prompt.includes('155.70 seconds'));
  assert.ok(prompt.includes('[scene_1 | 00:00.00 -> 00:15.00]'));
});

test('distributeEditedScriptAcrossBeats, buildRecapSceneMappings, buildRecapDurationAdjustmentPrompt, and validateRecapQuality support dynamic voice-synced speeds while blocking silence cuts', () => {
  const scenes = Array.from({ length: 12 }, (_, idx) => ({
    index: idx,
    sceneId: `scene_${idx + 1}`,
    timestamp: idx * 14 + 3,
    startTime: Number(((idx * 173) / 12).toFixed(2)),
    endTime: Number((((idx + 1) * 173) / 12).toFixed(2)),
    imageUrl: `/scene_${idx}.jpg`,
    characters: ['Captain Park', 'Mina'],
    storyEvent: `အခန်း ${idx + 1} ဖြစ်စဉ်`,
    descriptionMy: `Captain Park နဲ့ Mina အခန်း ${idx + 1} မှာ လှုပ်ရှားနေကြတယ်။`,
  }));

  const timestamped = [
    { start: 3, end: 9, text: 'Captain Park: Mina, stay behind me!' },
    { start: 158, end: 170, text: 'Mina: Captain Park, everything is finally over.' },
  ];
  const beats = buildFullRecapBeats(timestamped, 173, 'normal', { scenes, maxBeats: 24 });
  assert.equal(beats.length, 12);

  // Manual script edit across multiple Burmese sentences preserves all 12 scene windows
  const manualEditedScript = beats
    .map(
      (_, i) =>
        i === 0
          ? "Captain Park က Mina ကို 'နောက်မှာနေပါ' လို့ သတိပေးရင်း အမှုကို စတင်စစ်ဆေးနေတယ်။"
          : `Captain Park နဲ့ Mina တို့ အခန်း (${i + 1}) ထဲက သဲလွန်စကို အတူတကွ ဆက်လက်ဖော်ထုတ်နေကြတယ်။`
    )
    .join(' ');

  const distributed = distributeEditedScriptAcrossBeats(manualEditedScript, beats);
  assert.equal(distributed.length, 12);
  assert.ok(distributed[0].myanmarText.includes('Captain Park'));

  // Test longer narration (e.g. 210s narration > 173s video) -> slower playback (~0.82x) MUST PASS validation cleanly!
  const rawDurs: Record<string, number> = {};
  const textsById: Record<string, string> = {};
  beats.forEach((b, i) => {
    rawDurs[b.id] = 17.5;
    textsById[b.id] = distributed[i].myanmarText;
  });

  const schedule = computeLockedVideoRecapSchedule(beats, rawDurs, 173, { textsById });
  assert.ok(schedule.totalOutputDuration > 173);
  assert.ok(schedule.videoPlaybackRate < 1.0);

  const mappings = buildRecapSceneMappings({
    beats,
    segments: distributed,
    scenes,
    verifiedCharacters: [
      { canonicalName: 'Captain Park', aliases: [], roleOrRelation: 'Captain', evidenceSource: 'transcript' },
      { canonicalName: 'Mina', aliases: [], roleOrRelation: '', evidenceSource: 'transcript' },
    ],
    schedule,
  });

  assert.equal(mappings.length, 12);
  assert.equal(mappings[0].sceneId, 'scene_1');
  assert.equal(mappings[0].storyStage, 'opening_hook');
  assert.ok(mappings[0].dialogueText?.includes('နောက်မှာနေပါ'));
  assert.ok(typeof mappings[0].videoPlaybackRate === 'number' && mappings[0].videoPlaybackRate < 1.0);
  assert.equal(mappings[11].sceneId, 'scene_12');
  assert.equal(mappings[11].storyStage, 'full_ending');

  const validGate = validateRecapQuality({
    beats,
    segments: distributed,
    mappings,
    originalVideoDuration: 173,
    actualTtsDuration: schedule.actualFittedTtsDuration,
    videoPlaybackRate: schedule.videoPlaybackRate,
    silenceCutApplied: false,
    verifiedCharacters: [
      { canonicalName: 'Captain Park', aliases: [], roleOrRelation: 'Captain', evidenceSource: 'transcript' },
      { canonicalName: 'Mina', aliases: [], roleOrRelation: '', evidenceSource: 'transcript' },
    ],
    timestampedSegments: timestamped,
    hasTtsAudio: true,
  });

  assert.equal(validGate.canRender, true);
  assert.equal(validGate.passed, true);
  assert.equal(validGate.videoSpeedLocked, schedule.videoPlaybackRate);
  assert.equal(validGate.fullEndingCovered, true);

  // Critical block: if silenceCutApplied is true -> canRender MUST be false!
  const blockedSilenceGate = validateRecapQuality({
    beats,
    segments: distributed,
    mappings,
    originalVideoDuration: 173,
    actualTtsDuration: schedule.actualFittedTtsDuration,
    videoPlaybackRate: schedule.videoPlaybackRate,
    silenceCutApplied: true,
    hasTtsAudio: true,
  });
  assert.equal(blockedSilenceGate.canRender, false);
  assert.ok(blockedSilenceGate.criticalErrors.some((e) => e.includes('Silence Cut')));

  // Actual duration adjustment prompt includes measured seconds + expand/tighten instruction
  const adjPrompt = buildRecapDurationAdjustmentPrompt({
    durationSeconds: 173,
    actualTotalTtsSeconds: 98.4,
    targetTotalTtsSeconds: 155.7,
    targets: [
      {
        beat: beats[0],
        mode: 'expand',
        currentText: distributed[0].myanmarText,
        currentEmoji: '🎬',
        actualTtsSeconds: 3.1,
        targetTtsSeconds: 12.9,
        maxWindowSeconds: 14.4,
        matchingTranscriptLines: ['[00:03 -> 00:09] "Captain Park: Mina, stay behind me!"'],
        matchingSceneNotes: ['[00:03] Captain Park checks the gate.'],
        previousBeatText: '',
        nextBeatText: distributed[1].myanmarText,
      },
    ],
  });
  assert.ok(adjPrompt.prompt.includes('98.40s'));
  assert.ok(adjPrompt.prompt.includes('155.70s'));
  assert.ok(adjPrompt.prompt.includes('EXPAND'));
});

test('extractVerifiedCharacterClues extracts multi-word, titled, hyphenated, apostrophe, self-intro, and Burmese full names while keeping siblings distinct', () => {
  const clues = extractVerifiedCharacterClues({
    transcript: [
      'Ethan: Who are you?',
      "My name is Sarah Connor and this is Kim Min-joon.",
      "Detective John Miller: Stay back, Liam O'Connor!",
      'Sarah Miller: Leave John Miller alone!',
      'Ethan Hunt: Let us move now.',
    ].join('\n'),
    scenes: [
      {
        index: 0,
        timestamp: 2.0,
        imageUrl: '/scene_000.jpg',
        descriptionMy: 'မောင်ကျော်ဇေယျ နဲ့ Ethan Hunt တို့ အခန်းထဲဝင်လာကြသည်။',
        characters: ['ကောင်လေး (Ethan)', 'မောင်ကျော်ဇေယျ', 'ရဲအရာရှိ'],
      },
      {
        index: 1,
        timestamp: 8.0,
        imageUrl: '/scene_001.jpg',
        descriptionMy: 'ဦးသိန်းအောင် က စာရွက်စာတမ်းတွေ စစ်ဆေးနေသည်။',
        characters: ['ဦးသိန်းအောင်', 'ကျော်ဇေယျ'],
      },
    ],
  });

  const names = clues.map((c) => c.canonicalName);
  assert.ok(names.includes('Ethan Hunt'), `Expected Ethan Hunt in ${JSON.stringify(names)}`);
  assert.ok(names.includes('Sarah Connor'), `Expected Sarah Connor in ${JSON.stringify(names)}`);
  assert.ok(names.includes('Kim Min-joon'), `Expected Kim Min-joon in ${JSON.stringify(names)}`);
  assert.ok(names.includes("Liam O'Connor"), `Expected Liam O'Connor in ${JSON.stringify(names)}`);
  assert.ok(names.includes('Detective John Miller'), `Expected Detective John Miller in ${JSON.stringify(names)}`);
  assert.ok(names.includes('Sarah Miller'), `Expected Sarah Miller in ${JSON.stringify(names)}`);
  assert.ok(names.includes('မောင်ကျော်ဇေယျ'), `Expected မောင်ကျော်ဇေယျ in ${JSON.stringify(names)}`);
  assert.ok(names.includes('ဦးသိန်းအောင်'), `Expected ဦးသိန်းအောင် in ${JSON.stringify(names)}`);

  // Partial references consolidated cleanly into full canonical names without duplicating as separate entries
  assert.equal(names.includes('Ethan'), false);
  assert.equal(names.includes('ကျော်ဇေယျ'), false);
  assert.equal(names.includes('John Miller'), false);
  // Generic roles must not pollute verified proper character names
  assert.equal(names.includes('ရဲအရာရှိ'), false);
  assert.equal(names.includes('ကောင်လေး'), false);

  // Siblings sharing surname "Miller" remain distinct and never get merged together
  const johnProfile = clues.find((c) => c.canonicalName === 'Detective John Miller');
  const sarahProfile = clues.find((c) => c.canonicalName === 'Sarah Miller');
  assert.ok(johnProfile && sarahProfile);
  assert.equal(johnProfile.aliases.includes('Miller'), false);
  assert.equal(sarahProfile.aliases.includes('Miller'), false);
});

test('auditRecapCharacterConsistency flags truncated first-name-only mentions via missedFullNames and accepts complete full names', () => {
  const verifiedCharacters = extractVerifiedCharacterClues({
    transcript: [
      'My name is Sarah Connor.',
      'Detective John Miller: Keep your eyes on the exit, Sarah!',
    ].join('\n'),
  });

  const beats = buildFullRecapBeats(
    [
      { start: 0.5, end: 5.0, text: 'My name is Sarah Connor.' },
      { start: 5.5, end: 11.5, text: 'Detective John Miller: Keep your eyes on the exit, Sarah!' },
    ],
    12,
    'normal'
  );

  // Uses truncated "John" and "Sarah" instead of "Detective John Miller" and "Sarah Connor"
  const truncatedDraft = [
    { id: beats[0].id, myanmarText: 'Sarah က အခန်းထဲကို ဝင်လာပြီး စတင်စစ်ဆေးနေတယ်။', emoji: '🎬' },
    { id: beats[1].id, myanmarText: 'John က Sarah ကို ထွက်ပေါက်ကို စောင့်ကြည့်ဖို့ ပြောလိုက်တယ်။', emoji: '🔥' },
    { id: beats[2].id, myanmarText: 'ကောင်လေး နဲ့ ကောင်မလေး တို့ ဆက်ပြီး ထွက်ပြေးသွားကြတယ်။', emoji: '😱' },
  ];

  const truncatedAudit = auditRecapCharacterConsistency(truncatedDraft, verifiedCharacters);
  assert.equal(truncatedAudit.needsConsistencyPass, true);
  assert.ok(truncatedAudit.missedFullNames.includes('Detective John Miller'));
  assert.ok(truncatedAudit.missedFullNames.includes('Sarah Connor'));

  // Using complete full names passes cleanly
  const fullDraft = [
    { id: beats[0].id, myanmarText: 'Sarah Connor က အခန်းထဲကို ဝင်လာပြီး စတင်စစ်ဆေးနေတယ်။', emoji: '🎬' },
    { id: beats[1].id, myanmarText: "Detective John Miller က Sarah Connor ကို 'ထွက်ပေါက်ကို စောင့်ကြည့်ထားပါ' လို့ သတိပေးလိုက်တယ်။", emoji: '🔥' },
    { id: beats[2].id, myanmarText: 'Detective John Miller နဲ့ Sarah Connor တို့ အတူတကွ အမှုကို ဖြေရှင်းနိုင်ခဲ့ကြတယ်။', emoji: '✨' },
  ];

  const fullAudit = auditRecapCharacterConsistency(fullDraft, verifiedCharacters);
  assert.equal(fullAudit.missedFullNames.length, 0);
  assert.equal(fullAudit.needsConsistencyPass, false);
});

test('buildRecapSceneMappings applies strict character visual-presence threshold so audio narration selects only matching scenes and syncs schedule slots', () => {
  const scenes = [
    {
      index: 0,
      sceneId: 'scene_1',
      timestamp: 3,
      startTime: 0,
      endTime: 10,
      imageUrl: '/s1.jpg',
      characters: ['Ethan Hunt'],
      storyEvent: 'Ethan Hunt enters the hallway alone.',
      descriptionMy: 'Ethan Hunt တစ်ယောက်တည်း စင်္ကြံထဲ ဝင်လာသည်။',
    },
    {
      index: 1,
      sceneId: 'scene_2',
      timestamp: 14,
      startTime: 10,
      endTime: 20,
      imageUrl: '/s2.jpg',
      characters: ['Sarah Miller'],
      storyEvent: 'Sarah Miller inspects the vault blueprint.',
      descriptionMy: 'Sarah Miller က မီးခံသေတ္တာ မြေပုံကို စစ်ဆေးနေသည်။',
    },
    {
      index: 2,
      sceneId: 'scene_3',
      timestamp: 24,
      startTime: 20,
      endTime: 30,
      imageUrl: '/s3.jpg',
      characters: ['John Miller'],
      storyEvent: 'John Miller guards the north exit.',
      descriptionMy: 'John Miller က မြောက်ဘက်ထွက်ပေါက်ကို စောင့်ကြပ်နေသည်။',
    },
    {
      index: 3,
      sceneId: 'scene_4',
      timestamp: 35,
      startTime: 30,
      endTime: 40,
      imageUrl: '/s4.jpg',
      characters: ['Ethan Hunt', 'Sarah Miller'],
      storyEvent: 'Ethan Hunt and Sarah Miller meet at the safe.',
      descriptionMy: 'Ethan Hunt နဲ့ Sarah Miller တို့ မီးခံသေတ္တာရှေ့မှာ ဆုံကြသည်။',
    },
  ];

  const verifiedCharacters = [
    { canonicalName: 'Ethan Hunt', aliases: ['Ethan'], evidenceSource: 'transcript' as const },
    { canonicalName: 'Sarah Miller', aliases: ['Sarah'], evidenceSource: 'transcript' as const },
    { canonicalName: 'John Miller', aliases: ['John'], evidenceSource: 'transcript' as const },
    { canonicalName: 'Captain Vance', aliases: ['Vance'], evidenceSource: 'transcript' as const },
  ];

  const customBeats = [
    // Beat 1 spans [0..20] overlapping scene_1 (Ethan) and scene_2 (Sarah), narrating ONLY Sarah Miller
    {
      id: 'beat_1',
      sceneId: 'scene_1+scene_2',
      start: 0,
      end: 20,
      duration: 20,
      contextText: 'Sarah Miller checks blueprint',
      characters: ['Ethan Hunt', 'Sarah Miller'],
      maxMyanmarWords: 40,
    },
    // Beat 2 is anchored to scene_1 window [0..10], but audio actually narrates John Miller (only visible in scene_3 [20..30])
    {
      id: 'beat_2',
      sceneId: 'scene_1',
      start: 0,
      end: 10,
      duration: 10,
      contextText: 'John Miller guards exit',
      characters: ['Ethan Hunt'],
      maxMyanmarWords: 20,
    },
    // Beat 3 narrates both Ethan Hunt and Sarah Miller -> prefers scene_4 [30..40] where BOTH are visually present
    {
      id: 'beat_3',
      sceneId: 'scene_4',
      start: 30,
      end: 40,
      duration: 10,
      contextText: 'Both meet at the safe',
      maxMyanmarWords: 25,
    },
    // Beat 4 narrates Captain Vance who never appears visually in any scene -> temporal_fallback without stealing scene_3 characters
    {
      id: 'beat_4',
      sceneId: 'scene_3',
      start: 20,
      end: 30,
      duration: 10,
      contextText: 'Captain Vance radio message',
      maxMyanmarWords: 20,
    },
  ];

  const segs = [
    { id: 'beat_1', myanmarText: 'Sarah Miller က မြေပုံကို သေချာကြည့်ပြီး အဖြေရှာနေပါတယ်။', emoji: '🔍' },
    { id: 'beat_2', myanmarText: 'John Miller က ထွက်ပေါက်နားမှာ အသင့်စောင့်နေပါတယ်။', emoji: '🛡️' },
    { id: 'beat_3', myanmarText: 'Ethan Hunt နဲ့ Sarah Miller တို့ အတူတကွ မီးခံသေတ္တာကို ဖွင့်လိုက်ကြတယ်။', emoji: '🔥' },
    { id: 'beat_4', myanmarText: 'Captain Vance က ရေဒီယိုကနေ အမိန့်ပေးလိုက်ပါတယ်။', emoji: '📻' },
  ];

  const mappings = buildRecapSceneMappings({
    beats: customBeats,
    segments: segs,
    scenes,
    verifiedCharacters,
  });

  // Beat 1 excluded scene_1 (Ethan Hunt) and selected ONLY scene_2 (Sarah Miller)
  assert.equal(mappings[0].sceneId, 'scene_2');
  assert.deepEqual(mappings[0].matchedSceneIds, ['scene_2']);
  assert.equal(mappings[0].startTime, 10);
  assert.equal(mappings[0].endTime, 20);
  assert.deepEqual(mappings[0].characterRefs, ['Sarah Miller']);
  assert.equal(mappings[0].sceneMatchMode, 'character_visual_strict');
  assert.ok((mappings[0].sceneMatchConfidence ?? 0) >= STRICT_RECAP_SCENE_MATCH_THRESHOLD);

  // Beat 2 re-prioritized away from scene_1 (Ethan) to scene_3 (John Miller), never conflating Sarah Miller
  assert.equal(mappings[1].sceneId, 'scene_3');
  assert.deepEqual(mappings[1].matchedSceneIds, ['scene_3']);
  assert.equal(mappings[1].startTime, 20);
  assert.equal(mappings[1].endTime, 30);
  assert.deepEqual(mappings[1].characterRefs, ['John Miller']);
  assert.equal(mappings[1].sceneMatchMode, 'character_visual_strict');

  // Beat 3 selected scene_4 where BOTH Ethan Hunt and Sarah Miller are visually present
  assert.equal(mappings[2].sceneId, 'scene_4');
  assert.equal(mappings[2].sceneMatchMode, 'character_visual_strict');
  assert.ok((mappings[2].sceneMatchConfidence ?? 0) >= 0.9);

  // Beat 4 fell back cleanly without falsely attributing John Miller to Captain Vance's narration
  assert.equal(mappings[3].sceneMatchMode, 'temporal_fallback');
  assert.equal(mappings[3].sceneMatchConfidence, 0);
  assert.deepEqual(mappings[3].characterRefs, ['Captain Vance']);

  // Downstream schedule aligns FFmpeg video slots directly with strict character-matched scene windows
  const schedule = computeVoiceSyncedVideoRecapSchedule(
    customBeats,
    { beat_1: 8.5, beat_2: 7.0, beat_3: 8.0, beat_4: 6.0 },
    40,
    { sceneMappings: mappings }
  );
  assert.equal(schedule.slots[0].sceneId, 'scene_2');
  assert.equal(schedule.slots[0].sceneStart, 10);
  assert.equal(schedule.slots[0].sceneEnd, 20);
  assert.equal(schedule.slots[1].sceneId, 'scene_3');
  assert.equal(schedule.slots[1].sceneStart, 20);
  assert.equal(schedule.slots[1].sceneEnd, 30);
});

test('findBannedGenericCharacterLabels & isBannedGenericCharacterLabel detect temporary labels without false positives', () => {
  assert.equal(isBannedGenericCharacterLabel('Man 1'), true);
  assert.equal(isBannedGenericCharacterLabel('Woman 2'), true);
  assert.equal(isBannedGenericCharacterLabel('Person A'), true);
  assert.equal(isBannedGenericCharacterLabel('Character 3'), true);
  assert.equal(isBannedGenericCharacterLabel('အမျိုးသား (၁)'), true);
  assert.equal(isBannedGenericCharacterLabel('အမျိုးသား ၂'), true);
  assert.equal(isBannedGenericCharacterLabel('အမျိုးသမီး (၁)'), true);
  assert.equal(isBannedGenericCharacterLabel('လူ (၁)'), true);

  // Natural Burmese descriptions & plural counts must NOT be flagged
  assert.equal(isBannedGenericCharacterLabel('အမျိုးသားတစ်ဦး'), false);
  assert.equal(isBannedGenericCharacterLabel('ဆိုင်ရှင်'), false);
  assert.equal(isBannedGenericCharacterLabel('အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား'), false);

  const hits = findBannedGenericCharacterLabels(
    'အမျိုးသား (၁) သည် စားပွဲနားမှာ ရပ်နေပြီး Man 2 နှင့် Person B ကို စကားပြောနေသည်။ လူ ၂ ယောက် ထွက်သွားသည်။'
  );
  assert.ok(hits.some((h) => h.includes('အမျိုးသား (၁)')));
  assert.ok(hits.some((h) => /Man 2/i.test(h)));
  assert.ok(hits.some((h) => /Person B/i.test(h)));
  assert.equal(hits.some((h) => h.includes('လူ ၂ ယောက်')), false);
});

test('buildCharacterRegistry builds verified names, contextual designations, and visual descriptions while excluding banned labels', () => {
  const initialRegistry = buildCharacterRegistry({
    transcript: 'Detective John Miller: Stay back! Wait, where did the owner go?',
    timestampedSegments: [
      { start: 1.5, end: 4.5, text: 'Detective John Miller: Stay back!' },
      { start: 12.0, end: 15.0, text: 'Owner: Nobody takes my shop!' },
    ],
    scenes: [
      {
        index: 0,
        timestamp: 2.0,
        startTime: 0,
        endTime: 8,
        imageUrl: '/s0.jpg',
        descriptionMy: 'Detective John Miller က ဆိုင်ထဲ ဝင်လာပြီး အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား ကို မေးခွန်းမေးနေသည်။',
        characters: ['Detective John Miller', 'Man 1', 'အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား'],
        characterRegistryHints: [
          {
            nameOrRole: 'Detective John Miller',
            originalName: 'Detective John Miller',
            burmeseName: 'စုံထောက် John Miller',
            occupationOrTitle: 'Detective',
            confidence: 'high',
          },
          {
            nameOrRole: 'Man 1',
            visualDescription: 'အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား',
            confidence: 'low',
          },
        ],
      },
      {
        index: 1,
        timestamp: 13.0,
        startTime: 8,
        endTime: 18,
        imageUrl: '/s1.jpg',
        descriptionMy: 'စားသောက်ဆိုင်ပိုင်ရှင် က မီးဖိုချောင်တံခါးကို ပိတ်လိုက်သည်။',
        characters: ['စားသောက်ဆိုင်ပိုင်ရှင်', 'အမျိုးသား (၁)'],
        characterRegistryHints: [
          {
            nameOrRole: 'စားသောက်ဆိုင်ပိုင်ရှင်',
            burmeseName: 'စားသောက်ဆိုင်ပိုင်ရှင်',
            occupationOrTitle: 'စားသောက်ဆိုင်ပိုင်ရှင်',
            confidence: 'medium',
          },
        ],
      },
    ],
    videoTitle: 'Midnight Diner Mystery',
  });

  // No banned generic detection labels survive into the registry
  assert.equal(
    initialRegistry.some(
      (c) =>
        isBannedGenericCharacterLabel(c.burmeseName) ||
        isBannedGenericCharacterLabel(c.verifiedOriginalName || '')
    ),
    false
  );

  const miller = initialRegistry.find((c) => (c.verifiedOriginalName || '').includes('John Miller'));
  assert.ok(miller);
  assert.equal(miller.identificationConfidence, 'high');
  assert.equal(miller.firstAppearanceTimestamp, 1.5);
  assert.ok(miller.relatedSceneTimestamps.length >= 1);

  const brownSuitMan = initialRegistry.find(
    (c) => c.burmeseName === 'အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား' || c.visualDescription === 'အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား'
  );
  assert.ok(brownSuitMan);

  const owner = initialRegistry.find((c) => c.burmeseName === 'စားသောက်ဆိုင်ပိုင်ရှင်');
  assert.ok(owner);
  assert.equal(owner.verifiedOccupationOrTitle, 'စားသောက်ဆိုင်ပိုင်ရှင်');

  // Incremental refinement with distinct visual character must NOT merge conflicting visuals
  const refinedRegistry = buildCharacterRegistry({
    transcript: 'Detective John Miller: Check the back alley!',
    scenes: [
      {
        index: 2,
        timestamp: 21.0,
        startTime: 18,
        endTime: 25,
        imageUrl: '/s2.jpg',
        descriptionMy: 'အနီရောင်ကုတ်အင်္ကျီနဲ့ အမျိုးသမီး က လမ်းကြားထဲ ပြေးဝင်သွားသည်။',
        characters: ['အနီရောင်ကုတ်အင်္ကျီနဲ့ အမျိုးသမီး'],
      },
    ],
    existingRegistry: initialRegistry,
  });

  assert.ok(refinedRegistry.some((c) => c.burmeseName === 'အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား'));
  assert.ok(refinedRegistry.some((c) => c.burmeseName === 'အနီရောင်ကုတ်အင်္ကျီနဲ့ အမျိုးသမီး'));
  const promptBlock = formatCharacterRegistryPromptBlock(refinedRegistry);
  assert.ok(promptBlock.includes('CHARACTER REGISTRY'));
  assert.ok(promptBlock.includes('စားသောက်ဆိုင်ပိုင်ရှင်'));
});

test('auditRecapCharacterConsistency & validateRecapQuality flag banned generic labels and accept natural Burmese designations', () => {
  const registry = buildCharacterRegistry({
    transcript: 'Agent Min: Put the bag down!',
    scenes: [
      {
        index: 0,
        timestamp: 2.0,
        imageUrl: '/s0.jpg',
        descriptionMy: 'Agent Min နဲ့ ဆိုင်ရှင် တို့ စကားပြောနေကြသည်။',
        characters: ['Agent Min', 'ဆိုင်ရှင်'],
      },
    ],
  });

  const badSegments = [
    {
      id: 'beat_1',
      myanmarText: 'အမျိုးသား (၁) သည် ဆိုင်ထဲဝင်လာပြီး Man 2 ကို အော်လိုက်သည်။',
      emoji: '🎬',
    },
  ];
  const badAudit = auditRecapCharacterConsistency(badSegments, [], registry);
  assert.equal(badAudit.needsConsistencyPass, true);
  assert.ok(badAudit.bannedLabelHits.length >= 2);
  assert.deepEqual(badAudit.bannedLabelBeatIds, ['beat_1']);

  const sampleBeats = [
    {
      id: 'beat_1',
      start: 0,
      end: 11,
      duration: 11,
      contextText: 'Agent Min and shop owner talk',
      maxMyanmarWords: 20,
    },
  ];

  const badQuality = validateRecapQuality({
    beats: sampleBeats,
    segments: badSegments,
    mappings: [
      {
        beatId: 'beat_1',
        sceneId: 'scene_1',
        startTime: 0,
        endTime: 11,
        narrationStart: 0,
        narrationEnd: 9.5,
        characterRefs: ['Agent Min'],
        storyEvent: 'Agent Min and shop owner talk',
        narrationText: badSegments[0].myanmarText,
        storyStage: 'full_ending',
        alignmentStatus: 'aligned',
      },
    ],
    characterRegistry: registry,
    originalVideoDuration: 11,
    actualTtsDuration: 9.5,
  });
  assert.ok(
    badQuality.warnings.some((w) => w.includes('ယာယီဇာတ်ကောင် Label') || w.includes('အမျိုးသား (၁)'))
  );

  const goodSegments = [
    {
      id: 'beat_1',
      myanmarText: 'Agent Min က ဆိုင်ရှင် ကို မေးခွန်းမေးလိုက်ပြီး "အိတ်ကို ချလိုက်ပါ" လို့ သတိပေးလိုက်ပါတယ်။',
      emoji: '🎬',
    },
  ];
  const goodAudit = auditRecapCharacterConsistency(goodSegments, [], registry);
  assert.equal(goodAudit.bannedLabelHits.length, 0);
  assert.equal(goodAudit.needsConsistencyPass, false);

  const mixedPrompt = buildRecapMixedNarrationPrompt({
    durationSeconds: 30,
    transcript: 'Agent Min: Put the bag down!',
    voiceStyleName: 'Natural',
    voiceStyleTag: 'Drama',
    voiceStyleDesc: 'Natural Burmese',
    speedNote: 'Normal',
    beatListText: '- Beat id="beat_1" [0.00s -> 15.00s, TARGET_WORDS=30]',
    beatCount: 1,
    characterRegistry: registry,
  });
  assert.ok(mixedPrompt.prompt.includes('CHARACTER REGISTRY'));
  assert.ok(mixedPrompt.prompt.includes('STRICTLY FORBIDDEN GENERIC DETECTION LABELS'));

  const consistencyPrompt = buildRecapCharacterConsistencyPrompt({
    beats: sampleBeats,
    segments: badSegments,
    verifiedCharacters: [],
    characterRegistry: registry,
    audit: badAudit,
  });
  assert.ok(consistencyPrompt.prompt.includes('Banned generic detection labels found in draft'));
});


