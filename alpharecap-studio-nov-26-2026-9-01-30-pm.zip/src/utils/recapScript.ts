import type {
  CharacterIdentificationConfidence,
  CharacterRegistryEntry,
  RecapQualityCheckItem,
  RecapQualityValidation,
  RecapSceneMapping,
  RecapStoryStage,
  SceneSummary,
  VoiceSpeed,
} from '../types/studio';
import type { LockedVideoRecapScheduleResult, RecapBeat } from './audioSync';
import { resolveVoiceSpeedNumeric } from './audioSync';

export function computeRecapTargetDurationSeconds(videoDurationSeconds: number): number {
  const safe = Math.max(1, Number.isFinite(videoDurationSeconds) ? videoDurationSeconds : 12);
  return Number((safe * 0.9).toFixed(2));
}

export interface RecapGeneratedSegment {
  id: string;
  myanmarText: string;
  emoji: string;
}

export interface TimestampedTranscriptItem {
  start: number;
  end: number;
  text: string;
}

export interface VerifiedCharacterProfile {
  canonicalName: string;
  aliases: string[];
  roleOrRelation?: string;
  evidenceSource: 'transcript' | 'scene' | 'metadata';
}

export interface RecapMixedPromptInput {
  durationSeconds: number;
  transcript: string;
  timestampedSegments?: TimestampedTranscriptItem[];
  voiceStyleName: string;
  voiceStyleTag: string;
  voiceStyleDesc: string;
  speedNote: string;
  beatListText: string;
  beatCount: number;
  scenes?: SceneSummary[];
  storyAnalysisMy?: string;
  verifiedCharacters?: VerifiedCharacterProfile[];
  characterRegistry?: CharacterRegistryEntry[];
}

export interface RecapDurationEstimate {
  estimatedDurationSeconds: number;
  targetDurationSeconds: number;
  coverageRatio: number;
  totalSyllables: number;
  perSegment: Array<{
    id: string;
    estimatedSeconds: number;
    targetSeconds: number;
    syllables: number;
    fillRatio: number;
  }>;
}

export interface RecapExpansionCandidate {
  beat: RecapBeat;
  currentText: string;
  currentEmoji: string;
  estimatedSeconds: number;
  targetSeconds: number;
  matchingTranscriptLines: string[];
  matchingSceneNotes: string[];
  previousBeatText: string;
  nextBeatText: string;
}

export interface RecapValidationResult {
  segments: RecapGeneratedSegment[];
  estimatedDurationSeconds: number;
  targetDurationSeconds: number;
  coverageRatio: number;
  dialogueLineCount: number;
  removedDuplicateCount: number;
  warnings: string[];
}

const MYANMAR_SYLLABLES_PER_SECOND = 4.5;
const ENGLISH_WORDS_PER_SECOND = 2.4;

function formatClock(sec: number): string {
  const safe = Math.max(0, Number.isFinite(sec) ? sec : 0);
  const mins = Math.floor(safe / 60);
  const rem = safe - mins * 60;
  return `${String(mins).padStart(2, '0')}:${rem.toFixed(2).padStart(5, '0')}`;
}

/**
 * Strips non-spoken structural labels (e.g. "Narration:", "Dialogue:") and markdown clutter
 * while preserving natural Burmese prose and quoted character dialogue.
 */
export function cleanRecapSpokenText(rawText: string): string {
  return String(rawText || '')
    .replace(/^(?:\*{0,2}(?:Narration|Dialogue|Voiceover|Storyteller|Host|Scene)\s*:\*{0,2}\s*)+/gim, '')
    .replace(/(?:^|\s)\*{0,2}(?:Narration|Dialogue|Voiceover|Storyteller)\s*:\*{0,2}\s*/gi, ' ')
    .replace(/\[(?:music|applause|laughter|silence|noise|sfx|sound)\]/gi, ' ')
    .replace(/[*_`~#<>|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Counts Myanmar spoken syllables linguistically:
 * - Counts Myanmar consonants/independent vowels (U+1000..U+102A, U+103F, U+104E)
 *   excluding coda consonants with asat (U+103A) and stacked conjunct preceding virama (U+1039).
 * - Counts Myanmar digits and non-Myanmar alphanumeric words proportionally.
 */
export function countSpokenUnits(text: string): {
  myanmarSyllables: number;
  myanmarDigits: number;
  latinWords: number;
  sentencePauses: number;
} {
  const clean = cleanRecapSpokenText(text);
  if (!clean) {
    return { myanmarSyllables: 0, myanmarDigits: 0, latinWords: 0, sentencePauses: 0 };
  }

  let myanmarSyllables = 0;
  let myanmarDigits = 0;

  for (let i = 0; i < clean.length; i++) {
    const code = clean.charCodeAt(i);
    if (code >= 0x1040 && code <= 0x1049) {
      myanmarDigits += 1;
      continue;
    }
    const isBaseLetter =
      (code >= 0x1000 && code <= 0x102a) || code === 0x103f || code === 0x104e;
    if (!isBaseLetter) continue;

    const nextCode = i + 1 < clean.length ? clean.charCodeAt(i + 1) : 0;
    // Skip coda consonant killed by asat (်) or first consonant of stacked virama (္)
    if (nextCode === 0x103a || nextCode === 0x1039) {
      continue;
    }
    myanmarSyllables += 1;
  }

  const latinMatches = clean.match(/[A-Za-z0-9]+/g);
  const latinWords = latinMatches ? latinMatches.length : 0;

  const pauseMatches = clean.match(/[။!?]+|\.\s/g);
  const sentencePauses = Math.max(1, pauseMatches ? pauseMatches.length : 1);

  return { myanmarSyllables, myanmarDigits, latinWords, sentencePauses };
}

/**
 * Estimates spoken duration (seconds) for a Myanmar recap text snippet at a given VoiceSpeed.
 */
export function estimateMyanmarTextDurationSeconds(
  text: string,
  voiceSpeed: VoiceSpeed = 'normal'
): { estimatedSeconds: number; syllables: number } {
  const units = countSpokenUnits(text);
  const effectiveSyllables = units.myanmarSyllables + units.myanmarDigits * 1.4;
  if (effectiveSyllables === 0 && units.latinWords === 0) {
    return { estimatedSeconds: 0, syllables: 0 };
  }

  const baseSpeechSec =
    effectiveSyllables / MYANMAR_SYLLABLES_PER_SECOND +
    units.latinWords / ENGLISH_WORDS_PER_SECOND;
  const pauseSec = Math.min(2.5, units.sentencePauses * 0.22);
  const speedFactor = Math.max(0.5, resolveVoiceSpeedNumeric(voiceSpeed));

  const estimatedSeconds = Number(((baseSpeechSec + pauseSec) / speedFactor).toFixed(2));
  return {
    estimatedSeconds,
    syllables: Math.round(effectiveSyllables + units.latinWords * 2),
  };
}

/**
 * Evaluates how close generated recap segments come to the 90% target duration
 * (SOURCE VIDEO DURATION * 0.90), broken down per beat.
 */
export function estimateRecapNarrationCoverage(
  beats: RecapBeat[],
  segments: RecapGeneratedSegment[],
  videoDurationSeconds: number,
  voiceSpeed: VoiceSpeed = 'normal'
): RecapDurationEstimate {
  const safeVideoDur = Math.max(1, Number.isFinite(videoDurationSeconds) ? videoDurationSeconds : 12);
  const targetDurationSeconds = computeRecapTargetDurationSeconds(safeVideoDur);
  const segById = new Map(segments.map((s) => [s.id, s]));

  let totalEst = 0;
  let totalSyllables = 0;

  const perSegment = beats.map((beat, idx) => {
    const seg = segById.get(beat.id) || segments[idx];
    const text = seg?.myanmarText || '';
    const { estimatedSeconds, syllables } = estimateMyanmarTextDurationSeconds(text, voiceSpeed);
    const beatTargetSec = Number((beat.duration * 0.9).toFixed(2));
    totalEst += estimatedSeconds;
    totalSyllables += syllables;
    const fillRatio = beatTargetSec > 0 ? Number((estimatedSeconds / beatTargetSec).toFixed(3)) : 1;
    return {
      id: beat.id,
      estimatedSeconds,
      targetSeconds: beatTargetSec,
      syllables,
      fillRatio,
    };
  });

  const estimatedDurationSeconds = Number(totalEst.toFixed(2));
  const coverageRatio =
    targetDurationSeconds > 0
      ? Number((estimatedDurationSeconds / targetDurationSeconds).toFixed(3))
      : 1;

  return {
    estimatedDurationSeconds,
    targetDurationSeconds,
    coverageRatio,
    totalSyllables,
    perSegment,
  };
}

/**
 * Formats timestamped transcript segments cleanly for Gemini recap context,
 * preserving chronological timestamps and removing consecutive duplicate Whisper echoes.
 */
export function formatTimestampedTranscriptContext(
  rawSegments: TimestampedTranscriptItem[],
  durationSeconds: number,
  maxLines = 120
): string {
  if (!Array.isArray(rawSegments) || rawSegments.length === 0) return '';
  const safeDur = Math.max(1, Number.isFinite(durationSeconds) ? durationSeconds : 12);

  const cleaned = rawSegments
    .map((s) => ({
      start: Math.max(0, Math.min(safeDur, Number(s.start || 0))),
      end: Math.max(0, Math.min(safeDur, Number(s.end || safeDur))),
      text: String(s.text || '').replace(/\s+/g, ' ').trim(),
    }))
    .filter((s) => s.text.length > 0)
    .sort((a, b) => a.start - b.start);

  const deduped: TimestampedTranscriptItem[] = [];
  for (const item of cleaned) {
    const prev = deduped[deduped.length - 1];
    if (prev && prev.text.toLowerCase() === item.text.toLowerCase()) {
      prev.end = Math.max(prev.end, item.end);
      continue;
    }
    deduped.push(item);
  }

  const capped = deduped.slice(0, Math.max(1, maxLines));
  return capped
    .map((s) => `[${formatClock(s.start)} -> ${formatClock(s.end)}] "${s.text}"`)
    .join('\n');
}

/**
 * Detects whether a transcript contains meaningful spoken content vs placeholder/empty text.
 */
export function hasSubstantiveTranscript(
  transcript: string,
  segments?: TimestampedTranscriptItem[]
): boolean {
  const joined = [
    String(transcript || '').trim(),
    ...(Array.isArray(segments) ? segments.map((s) => String(s.text || '').trim()) : []),
  ]
    .join(' ')
    .replace(/Visual scene sequence|Scene part \d+ \([^)]*\)/gi, '')
    .replace(/[\p{P}\p{S}\s]/gu, '')
    .trim();
  return joined.length >= 8;
}

const NON_CHARACTER_CAPITALIZED_WORDS = new Set([
  'the', 'a', 'an', 'and', 'or', 'but', 'if', 'so', 'yet', 'for', 'nor', 'at', 'by', 'in', 'of', 'on', 'to', 'up',
  'wait', 'stop', 'look', 'listen', 'run', 'help', 'please', 'sorry', 'thanks', 'thank', 'yes', 'no', 'okay', 'ok',
  'hey', 'hi', 'hello', 'bye', 'goodbye', 'what', 'where', 'when', 'why', 'who', 'how', 'which', 'whose',
  'this', 'that', 'these', 'those', 'here', 'there', 'now', 'then', 'today', 'tonight', 'tomorrow', 'yesterday',
  'man', 'woman', 'boy', 'girl', 'kid', 'child', 'person', 'people', 'someone', 'anyone', 'everyone', 'everybody',
  'nobody', 'anyone', 'stranger', 'victim', 'killer', 'suspect', 'guard', 'driver', 'waiter', 'teacher', 'student',
  'sir', 'madam', 'maam', 'bro', 'dude', 'friend', 'guys', 'boss', 'husband', 'wife', 'father', 'mother', 'son', 'daughter',
  'brother', 'sister', 'uncle', 'aunt', 'doctor', 'nurse', 'police', 'officer', 'detective', 'captain', 'inspector',
  'sergeant', 'agent', 'chief', 'professor', 'master', 'king', 'queen', 'prince', 'princess', 'lord', 'lady',
  'god', 'scene', 'beat', 'narration', 'dialogue', 'narrator', 'voiceover', 'storyteller', 'speaker',
  'audio', 'music', 'sfx', 'note', 'video', 'uploaded', 'visual', 'unknown', 'character', 'characters',
  'fine', 'good', 'ready', 'back', 'home', 'dead', 'alive', 'afraid', 'scared', 'sure', 'right', 'wrong',
  'lost', 'alone', 'tired', 'hungry', 'late', 'early', 'new', 'old', 'true', 'false', 'done', 'going', 'coming',
  'looking', 'trying', 'waiting', 'stay', 'leave', 'tell', 'ask', 'take', 'give', 'make', 'keep', 'hold',
  'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
  'january', 'february', 'march', 'april', 'june', 'july', 'august', 'september', 'october', 'november', 'december',
  'midnight', 'overpass', 'studio', 'alpharecap', 'part',
]);

const NON_CHARACTER_PHRASES = new Set([
  'new york', 'los angeles', 'san francisco', 'las vegas', 'united states', 'hong kong', 'south korea', 'north korea',
  'high school', 'middle school', 'police department', 'police station', 'city hall', 'main street',
  'uploaded video', 'story stage', 'opening hook', 'full ending', 'movie recap',
]);

const GENERIC_BURMESE_ROLE_OR_PRONOUN_SET = new Set([
  'သူ', 'သူမ', 'သူတို့', 'အဲဒီလူ', 'အဲ့ဒီလူ', 'ထိုသူ', 'ကောင်လေး', 'ကောင်မလေး', 'အဲဒီကောင်လေး', 'အဲ့ဒီကောင်လေး',
  'အဲဒီကောင်မလေး', 'အဲ့ဒီကောင်မလေး', 'လူငယ်', 'လူကြီး', 'အမျိုးသား', 'အမျိုးသမီး', 'အမျိုးသားတစ်ဦး', 'အမျိုးသမီးတစ်ဦး',
  'လူတစ်ဦး', 'လူတစ်ယောက်', 'လူစိမ်း', 'တရားခံ', 'ရဲအရာရှိ', 'ရဲသား', 'စုံထောက်', 'ဆရာဝန်', 'သူနာပြု',
  'သူ့အစ်ကို', 'သူ့ညီ', 'သူ့ညီမ', 'သူ့အစ်မ', 'သူ့အမေ', 'သူ့အဖေ', 'သူ့သူငယ်ချင်း', 'အမည်မသိ', 'ဇာတ်ကောင်',
]);

const TITLE_WORDS_RE_SOURCE =
  '(?:Detective|Inspector|Captain|Officer|Sergeant|Lieutenant|Lt\\.?|Colonel|Col\\.?|Major|General|Commander|Cmdr\\.?|Doctor|Dr\\.?|Professor|Prof\\.?|Agent|Chief|Commissioner|Superintendent|Mr\\.?|Mrs\\.?|Ms\\.?|Miss|Uncle|Aunt|Auntie|Brother|Sister|Father|Mother|Boss|Master|King|Queen|Prince|Princess|Lord|Lady|Sir|Madam|Coach|Judge|Pastor|Reverend|Rev\\.?|Senator|President|Mayor|Governor|Nurse)';
const LATIN_NAME_WORD_SOURCE = "[A-Z][a-zA-Z'’-]{1,20}(?:-[A-Za-z][a-zA-Z'’-]{1,18})?";
const LATIN_FULL_NAME_SOURCE = `(?:${TITLE_WORDS_RE_SOURCE}\\s+)?${LATIN_NAME_WORD_SOURCE}(?:\\s+${LATIN_NAME_WORD_SOURCE}){0,2}`;
const BURMESE_CHAR_TEST_RE = /[\u1000-\u109F]/;

const BANNED_EN_GENERIC_LABEL_RE =
  /(?:^|[^\p{L}\p{N}])((?:Unknown\s+|Unnamed\s+)?(?:Man|Woman|Boy|Girl|Male|Female|Guy|Lady|Person|Character|Speaker|Subject|Human|Individual|Figure|Voice)\s*(?:#\s*[0-9A-Za-z]+|\(\s*[0-9A-Za-z]+\s*\)|[0-9]+(?![a-zA-Z])|[A-Z](?=[\s.,!?;:'"”’)\u1000-\u109F]|$)))(?=[\s.,!?;:'"”’)\u1000-\u109F]|$)/gu;

const BANNED_MY_GENERIC_LABEL_RE =
  /(?:^|[\s'"“”‘’(\[])((?:အမျိုးသား|အမျိုးသမီး|လူ|ဇာတ်ကောင်|ပုဂ္ဂိုလ်|စကားပြောသူ|ကောင်လေး|ကောင်မလေး)\s*(?:\(\s*[0-9၀-၉A-Za-z]+\s*\)|#\s*[0-9၀-၉A-Za-z]+|\s+(?:[0-9၀-၉]+(?![\s]*(?:ဦး|ယောက်|ခု|တစ်))|[A-Z](?=[\s။,.!?ကကိုမှာကနေတွင်နဲ့နှင့်မှလည်းပဲ\u1000-\u109F]|$))))(?=[\s'"“”‘’။,.!?ကကိုမှာကနေတွင်နဲ့နှင့်မှလည်းပဲ]|$)/gu;

/**
 * Detects temporary machine/detection labels such as "Man 1", "Man 2", "Woman 1",
 * "Person A", "Person B", "အမျိုးသား (၁)", "အမျိုးသား ၂", etc.
 */
export function findBannedGenericCharacterLabels(text: string): string[] {
  const input = String(text || '');
  if (!input.trim()) return [];
  const hits: string[] = [];
  const seen = new Set<string>();

  for (const m of input.matchAll(BANNED_EN_GENERIC_LABEL_RE)) {
    const label = String(m[1] || '').replace(/\s+/g, ' ').trim();
    if (label && !seen.has(label.toLowerCase())) {
      seen.add(label.toLowerCase());
      hits.push(label);
    }
  }
  for (const m of input.matchAll(BANNED_MY_GENERIC_LABEL_RE)) {
    const label = String(m[1] || '').replace(/\s+/g, ' ').trim();
    if (label && !seen.has(label.toLowerCase())) {
      seen.add(label.toLowerCase());
      hits.push(label);
    }
  }
  return hits;
}

export function isBannedGenericCharacterLabel(label: string): boolean {
  const clean = String(label || '').replace(/\s+/g, ' ').trim();
  if (!clean) return false;
  const hits = findBannedGenericCharacterLabels(clean);
  return hits.some((h) => h.toLowerCase() === clean.toLowerCase());
}

const CONTEXTUAL_DESIGNATION_TERMS = new Set([
  'ဆိုင်ရှင်',
  'စားသောက်ဆိုင်ပိုင်ရှင်',
  'ဆိုင်ပိုင်ရှင်',
  'မန်နေဂျာ',
  'ရဲအရာရှိ',
  'ရဲတပ်ဖွဲ့ဝင်',
  'စုံထောက်',
  'ဆရာဝန်',
  'သူနာပြု',
  'အမျိုးသားဝန်ထမ်း',
  'အမျိုးသမီးဝန်ထမ်း',
  'ဝန်ထမ်း',
  'အဓိကဇာတ်ကောင်',
  'သူ့ရဲ့အဖော်',
  'အဖော်',
  'ကားမောင်းသမား',
  'ယာဉ်မောင်း',
  'စားပွဲထိုး',
  'လုံခြုံရေးဝန်ထမ်း',
  'လုံခြုံရေး',
  'ကျောင်းဆရာ',
  'ကျောင်းဆရာမ',
  'ကျောင်းသား',
  'ကျောင်းသူ',
  'သူဌေး',
  'အိမ်ရှင်',
  'တရားသူကြီး',
  'ရှေ့နေ',
  'သတင်းထောက်',
  'shopkeeper',
  'shop owner',
  'restaurant owner',
  'manager',
  'police officer',
  'doctor',
  'nurse',
  'male staff',
  'female staff',
  'main character',
  'protagonist',
  'companion',
  'partner',
  'driver',
  'security guard',
  'waiter',
]);

const BURMESE_VISUAL_DESCRIPTOR_RE =
  /(?:ဝတ်စုံ|အင်္ကျီ|ဂျာကင်|ကုတ်|ဦးထုပ်|မျက်မှန်|ဆံပင်|အရောင်|ထားတဲ့|ဝတ်ထားတဲ့|ကိုင်ထားတဲ့|နဲ့|နှင့်)\s*(?:အမျိုးသား|အမျိုးသမီး|ကောင်လေး|ကောင်မလေး|လူငယ်|လူကြီး|ဝန်ထမ်း|ပိုင်ရှင်|အဖော်)/;

export function isContextualCharacterDesignation(label: string): boolean {
  const clean = String(label || '').replace(/\s+/g, ' ').trim();
  if (!clean || isBannedGenericCharacterLabel(clean)) return false;
  if (CONTEXTUAL_DESIGNATION_TERMS.has(clean.toLowerCase()) || CONTEXTUAL_DESIGNATION_TERMS.has(clean)) {
    return true;
  }
  return BURMESE_VISUAL_DESCRIPTOR_RE.test(clean);
}

function cleanRawCharacterString(raw: string): string {
  let text = String(raw || '').replace(/\s+/g, ' ').trim();
  if (!text) return '';
  // Handle "ကောင်လေး (Ethan Hunt)" or "Ethan Hunt (Detective)"
  const parenMatch = text.match(/^(.+?)\s*\(([^()]+)\)\s*$/);
  if (parenMatch) {
    const outer = parenMatch[1].trim();
    const inner = parenMatch[2].trim();
    const outerGeneric =
      NON_CHARACTER_CAPITALIZED_WORDS.has(outer.toLowerCase()) ||
      GENERIC_BURMESE_ROLE_OR_PRONOUN_SET.has(outer) ||
      isBannedGenericCharacterLabel(outer);
    const innerGeneric =
      NON_CHARACTER_CAPITALIZED_WORDS.has(inner.toLowerCase()) ||
      GENERIC_BURMESE_ROLE_OR_PRONOUN_SET.has(inner) ||
      isBannedGenericCharacterLabel(inner);
    if (outerGeneric && !innerGeneric && inner.length >= 2) {
      text = inner;
    } else if (!outerGeneric) {
      text = outer;
    }
  }
  return text.replace(/^[\s'"“”‘’\-:]+|[\s'"“”‘’.,!?;:]+$/g, '').replace(/\s+/g, ' ').trim();
}

function isPlausibleCharacterToken(candidate: string, allowUnicodeProperName = false): boolean {
  const clean = cleanRawCharacterString(candidate);
  if (clean.length < 2 || clean.length > 52) return false;
  if (isBannedGenericCharacterLabel(clean)) return false;
  if (isContextualCharacterDesignation(clean)) return false;
  const lower = clean.toLowerCase();
  if (NON_CHARACTER_PHRASES.has(lower)) return false;
  if (GENERIC_BURMESE_ROLE_OR_PRONOUN_SET.has(clean)) return false;

  const parts = clean.split(/\s+/).filter(Boolean);
  if (parts.length === 0 || parts.length > 4) return false;

  if (BURMESE_CHAR_TEST_RE.test(clean)) {
    if (!allowUnicodeProperName) return false;
    return !GENERIC_BURMESE_ROLE_OR_PRONOUN_SET.has(clean) && clean.length >= 2;
  }

  if (parts.length === 1) {
    return /^[A-Z]/.test(parts[0]) && !NON_CHARACTER_CAPITALIZED_WORDS.has(parts[0].toLowerCase());
  }

  const firstLower = parts[0].toLowerCase();
  const lastLower = parts[parts.length - 1].toLowerCase();
  // Reject phrases whose last word is a stopword/non-name, or whose first word is a stopword (unless it is a recognized title)
  if (NON_CHARACTER_CAPITALIZED_WORDS.has(lastLower)) return false;
  const firstIsTitle = new RegExp(`^${TITLE_WORDS_RE_SOURCE}$`, 'i').test(parts[0]);
  if (!firstIsTitle && NON_CHARACTER_CAPITALIZED_WORDS.has(firstLower)) return false;
  return true;
}

const TOKEN_ABBREV_CANON: Record<string, string> = {
  dr: 'doctor',
  prof: 'professor',
  lt: 'lieutenant',
  col: 'colonel',
  cmdr: 'commander',
  rev: 'reverend',
};

function normalizeNameTokens(name: string): string[] {
  return String(name || '')
    .replace(/\./g, '')
    .toLowerCase()
    .split(/\s+/)
    .map((t) => TOKEN_ABBREV_CANON[t] || t)
    .filter(Boolean);
}

const BURMESE_HONORIFIC_PREFIX_RE = /^(?:ဆရာမ|ဆရာ|မောင်|ဦး|ဒေါ်|ကို|မ)\s*/;

function isSubsequenceMatch(shorter: VerifiedCharacterProfile, fuller: VerifiedCharacterProfile): boolean {
  const aClean = shorter.canonicalName.trim();
  const bClean = fuller.canonicalName.trim();
  if (aClean.toLowerCase() === bClean.toLowerCase()) return false;

  const aTokens = normalizeNameTokens(aClean);
  const bTokens = normalizeNameTokens(bClean);
  const isStrictlyFuller =
    bTokens.length > aTokens.length ||
    (bTokens.length === aTokens.length && bClean.length > aClean.length);
  if (!isStrictlyFuller) return false;

  // Burmese prefix + proper name match (e.g. "ကျော်ဇေယျ" -> "မောင်ကျော်ဇေယျ")
  if (BURMESE_CHAR_TEST_RE.test(aClean) && BURMESE_CHAR_TEST_RE.test(bClean)) {
    const bStripped = bClean.replace(BURMESE_HONORIFIC_PREFIX_RE, '').trim();
    const aStripped = aClean.replace(BURMESE_HONORIFIC_PREFIX_RE, '').trim();
    if (aStripped.length >= 2 && aStripped === bStripped && bClean.length > aClean.length) {
      return true;
    }
  }

  if (aTokens.length === 0 || bTokens.length < aTokens.length) return false;
  // Ignore trailing title-only match: every token in shorter must appear in order inside fuller
  let j = 0;
  for (let i = 0; i < bTokens.length && j < aTokens.length; i++) {
    if (bTokens[i] === aTokens[j]) {
      j++;
    }
  }
  return j === aTokens.length;
}

/**
 * Consolidates partial/short character references (e.g. "Ethan", "Detective Miller", "Ethan Hunt")
 * onto their unique fuller canonical name ("Detective Ethan Hunt") while storing shorter forms in aliases.
 * Never merges ambiguous shared surnames (e.g. "Miller" when both "John Miller" & "Sarah Miller" exist).
 */
export function consolidateVerifiedCharacterProfiles(
  profiles: VerifiedCharacterProfile[]
): VerifiedCharacterProfile[] {
  if (!Array.isArray(profiles) || profiles.length <= 1) return profiles || [];

  const cloned: VerifiedCharacterProfile[] = profiles.map((p) => ({
    ...p,
    aliases: [...new Set((p.aliases || []).map((a) => a.trim()).filter(Boolean))],
  }));

  const n = cloned.length;
  // Direct subsequence DAG: edge i -> j means i is a partial form of fuller j
  const edges: number[][] = Array.from({ length: n }, () => []);
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (i !== j && isSubsequenceMatch(cloned[i], cloned[j])) {
        edges[i].push(j);
      }
    }
  }

  // Find maximal sinks reachable from each node i
  const getMaximalSinks = (start: number): number[] => {
    const visited = new Set<number>();
    const stack = [...edges[start]];
    const sinks = new Set<number>();
    while (stack.length > 0) {
      const curr = stack.pop()!;
      if (visited.has(curr)) continue;
      visited.add(curr);
      if (edges[curr].length === 0) {
        sinks.add(curr);
      } else {
        for (const nxt of edges[curr]) stack.push(nxt);
      }
    }
    return [...sinks];
  };

  const mergedInto = new Map<number, number>();
  const ambiguousStandaloneIndices = new Set<number>();

  for (let i = 0; i < n; i++) {
    if (edges[i].length === 0) continue;
    const sinks = getMaximalSinks(i);
    if (sinks.length === 1) {
      mergedInto.set(i, sinks[0]);
    } else if (sinks.length > 1 && normalizeNameTokens(cloned[i].canonicalName).length === 1) {
      // Single bare surname/token shared by multiple full characters (e.g. "Miller" across "John Miller" & "Sarah Miller")
      // should not remain as a separate ambiguous person entry when all fuller characters are already captured.
      ambiguousStandaloneIndices.add(i);
    }
  }

  const evidenceRank: Record<VerifiedCharacterProfile['evidenceSource'], number> = {
    metadata: 3,
    transcript: 2,
    scene: 1,
  };

  for (const [srcIdx, targetIdx] of mergedInto.entries()) {
    const src = cloned[srcIdx];
    const target = cloned[targetIdx];
    const allTerms = [src.canonicalName, ...src.aliases];
    for (const term of allTerms) {
      const cleanTerm = term.trim();
      if (
        cleanTerm &&
        cleanTerm.toLowerCase() !== target.canonicalName.toLowerCase() &&
        !target.aliases.some((a) => a.toLowerCase() === cleanTerm.toLowerCase())
      ) {
        target.aliases.push(cleanTerm);
      }
    }
    if (!target.roleOrRelation && src.roleOrRelation) {
      target.roleOrRelation = src.roleOrRelation;
    }
    if (evidenceRank[src.evidenceSource] > evidenceRank[target.evidenceSource]) {
      target.evidenceSource = src.evidenceSource;
    }
  }

  const result: VerifiedCharacterProfile[] = [];
  for (let i = 0; i < n; i++) {
    if (mergedInto.has(i) || ambiguousStandaloneIndices.has(i)) continue;
    const p = cloned[i];
    // Drop ambiguous aliases that also match another distinct canonical character
    p.aliases = p.aliases.filter((al) => {
      const alLower = al.toLowerCase();
      const matchingOthers = cloned.filter(
        (other, j) =>
          j !== i &&
          !mergedInto.has(j) &&
          !ambiguousStandaloneIndices.has(j) &&
          (other.canonicalName.toLowerCase() === alLower ||
            normalizeNameTokens(other.canonicalName).includes(alLower))
      );
      return matchingOthers.length === 0;
    });
    result.push(p);
  }

  return result;
}

/**
 * Extracts ONLY evidence-backed character names, nicknames, professional titles/ranks,
 * honorifics, and relationships directly from the transcript, scenes, and metadata.
 * Consolidates partial references onto verified FULL names and never invents unverified identities.
 */
export function extractVerifiedCharacterClues(params: {
  transcript?: string;
  timestampedSegments?: TimestampedTranscriptItem[];
  scenes?: SceneSummary[];
  storyAnalysisMy?: string;
  videoTitle?: string;
  explicitCharacters?: Array<string | { canonicalName?: string; aliases?: string[]; roleOrRelation?: string }>;
}): VerifiedCharacterProfile[] {
  const {
    transcript = '',
    timestampedSegments = [],
    scenes = [],
    storyAnalysisMy = '',
    videoTitle = '',
    explicitCharacters = [],
  } = params;

  const profileMap = new Map<string, VerifiedCharacterProfile>();

  const registerProfile = (
    rawName: string,
    evidenceSource: VerifiedCharacterProfile['evidenceSource'],
    roleOrRelation?: string,
    extraAliases: string[] = [],
    allowUnicodeProperName = false
  ) => {
    const clean = cleanRawCharacterString(rawName);
    if (!clean || !isPlausibleCharacterToken(clean, allowUnicodeProperName)) return;
    const key = clean.toLowerCase();
    const existing = profileMap.get(key);
    if (existing) {
      for (const al of extraAliases) {
        const a = cleanRawCharacterString(al);
        if (a && a.toLowerCase() !== key && !existing.aliases.some((x) => x.toLowerCase() === a.toLowerCase())) {
          existing.aliases.push(a);
        }
      }
      if (!existing.roleOrRelation && roleOrRelation) {
        existing.roleOrRelation = roleOrRelation;
      }
      return;
    }
    profileMap.set(key, {
      canonicalName: clean,
      aliases: extraAliases
        .map((a) => cleanRawCharacterString(a))
        .filter((a) => a && a.toLowerCase() !== key && !GENERIC_BURMESE_ROLE_OR_PRONOUN_SET.has(a)),
      ...(roleOrRelation ? { roleOrRelation } : {}),
      evidenceSource,
    });
  };

  for (const item of explicitCharacters) {
    if (typeof item === 'string') {
      registerProfile(item, 'metadata', undefined, [], true);
    } else if (item && typeof item === 'object' && item.canonicalName) {
      registerProfile(
        item.canonicalName,
        'metadata',
        item.roleOrRelation,
        Array.isArray(item.aliases) ? item.aliases : [],
        true
      );
    }
  }

  // Direct scene character lists (supporting both Latin and Burmese/Unicode full names)
  for (const sc of scenes) {
    if (Array.isArray(sc.characters)) {
      for (const ch of sc.characters) {
        registerProfile(String(ch || ''), 'scene', undefined, [], true);
      }
    }
  }

  const transcriptCorpus = [
    transcript,
    ...timestampedSegments.map((s) => s.text),
    ...scenes.map((s) => String(s.dialogueRef || '')),
  ]
    .filter(Boolean)
    .join('\n');

  const extractStructuredNamesFromText = (
    corpus: string,
    source: VerifiedCharacterProfile['evidenceSource']
  ) => {
    if (!corpus.trim()) return;

    // 1. Explicit speaker turns: "Detective Ethan Hunt: ..." or "Marcus Vance: ..." or "Dr. Lin: ..."
    const speakerRe = new RegExp(`(?:^|\\n)\\s*(${LATIN_FULL_NAME_SOURCE})\\s*:\\s+`, 'g');
    for (const m of corpus.matchAll(speakerRe)) {
      registerProfile(m[1], source);
    }

    // 2. Self-introductions & explicit naming phrases (case-sensitive on captured proper name!)
    const introRe = new RegExp(
      `(?:[Mm]y [Nn]ame [Ii]s|[Mm]y [Nn]ame's|[Ii]'m|[Ii] am|[Tt]his [Ii]s|[Cc]all [Mm]e|[Nn]amed|[Kk]nown [Aa]s)\\s+(${LATIN_FULL_NAME_SOURCE})(?=[,.'’"”!?\\s]|$)`,
      'g'
    );
    for (const m of corpus.matchAll(introRe)) {
      const fullIntro = cleanRawCharacterString(m[1]);
      const parts = fullIntro.split(/\s+/);
      registerProfile(fullIntro, source, undefined, parts.length >= 2 ? [parts[0]] : []);
    }

    // 3. Titled full character names: "Detective Ethan Hunt", "Detective Miller", "Captain Park", "Dr. Stephen Strange"
    const titledRe = new RegExp(
      `\\b(${TITLE_WORDS_RE_SOURCE})\\s+(${LATIN_NAME_WORD_SOURCE}(?:\\s+${LATIN_NAME_WORD_SOURCE}){0,2})\\b`,
      'g'
    );
    for (const m of corpus.matchAll(titledRe)) {
      const fullTitled = `${m[1]} ${m[2]}`.replace(/\s+/g, ' ').trim();
      const nameOnly = m[2].trim();
      const firstToken = nameOnly.split(/\s+/)[0];
      const aliases = [nameOnly];
      if (firstToken && firstToken !== nameOnly) aliases.push(firstToken);
      registerProfile(fullTitled, source, m[1], aliases);
    }

    // 4. Direct vocatives in dialogue: "Wait, Sarah Connor!" / "Listen to me, Marcus." / "Hey Ethan Hunt, ..."
    const trailingVocativeRe = new RegExp(`,\\s*(${LATIN_FULL_NAME_SOURCE})(?=[!?.])`, 'g');
    for (const m of corpus.matchAll(trailingVocativeRe)) {
      registerProfile(m[1], source);
    }
    const leadingVocativeRe = new RegExp(
      `(?:^|[.!?]\\s+)(?:Hey|Hi|Wait|Stop|Listen|Look|Run|Careful|Sorry|Please|Tell me|Excuse me),?\\s+(${LATIN_FULL_NAME_SOURCE})(?=[,!?.])`,
      'g'
    );
    for (const m of corpus.matchAll(leadingVocativeRe)) {
      registerProfile(m[1], source);
    }
  };

  extractStructuredNamesFromText(transcriptCorpus, 'transcript');

  // 5. Multi-word capitalized proper names appearing inside transcript (e.g. "John Wick", "Sarah Connor")
  if (transcriptCorpus.trim()) {
    const multiWordTranscriptRe = new RegExp(
      `\\b(${LATIN_NAME_WORD_SOURCE}(?:\\s+${LATIN_NAME_WORD_SOURCE}){1,2})\\b`,
      'g'
    );
    for (const m of transcriptCorpus.matchAll(multiWordTranscriptRe)) {
      const candidate = cleanRawCharacterString(m[1]);
      if (candidate.split(/\s+/).length >= 2 && isPlausibleCharacterToken(candidate)) {
        const firstWord = candidate.split(/\s+/)[0];
        registerProfile(candidate, 'transcript', undefined, firstWord ? [firstWord] : []);
      }
    }
  }

  // 6. Scene descriptions, storyEvent, story overview & video title
  const sceneCorpus = [
    ...scenes.map((s) => String(s.storyEvent || '')),
    ...scenes.map((s) => String(s.descriptionMy || '')),
    String(storyAnalysisMy || ''),
    String(videoTitle || ''),
  ]
    .filter(Boolean)
    .join('\n');

  extractStructuredNamesFromText(sceneCorpus, 'scene');

  if (sceneCorpus.trim()) {
    const sceneNamedRe = new RegExp(
      `\\b(${LATIN_NAME_WORD_SOURCE}(?:\\s+${LATIN_NAME_WORD_SOURCE}){0,2})\\b`,
      'g'
    );
    for (const m of sceneCorpus.matchAll(sceneNamedRe)) {
      const candidate = cleanRawCharacterString(m[1]);
      if (!isPlausibleCharacterToken(candidate)) continue;
      const wordCount = candidate.split(/\s+/).length;
      const inTranscript = transcriptCorpus.toLowerCase().includes(candidate.toLowerCase());
      // Accept scene proper names when corroborated by transcript OR clear multi-word proper name embedded in Burmese scene notes
      if (inTranscript || (wordCount >= 2 && BURMESE_CHAR_TEST_RE.test(sceneCorpus))) {
        registerProfile(candidate, 'scene');
      }
    }
  }

  const consolidated = consolidateVerifiedCharacterProfiles(Array.from(profileMap.values()));
  return consolidated.slice(0, 14);
}

/**
 * Formats verified characters and forms of address for Movie Recap prompts.
 */
export function formatCharacterRosterPromptBlock(profiles: VerifiedCharacterProfile[]): string {
  if (!Array.isArray(profiles) || profiles.length === 0) return '';
  const lines = profiles.map((p) => {
    const aliasText = p.aliases.length > 0 ? ` | short aliases found in source (upgrade to FULL NAME): ${p.aliases.join(', ')}` : '';
    const roleText = p.roleOrRelation ? ` | title/role: ${p.roleOrRelation}` : '';
    return `- FULL NAME: "${p.canonicalName}"${roleText}${aliasText} (verified from ${p.evidenceSource})`;
  });
  return `Verified Character FULL Names & Forms of Address (ALWAYS write the COMPLETE FULL NAME shown above — never truncate to first name only, never swap names, and never replace known characters with generic "သူ/သူမ/ကောင်လေး/ကောင်မလေး" or detection labels like "Man 1" / "အမျိုးသား (၁)"):\n${lines.join('\n')}`;
}

function uniqueSortedTimestamps(values: number[]): number[] {
  const clean = values
    .map((v) => Number(v))
    .filter((v) => Number.isFinite(v) && v >= 0)
    .map((v) => Number(v.toFixed(2)));
  return [...new Set(clean)].sort((a, b) => a - b);
}

function isSingleBareGenericNoun(value: string): boolean {
  const clean = String(value || '').trim();
  if (!clean) return true;
  if (isBannedGenericCharacterLabel(clean)) return true;
  if (
    /^(?:သူ|သူမ|သူတို့|အဲဒီလူ|အဲ့ဒီလူ|ထိုသူ|ကောင်လေး|ကောင်မလေး|အမျိုးသား|အမျိုးသမီး|လူတစ်ဦး|လူတစ်ယောက်|ဇာတ်ကောင်|အမည်မသိ|man|woman|boy|girl|person|stranger|unknown)$/i.test(
      clean
    )
  ) {
    return true;
  }
  return false;
}

function resolveBestDesignationFromHint(hint: {
  nameOrRole?: string;
  originalName?: string;
  burmeseName?: string;
  occupationOrTitle?: string;
  relationship?: string;
  visualDescription?: string;
}): string {
  const candidates = [
    hint.burmeseName,
    hint.originalName,
    hint.nameOrRole,
    hint.occupationOrTitle,
    hint.visualDescription,
    hint.relationship,
  ];
  for (const raw of candidates) {
    const clean = cleanRawCharacterString(String(raw || ''));
    if (!clean || isSingleBareGenericNoun(clean)) continue;
    return clean;
  }
  return '';
}

function hintMatchesProperProfile(
  hint: {
    nameOrRole?: string;
    originalName?: string;
    burmeseName?: string;
    aliases?: string[];
  },
  profile: VerifiedCharacterProfile
): boolean {
  const terms = [
    hint.originalName,
    hint.burmeseName,
    hint.nameOrRole,
    ...(hint.aliases || []),
  ]
    .map((t) => cleanRawCharacterString(String(t || '')))
    .filter((t) => t && !isSingleBareGenericNoun(t));

  if (terms.length === 0) return false;
  const profileTerms = [profile.canonicalName, ...profile.aliases].map((t) => t.toLowerCase());
  const canonTokens = normalizeNameTokens(profile.canonicalName);

  for (const t of terms) {
    const tLow = t.toLowerCase();
    if (profileTerms.includes(tLow)) return true;
    const tTokens = normalizeNameTokens(t);
    if (tTokens.length >= 2 && canonTokens.length >= 2) {
      let j = 0;
      for (let i = 0; i < canonTokens.length && j < tTokens.length; i++) {
        if (canonTokens[i] === tTokens[j]) j++;
      }
      if (j === tTokens.length) return true;
    }
  }
  return false;
}

/**
 * Builds and updates a structured Character Registry combining:
 * 1) Verified real character names (from dialogue, subtitles, credits, scene metadata)
 * 2) Evidence-backed contextual designations (e.g. "ဆိုင်ရှင်", "မန်နေဂျာ", "ရဲအရာရှိ", "ဆရာဝန်")
 *    and distinctive visual descriptions (e.g. "အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား") when names are unknown.
 * Never retains temporary detection labels ("Man 1", "Woman 1", "Person A", "အမျိုးသား (၁)")
 * and updates existing entries only when compatible reliable evidence arrives.
 */
export function buildCharacterRegistry(params: {
  transcript?: string;
  timestampedSegments?: TimestampedTranscriptItem[];
  scenes?: SceneSummary[];
  storyAnalysisMy?: string;
  videoTitle?: string;
  existingRegistry?: CharacterRegistryEntry[];
  explicitCharacters?: Array<string | { canonicalName?: string; aliases?: string[]; roleOrRelation?: string }>;
}): CharacterRegistryEntry[] {
  const {
    transcript = '',
    timestampedSegments = [],
    scenes = [],
    storyAnalysisMy = '',
    videoTitle = '',
    existingRegistry = [],
    explicitCharacters = [],
  } = params;

  const verifiedProfiles = extractVerifiedCharacterClues({
    transcript,
    timestampedSegments,
    scenes,
    storyAnalysisMy,
    videoTitle,
    explicitCharacters,
  });

  const collectTimestampsForTerms = (terms: string[]): number[] => {
    const cleanTerms = terms
      .map((t) => cleanRawCharacterString(t))
      .filter((t) => t.length >= 2 && !isSingleBareGenericNoun(t));
    if (cleanTerms.length === 0) return [];
    const ts: number[] = [];
    for (const sc of scenes) {
      const charBlob = [
        ...(Array.isArray(sc.characters) ? sc.characters : []),
        ...(Array.isArray(sc.characterRegistryHints)
          ? sc.characterRegistryHints.flatMap((h) => [
              h.nameOrRole,
              h.originalName || '',
              h.burmeseName || '',
              h.occupationOrTitle || '',
              h.visualDescription || '',
              ...(h.aliases || []),
            ])
          : []),
      ]
        .filter(Boolean)
        .join(' | ');
      const textBlob = [charBlob, sc.descriptionMy, sc.storyEvent, sc.dialogueRef].filter(Boolean).join(' ');
      if (cleanTerms.some((term) => textExplicitlyMentionsTerm(textBlob, term))) {
        ts.push(sc.timestamp);
      }
    }
    for (const seg of timestampedSegments) {
      if (cleanTerms.some((term) => textExplicitlyMentionsTerm(seg.text, term))) {
        ts.push(seg.start);
      }
    }
    return uniqueSortedTimestamps(ts);
  };

  const entries: CharacterRegistryEntry[] = [];
  const assignedIds = new Set<string>();
  const reservedPrevIds = new Set<string>();
  const prevByKey = new Map<string, CharacterRegistryEntry>();

  for (const prev of existingRegistry) {
    if (!prev || !prev.burmeseName) continue;
    if (isSingleBareGenericNoun(prev.burmeseName)) continue;
    if (prev.characterId) reservedPrevIds.add(prev.characterId);
    if (prev.verifiedOriginalName) {
      prevByKey.set(prev.verifiedOriginalName.toLowerCase(), prev);
    }
    prevByKey.set(prev.burmeseName.toLowerCase(), prev);
    if (prev.visualDescription) {
      prevByKey.set(`vis:${prev.visualDescription.toLowerCase()}`, prev);
    }
  }

  let nextIdNum = 1;
  const allocateCharacterId = (preferred?: string): string => {
    if (preferred && !assignedIds.has(preferred)) {
      assignedIds.add(preferred);
      return preferred;
    }
    while (assignedIds.has(`char_${nextIdNum}`) || reservedPrevIds.has(`char_${nextIdNum}`)) {
      nextIdNum += 1;
    }
    const assigned = `char_${nextIdNum++}`;
    assignedIds.add(assigned);
    return assigned;
  };

  // 1. Register verified real-name characters first
  for (const profile of verifiedProfiles) {
    const matchedHints: Array<{
      ts: number;
      burmeseName?: string;
      occupationOrTitle?: string;
      relationship?: string;
      visualDescription?: string;
      aliases?: string[];
      confidence?: CharacterIdentificationConfidence;
    }> = [];

    for (const sc of scenes) {
      for (const h of sc.characterRegistryHints || []) {
        if (hintMatchesProperProfile(h, profile)) {
          matchedHints.push({
            ts: sc.timestamp,
            burmeseName: h.burmeseName,
            occupationOrTitle: h.occupationOrTitle,
            relationship: h.relationship,
            visualDescription: h.visualDescription,
            aliases: h.aliases,
            confidence: h.confidence,
          });
        }
      }
    }

    const prev =
      prevByKey.get(profile.canonicalName.toLowerCase()) ||
      matchedHints
        .map((h) =>
          h.visualDescription ? prevByKey.get(`vis:${h.visualDescription.toLowerCase()}`) : undefined
        )
        .find(Boolean);

    const hintBurmeseName = matchedHints
      .map((h) => cleanRawCharacterString(h.burmeseName || ''))
      .find((b) => b && !isSingleBareGenericNoun(b) && BURMESE_CHAR_TEST_RE.test(b));

    const burmeseName =
      BURMESE_CHAR_TEST_RE.test(profile.canonicalName)
        ? profile.canonicalName
        : hintBurmeseName || prev?.burmeseName || profile.canonicalName;

    const allAliases = [
      ...profile.aliases,
      ...(prev?.aliases || []),
      ...matchedHints.flatMap((h) => h.aliases || []),
    ]
      .map((a) => cleanRawCharacterString(a))
      .filter(
        (a) =>
          a &&
          !isSingleBareGenericNoun(a) &&
          a.toLowerCase() !== profile.canonicalName.toLowerCase() &&
          a.toLowerCase() !== burmeseName.toLowerCase()
      );

    const occ =
      cleanRawCharacterString(
        matchedHints.map((h) => h.occupationOrTitle || '').find(Boolean) ||
          profile.roleOrRelation ||
          prev?.verifiedOccupationOrTitle ||
          ''
      ) || undefined;

    const rel =
      cleanRawCharacterString(
        matchedHints.map((h) => h.relationship || '').find(Boolean) || prev?.verifiedRelationship || ''
      ) || undefined;

    const vis =
      cleanRawCharacterString(
        matchedHints.map((h) => h.visualDescription || '').find(Boolean) || prev?.visualDescription || ''
      ) || undefined;

    const timestamps = uniqueSortedTimestamps([
      ...(prev?.relatedSceneTimestamps || []),
      ...matchedHints.map((h) => h.ts),
      ...collectTimestampsForTerms([profile.canonicalName, burmeseName, ...allAliases]),
    ]);

    const hasTranscriptAndScene =
      scenes.some((sc) =>
        [...(sc.characters || []), sc.descriptionMy, sc.storyEvent]
          .filter(Boolean)
          .some((t) => textExplicitlyMentionsTerm(String(t), profile.canonicalName))
      ) &&
      textExplicitlyMentionsTerm(
        [transcript, ...timestampedSegments.map((s) => s.text)].join('\n'),
        profile.canonicalName
      );

    const confidence: CharacterIdentificationConfidence =
      profile.evidenceSource === 'metadata' ||
      hasTranscriptAndScene ||
      timestamps.length >= 2 ||
      matchedHints.some((h) => h.confidence === 'high')
        ? 'high'
        : 'medium';

    entries.push({
      characterId: allocateCharacterId(prev?.characterId),
      verifiedOriginalName: profile.canonicalName,
      burmeseName,
      aliases: [...new Set(allAliases)],
      ...(occ ? { verifiedOccupationOrTitle: occ } : {}),
      ...(rel ? { verifiedRelationship: rel } : {}),
      ...(vis ? { visualDescription: vis } : {}),
      firstAppearanceTimestamp: timestamps[0] ?? prev?.firstAppearanceTimestamp ?? 0,
      relatedSceneTimestamps: timestamps,
      identificationConfidence: confidence,
      evidenceSource: profile.evidenceSource,
    });
  }

  // 2. Register unnamed characters using ONLY contextual designations or visual descriptions (never banned labels)
  const namedTermSet = new Set(
    entries.flatMap((e) =>
      [e.verifiedOriginalName || '', e.burmeseName, ...e.aliases]
        .filter(Boolean)
        .map((t) => t.toLowerCase())
    )
  );

  const contextualPool = new Map<string, CharacterRegistryEntry>();

  const upsertContextualEntry = (candidate: {
    designation: string;
    occupationOrTitle?: string;
    relationship?: string;
    visualDescription?: string;
    timestamp: number;
    aliases?: string[];
    confidence?: CharacterIdentificationConfidence;
  }) => {
    const cleanDesig = cleanRawCharacterString(candidate.designation);
    if (!cleanDesig || isSingleBareGenericNoun(cleanDesig)) return;
    const desigLow = cleanDesig.toLowerCase();
    if (namedTermSet.has(desigLow)) return;

    const cleanVis = cleanRawCharacterString(candidate.visualDescription || '');
    const cleanOcc = cleanRawCharacterString(candidate.occupationOrTitle || '');
    const cleanRel = cleanRawCharacterString(candidate.relationship || '');

    // Never merge two contextual characters whose visual descriptions or occupations conflict
    let matchKey = '';
    for (const [k, existing] of contextualPool.entries()) {
      const sameDesignation = existing.burmeseName.toLowerCase() === desigLow;
      const sameVisual =
        cleanVis && existing.visualDescription && existing.visualDescription.toLowerCase() === cleanVis.toLowerCase();
      const conflictingVisual =
        cleanVis &&
        existing.visualDescription &&
        existing.visualDescription.toLowerCase() !== cleanVis.toLowerCase();
      const conflictingOcc =
        cleanOcc &&
        existing.verifiedOccupationOrTitle &&
        existing.verifiedOccupationOrTitle.toLowerCase() !== cleanOcc.toLowerCase();

      if ((sameDesignation || sameVisual) && !conflictingVisual && !conflictingOcc) {
        matchKey = k;
        break;
      }
    }

    if (matchKey) {
      const existing = contextualPool.get(matchKey)!;
      existing.relatedSceneTimestamps = uniqueSortedTimestamps([
        ...existing.relatedSceneTimestamps,
        candidate.timestamp,
      ]);
      existing.firstAppearanceTimestamp =
        existing.relatedSceneTimestamps[0] ?? existing.firstAppearanceTimestamp;
      if (!existing.verifiedOccupationOrTitle && cleanOcc) {
        existing.verifiedOccupationOrTitle = cleanOcc;
      }
      if (!existing.verifiedRelationship && cleanRel) {
        existing.verifiedRelationship = cleanRel;
      }
      if (!existing.visualDescription && cleanVis) {
        existing.visualDescription = cleanVis;
      }
      for (const al of candidate.aliases || []) {
        const cleanAl = cleanRawCharacterString(al);
        if (
          cleanAl &&
          !isSingleBareGenericNoun(cleanAl) &&
          cleanAl.toLowerCase() !== existing.burmeseName.toLowerCase() &&
          !existing.aliases.some((x) => x.toLowerCase() === cleanAl.toLowerCase())
        ) {
          existing.aliases.push(cleanAl);
        }
      }
      return;
    }

    const prev =
      prevByKey.get(desigLow) || (cleanVis ? prevByKey.get(`vis:${cleanVis.toLowerCase()}`) : undefined);
    const id = allocateCharacterId(prev && !entries.some((e) => e.characterId === prev.characterId) ? prev.characterId : undefined);
    const timestamps = uniqueSortedTimestamps([
      ...(prev?.relatedSceneTimestamps || []),
      candidate.timestamp,
      ...collectTimestampsForTerms([cleanDesig, cleanVis].filter(Boolean)),
    ]);

    const key = `${desigLow}|${cleanVis.toLowerCase()}|${id}`;
    contextualPool.set(key, {
      characterId: id,
      burmeseName: cleanDesig,
      aliases: (candidate.aliases || [])
        .map((a) => cleanRawCharacterString(a))
        .filter((a) => a && !isSingleBareGenericNoun(a) && a.toLowerCase() !== desigLow),
      ...(cleanOcc ? { verifiedOccupationOrTitle: cleanOcc } : {}),
      ...(cleanRel ? { verifiedRelationship: cleanRel } : {}),
      ...(cleanVis ? { visualDescription: cleanVis } : {}),
      firstAppearanceTimestamp: timestamps[0] ?? Math.max(0, Number(candidate.timestamp.toFixed(2))),
      relatedSceneTimestamps: timestamps.length > 0 ? timestamps : [Math.max(0, Number(candidate.timestamp.toFixed(2)))],
      identificationConfidence:
        candidate.confidence || (cleanOcc || cleanRel || cleanVis ? 'medium' : 'low'),
      evidenceSource: 'scene',
    });
  };

  for (const sc of scenes) {
    for (const h of sc.characterRegistryHints || []) {
      const desig = resolveBestDesignationFromHint(h);
      if (!desig) continue;
      if (namedTermSet.has(desig.toLowerCase())) continue;
      upsertContextualEntry({
        designation: desig,
        occupationOrTitle: h.occupationOrTitle,
        relationship: h.relationship,
        visualDescription: h.visualDescription,
        timestamp: sc.timestamp,
        aliases: h.aliases,
        confidence: h.confidence,
      });
    }
    for (const rawChar of sc.characters || []) {
      const cleanChar = cleanRawCharacterString(String(rawChar || ''));
      if (!cleanChar || isSingleBareGenericNoun(cleanChar)) continue;
      if (namedTermSet.has(cleanChar.toLowerCase())) continue;
      if (isContextualCharacterDesignation(cleanChar) || BURMESE_CHAR_TEST_RE.test(cleanChar)) {
        upsertContextualEntry({
          designation: cleanChar,
          occupationOrTitle: CONTEXTUAL_DESIGNATION_TERMS.has(cleanChar) ? cleanChar : undefined,
          visualDescription: BURMESE_VISUAL_DESCRIPTOR_RE.test(cleanChar) ? cleanChar : undefined,
          timestamp: sc.timestamp,
        });
      }
    }
  }

  // Carry over still-valid entries from existingRegistry if scenes weren't re-emitted yet
  for (const prev of existingRegistry) {
    if (!prev || isSingleBareGenericNoun(prev.burmeseName)) continue;
    const prevOrigLow = prev.verifiedOriginalName?.toLowerCase();
    const prevNameLow = prev.burmeseName.toLowerCase();
    const alreadyExists =
      entries.some(
        (e) =>
          e.characterId === prev.characterId ||
          e.burmeseName.toLowerCase() === prevNameLow ||
          (prevOrigLow && e.verifiedOriginalName?.toLowerCase() === prevOrigLow)
      ) ||
      [...contextualPool.values()].some(
        (c) =>
          c.characterId === prev.characterId ||
          c.burmeseName.toLowerCase() === prevNameLow
      );
    if (!alreadyExists) {
      const carryId = allocateCharacterId(prev.characterId);
      contextualPool.set(`carry:${carryId}`, {
        ...prev,
        characterId: carryId,
      });
    }
  }

  return [...entries, ...contextualPool.values()]
    .sort((a, b) => a.firstAppearanceTimestamp - b.firstAppearanceTimestamp)
    .slice(0, 18);
}

/**
 * Formats the complete structured Character Registry for Story Analysis, Script Generation,
 * Consistency Verification, and Duration Adjustment prompts.
 */
export function formatCharacterRegistryPromptBlock(
  registry: CharacterRegistryEntry[],
  fallbackProfiles: VerifiedCharacterProfile[] = []
): string {
  if (Array.isArray(registry) && registry.length > 0) {
    const lines = registry.map((c) => {
      const origLabel = c.verifiedOriginalName
        ? `Original Name: "${c.verifiedOriginalName}"`
        : 'Original Name: [UNKNOWN — DO NOT INVENT A NAME]';
      const aliasLabel = c.aliases.length > 0 ? ` | Aliases/Nicknames: ${c.aliases.join(', ')}` : '';
      const occLabel = c.verifiedOccupationOrTitle ? ` | Occupation/Title: ${c.verifiedOccupationOrTitle}` : '';
      const relLabel = c.verifiedRelationship ? ` | Relationship: ${c.verifiedRelationship}` : '';
      const visLabel = c.visualDescription ? ` | Visual: ${c.visualDescription}` : '';
      const tsList = c.relatedSceneTimestamps.slice(0, 6).map((t) => `${t.toFixed(1)}s`).join(', ');
      return `- [${c.characterId}] ${origLabel} | Burmese Name/Designation: "${c.burmeseName}"${aliasLabel}${occLabel}${relLabel}${visLabel} | First Seen: ${c.firstAppearanceTimestamp.toFixed(1)}s${tsList ? ` | Scenes: [${tsList}]` : ''} | Confidence: ${c.identificationConfidence}`;
    });

    return `CHARACTER REGISTRY (USE THESE EXACT VERIFIED NAMES OR CONTEXTUAL DESIGNATIONS CONSISTENTLY — NEVER use "Man 1", "Man 2", "Woman 1", "Person A", "Person B", or "အမျိုးသား (၁)" / "အမျိုးသား (၂)"):\n${lines.join('\n')}`;
  }

  return formatCharacterRosterPromptBlock(fallbackProfiles);
}

export const RECAP_STORY_STAGE_LABELS: Record<RecapStoryStage, { en: string; my: string }> = {
  opening_hook: { en: '1. Opening Hook', my: '၁။ အစပိုင်း ဆွဲဆောင်မှု' },
  story_background: { en: '2. Story Background', my: '၂။ ဇာတ်လမ်းနောက်ခံ' },
  character_intro: { en: '3. Character Introduction', my: '၃။ ဇာတ်ကောင်မိတ်ဆက်' },
  main_conflict: { en: '4. Main Conflict', my: '၄။ အဓိက ပဋိပက္ခ' },
  story_development: { en: '5. Detailed Story Development', my: '၅။ ဇာတ်လမ်းအသေးစိတ် တိုးတက်မှု' },
  important_dialogue: { en: '6. Important Character Dialogues', my: '၆။ အရေးပါသော စကားပြောခန်းများ' },
  twists_reveals: { en: '7. Twists and Reveals', my: '၇။ အလှည့်အပြောင်းနှင့် ဖော်ထုတ်ချက်များ' },
  climax: { en: '8. Climax', my: '၈။ အထွတ်အထိပ် အခန်း' },
  full_ending: { en: '9. Full Ending and Resolution', my: '၉။ ဇာတ်သိမ်းအပြည့်အစုံ' },
};

export function assignRecapStoryStages(beats: RecapBeat[]): RecapStoryStage[] {
  const count = beats.length;
  return beats.map((b, idx) => {
    if (b.storyStage) return b.storyStage;
    if (count <= 1 || idx === count - 1) return 'full_ending';
    if (idx === 0) return 'opening_hook';
    if (count === 2) return 'full_ending';
    const ratio = idx / (count - 1);
    if (ratio < 0.14) return 'story_background';
    if (ratio < 0.25) return 'character_intro';
    if (ratio < 0.38) return 'main_conflict';
    if (ratio < 0.56) return 'story_development';
    if (ratio < 0.7) return 'important_dialogue';
    if (ratio < 0.84) return 'twists_reveals';
    return 'climax';
  });
}

/**
 * Builds the upgraded MIXED (Professional Narration + Important Character Dialogues)
 * DETAILED + FULL ENDING Movie Recap prompt with preserved transcript timestamps,
 * scene-locked IDs/timecodes, TARGET_WORDS (never MAX_WORDS), AI Voice-Synced per-scene
 * video speed matching, character identity consistency rules, and anti-hallucination guards.
 */
export function buildRecapMixedNarrationPrompt(input: RecapMixedPromptInput): {
  systemInstruction: string;
  prompt: string;
  targetDurationSeconds: number;
} {
  const targetDurationSeconds = computeRecapTargetDurationSeconds(input.durationSeconds);

  const sceneContextText =
    Array.isArray(input.scenes) && input.scenes.length > 0
      ? input.scenes
          .slice(0, 28)
          .map((sc, i) => {
            const sceneTag = sc.sceneId || `scene_${i + 1}`;
            const windowStr =
              typeof sc.startTime === 'number' && typeof sc.endTime === 'number'
                ? `${formatClock(sc.startTime)} -> ${formatClock(sc.endTime)}`
                : formatClock(Number(sc.timestamp || 0));
            const charTag =
              Array.isArray(sc.characters) && sc.characters.length > 0
                ? ` | characters: ${sc.characters.join(', ')}`
                : '';
            const actTag =
              Array.isArray(sc.actions) && sc.actions.length > 0
                ? ` | actions: ${sc.actions.join(', ')}`
                : '';
            const dlgTag = sc.dialogueRef ? ` | dialogueRef: "${sc.dialogueRef}"` : '';
            return `- [${sceneTag} | ${windowStr}] ${String(sc.storyEvent || sc.descriptionMy || '').trim()}${charTag}${actTag}${dlgTag}`;
          })
          .join('\n')
      : '';

  const timestampedTranscript =
    Array.isArray(input.timestampedSegments) && input.timestampedSegments.length > 0
      ? formatTimestampedTranscriptContext(input.timestampedSegments, input.durationSeconds)
      : '';

  const verifiedCharacters =
    Array.isArray(input.verifiedCharacters) && input.verifiedCharacters.length > 0
      ? input.verifiedCharacters
      : extractVerifiedCharacterClues({
          transcript: input.transcript,
          timestampedSegments: input.timestampedSegments,
          scenes: input.scenes,
          storyAnalysisMy: input.storyAnalysisMy,
        });
  const characterRegistry =
    Array.isArray(input.characterRegistry) && input.characterRegistry.length > 0
      ? input.characterRegistry
      : buildCharacterRegistry({
          transcript: input.transcript,
          timestampedSegments: input.timestampedSegments,
          scenes: input.scenes,
          storyAnalysisMy: input.storyAnalysisMy,
        });
  const characterRosterBlock = formatCharacterRegistryPromptBlock(characterRegistry, verifiedCharacters);

  const systemInstruction =
    'You are an expert Myanmar Movie Recap writer and dramatic storyteller. Write a DETAILED, FULL-ENDING MIXED recap targeting ~90% of the source video duration (guided by TARGET_WORDS per beat) blending natural conversational spoken Burmese narration with important original character dialogues. Follow the source video chronologically through all 9 narrative stages (Opening Hook, Story Background, Character Introduction, Main Conflict, Detailed Story Development, Important Character Dialogues, Twists & Reveals, Climax, and Full Ending & Resolution). Each scene beat is strictly paired to its visual scene so the exported video adjusts each scene speed dynamically to match your Burmese AI voiceover cleanly (AI Voice-Synced, NOT 1.0x locked). Use the Character Registry strictly: whenever a character has a verified REAL FULL NAME (from dialogue, subtitles, or credits), ALWAYS use their consistent original name or natural Burmese transliteration; when a real name is unknown, use an evidence-backed contextual designation ("ဆိုင်ရှင်", "စားသောက်ဆိုင်ပိုင်ရှင်", "မန်နေဂျာ", "ရဲအရာရှိ", "ဆရာဝန်", "အမျိုးသားဝန်ထမ်း", "သူ့ရဲ့အဖော်") or clear visual description ("အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား"). NEVER output robotic placeholder labels like "Man 1", "Man 2", "Woman 1", "Person A", "Person B", "အမျိုးသား (၁)", or "အမျိုးသား (၂)", never invent unverified names or relationships, and never output labels like "Narration:" or "Dialogue:".';

  const prompt = `Write a NEW FULL DETAILED Myanmar movie recap narration covering the ${input.durationSeconds.toFixed(2)}s video chronologically from Opening Hook to Climax and Full Ending & Resolution.
Configuration: Recap Style = DETAILED | Ending Style = FULL ENDING | Target Narration Depth = ~${targetDurationSeconds.toFixed(2)} seconds (~90% of ${input.durationSeconds.toFixed(2)}s guide, Video Speed = AI Voice-Synced per scene) | Story Expansion = AUTO EXPAND | Language = Natural Spoken Burmese | Important Character Dialogues = ENABLED.
Selected Voice Persona Style: ${input.voiceStyleName} (${input.voiceStyleTag}) — ${input.voiceStyleDesc}
${timestampedTranscript ? `\nTimestamped Original Audio Transcript Segments:\n${timestampedTranscript}\n` : input.transcript ? `\nOriginal Audio Transcript Context:\n"${input.transcript}"\n` : ''}
${characterRosterBlock ? `\n${characterRosterBlock}\n` : ''}
${input.storyAnalysisMy ? `\nChronological Story Overview:\n${input.storyAnalysisMy}\n` : ''}
${sceneContextText ? `\nVerified Chronological Scene Breakdown:\n${sceneContextText}\n` : ''}
${input.speedNote}

## DETAILED 9-STAGE STORYTELLING ARCHITECTURE (FULL ENDING REQUIRED)
Cover the movie chronologically across these 9 narrative stages (matching each beat's assigned stage and scene window):
1. Opening Hook — hook viewers immediately with the opening tension/situation from the earliest scene.
2. Story Background — establish the setting, context, and situation shown in the video.
3. Character Introduction — introduce key characters clearly with their COMPLETE FULL NAMES, titles, contextual roles, or clear visual descriptions.
4. Main Conflict — explain what triggered the central problem or confrontation.
5. Detailed Story Development — follow cause-and-effect events step by step without skipping middle scenes.
6. Important Character Dialogues — weave meaningful spoken lines directly into the story flow.
7. Twists and Reveals — clearly explain surprising turns, betrayals, secrets, or discoveries.
8. Climax — build dramatic tension naturally through the peak confrontation.
9. Full Ending and Resolution — explain the COMPLETE ending and final outcome truthfully (NEVER stop on a vague cliffhanger or cut the resolution short).

## MOVIE RECAP – MIXED NARRATION & NATURAL CHARACTER DIALOGUE INTEGRATION RULES
1. STYLE = MIXED (Professional Storytelling Narration + Important Original Character Dialogues):
   - Combine vivid natural spoken Burmese storytelling, character reactions, emotions, motivations, and smooth transitions WITH important spoken character conversations.
   - Do NOT flatten the movie into a dry narration-only summary that skips meaningful conversations.
2. PRIORITIZE PLOT-MOVING CHARACTER DIALOGUE WHEN PRESENT IN THE TRANSCRIPT:
   - Important questions and answers.
   - Arguments, conflicts, and confrontations.
   - Threats and warnings.
   - Emotional conversations and turning points.
   - Confessions, revelations, promises, and critical character decisions.
   - Funny or memorable lines.
3. NATURAL CONVERSATIONAL BURMESE FORMAT:
   - Use natural, engaging spoken Burmese (avoid robotic literal translation or stiff bureaucratic phrasing).
   - Connect each character's actions, dialogue, emotions, and story events smoothly without repetitive generic labels or unnecessary pronouns.
   - Rewrite translated character lines into natural, expressive spoken Burmese inside quotes (e.g., '...').
   - Weave narration and quoted dialogue smoothly into ONE continuous spoken script (NO "Narration:" / "Dialogue:" labels, NO stage tags, NO separate track).
   - Never copy or reuse phrasing from prompt instructions — adapt ONLY real events and lines from this video's transcript and scenes.
4. CHARACTER IDENTITY AND NATURAL NAMING SYSTEM (CHARACTER NAME & IDENTITY CONSISTENCY):
   - USE REAL CHARACTER NAMES WHEN AVAILABLE: Analyze dialogue, subtitles, on-screen credits, and scene context to use each character's verified COMPLETE FULL NAME or natural Burmese transliteration consistently across the entire recap.
   - WHEN THE REAL NAME IS UNKNOWN: Identify the character using an accurate contextual designation supported by the actual movie context (e.g., "ဆိုင်ရှင်", "စားသောက်ဆိုင်ပိုင်ရှင်", "မန်နေဂျာ", "ရဲအရာရှိ", "ဆရာဝန်", "အမျိုးသားဝန်ထမ်း", "အဓိကဇာတ်ကောင်", "သူ့ရဲ့အဖော်") or a clear consistent visual description (e.g., "အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား").
   - STRICTLY FORBIDDEN GENERIC DETECTION LABELS: NEVER write "Man 1", "Man 2", "Woman 1", "Person A", "Person B", "အမျိုးသား (၁)", "အမျိုးသား (၂)", "အမျိုးသမီး (၁)", or any numbered/lettered temporary labels anywhere in the Burmese narration.
   - STRICT IDENTITY CONSISTENCY: Never randomly rename a character, never assign one character's name to another person, do not confuse characters who look similar, and strictly NEVER invent or guess character names, occupations, or family relationships without evidence.
5. STRICT ANTI-HALLUCINATION RULE:
   - Strictly DO NOT invent or fabricate character dialogue that does not exist in the transcript.
   - If dialogue transcription is missing or unclear for a scene, write a faithful description of the observable scene and character reactions instead.
6. SCENE-TO-VOICE CONTENT PARITY & TARGET_WORDS (AI VOICE-SYNCED VIDEO):
   - Each video scene dynamically adapts its playback speed to match its Burmese AI voice duration, so whatever the AI voice narrates in each beat MUST directly describe ONLY what happens in that exact scene's visuals and transcript window!
   - NEVER put events from another scene into the wrong beat — keeping exact visual-to-voice alignment ensures the spoken narration and on-screen action always match seamlessly.
   - Treat TARGET_WORDS as a balanced storytelling depth guideline (~${targetDurationSeconds.toFixed(2)}s total guide, NOT a restrictive cap). Avoid artificially empty 2-word beats or extreme rambling that slows a short clip excessively.
   - Character dialogues count directly toward this single narration duration.
7. CHRONOLOGICAL CONTINUITY:
   - Match transcript timestamps accurately to their scenes and preserve strict start-to-finish chronological order without repeating events across beats.

Story Beats Covering Full Video:
${input.beatListText}

Requirements:
1. "segments": Array with EXACTLY ${input.beatCount} items matching each input beat id in order. Each item MUST have: id (string matching input id), myanmarText (clean natural spoken Burmese blending storytelling narration + quoted character dialogue matching ONLY that scene's events with consistent Character Registry names/contextual designations, ZERO "Man 1"/"Person A"/"အမျိုးသား (၁)" labels, and NO "Narration:"/"Dialogue:" prefixes), emoji (1 matching emoji like 🔥, 😱, 🎬, 💬).
2. "thumbnailTitleMy": A viral Myanmar thumbnail title STRICTLY under 25 characters (maximum 24 characters).`;

  return { systemInstruction, prompt, targetDurationSeconds };
}

/**
 * Determines whether the initial Movie Recap script is significantly under the 90% target
 * AND selects ONLY the underfilled beats that have genuine source transcript/scene evidence
 * to expand chronologically without fabricating or duplicating content.
 */
export function selectRecapBeatsForAutoExpansion(params: {
  beats: RecapBeat[];
  segments: RecapGeneratedSegment[];
  videoDurationSeconds: number;
  voiceSpeed: VoiceSpeed;
  timestampedSegments?: TimestampedTranscriptItem[];
  scenes?: SceneSummary[];
  transcript?: string;
  storyAnalysisMy?: string;
}): {
  shouldExpand: boolean;
  estimate: RecapDurationEstimate;
  candidates: RecapExpansionCandidate[];
} {
  const {
    beats,
    segments,
    videoDurationSeconds,
    voiceSpeed,
    timestampedSegments = [],
    scenes = [],
    transcript = '',
    storyAnalysisMy = '',
  } = params;

  const estimate = estimateRecapNarrationCoverage(
    beats,
    segments,
    videoDurationSeconds,
    voiceSpeed
  );

  // Never fabricate content when there is neither transcript nor visual scene evidence
  const hasEvidence =
    hasSubstantiveTranscript(transcript, timestampedSegments) ||
    scenes.some((s) => String(s.descriptionMy || '').trim().length >= 8) ||
    String(storyAnalysisMy || '').trim().length >= 16;

  if (!hasEvidence || beats.length === 0) {
    return { shouldExpand: false, estimate, candidates: [] };
  }

  // Trigger expansion only when meaningfully short of the 90% target
  const deficitSeconds = estimate.targetDurationSeconds - estimate.estimatedDurationSeconds;
  const isUnderTarget =
    estimate.coverageRatio < 0.78 ||
    (estimate.targetDurationSeconds >= 12 && deficitSeconds >= 3.0);

  if (!isUnderTarget) {
    return { shouldExpand: false, estimate, candidates: [] };
  }

  const segById = new Map(segments.map((s) => [s.id, s]));
  const candidates: RecapExpansionCandidate[] = [];

  for (let i = 0; i < beats.length; i++) {
    const beat = beats[i];
    const perEst = estimate.perSegment[i];
    if (!perEst || perEst.fillRatio >= 0.85) continue;

    const matchingTranscriptLines = timestampedSegments
      .filter((t) => t.end > beat.start - 0.5 && t.start < beat.end + 0.5 && String(t.text || '').trim())
      .map((t) => `[${formatClock(t.start)} -> ${formatClock(t.end)}] "${t.text.trim()}"`);

    const matchingSceneNotes = scenes
      .filter((sc) => sc.timestamp >= beat.start - 1.0 && sc.timestamp <= beat.end + 1.0 && String(sc.descriptionMy || '').trim())
      .map((sc) => `[${formatClock(sc.timestamp)}] ${sc.descriptionMy.trim()}`);

    const beatHasContext =
      matchingTranscriptLines.length > 0 ||
      matchingSceneNotes.length > 0 ||
      hasSubstantiveTranscript(beat.contextText);

    if (!beatHasContext) continue;

    candidates.push({
      beat,
      currentText: segById.get(beat.id)?.myanmarText || segments[i]?.myanmarText || '',
      currentEmoji: segById.get(beat.id)?.emoji || segments[i]?.emoji || '🎬',
      estimatedSeconds: perEst.estimatedSeconds,
      targetSeconds: perEst.targetSeconds,
      matchingTranscriptLines,
      matchingSceneNotes,
      previousBeatText: i > 0 ? segById.get(beats[i - 1].id)?.myanmarText || segments[i - 1]?.myanmarText || '' : '',
      nextBeatText: i + 1 < beats.length ? segById.get(beats[i + 1].id)?.myanmarText || segments[i + 1]?.myanmarText || '' : '',
    });
  }

  return {
    shouldExpand: candidates.length > 0,
    estimate,
    candidates,
  };
}

/**
 * Builds a targeted Gemini prompt that expands ONLY underfilled beats using missed story explanations
 * and unincluded transcript dialogues, preserving neighboring beats without duplication or fabrication.
 */
export function buildRecapAutoExpansionPrompt(params: {
  durationSeconds: number;
  targetDurationSeconds: number;
  currentEstimatedSeconds: number;
  candidates: RecapExpansionCandidate[];
  storyAnalysisMy?: string;
  verifiedCharacters?: VerifiedCharacterProfile[];
  characterRegistry?: CharacterRegistryEntry[];
}): { systemInstruction: string; prompt: string } {
  const {
    durationSeconds,
    targetDurationSeconds,
    currentEstimatedSeconds,
    candidates,
    storyAnalysisMy = '',
    verifiedCharacters = [],
    characterRegistry = [],
  } = params;

  const characterRosterBlock = formatCharacterRegistryPromptBlock(characterRegistry, verifiedCharacters);

  const candidateBlock = candidates
    .map((c) => {
      const lines = [
        `### Beat id="${c.beat.id}" [${c.beat.start.toFixed(2)}s -> ${c.beat.end.toFixed(2)}s]`,
        `Current Est Duration: ${c.estimatedSeconds.toFixed(2)}s | Target: ~${c.targetSeconds.toFixed(2)}s (TARGET_WORDS=${c.beat.maxMyanmarWords})`,
        `Current Myanmar Draft: "${c.currentText}"`,
      ];
      if (c.previousBeatText) {
        lines.push(`Previous Beat (DO NOT repeat its content): "${c.previousBeatText}"`);
      }
      if (c.nextBeatText) {
        lines.push(`Next Beat (DO NOT repeat its content): "${c.nextBeatText}"`);
      }
      if (c.matchingTranscriptLines.length > 0) {
        lines.push(`Source Transcript in This Window:\n${c.matchingTranscriptLines.join('\n')}`);
      } else if (c.beat.contextText) {
        lines.push(`Beat Source Context: "${c.beat.contextText}"`);
      }
      if (c.matchingSceneNotes.length > 0) {
        lines.push(`Visual Scene Evidence:\n${c.matchingSceneNotes.join('\n')}`);
      }
      return lines.join('\n');
    })
    .join('\n\n');

  const systemInstruction =
    'You are refining an under-length Myanmar Movie Recap script to reach ~90% of the source video duration. Expand ONLY the listed underfilled beats by integrating missed story context, character reactions, and important transcript dialogues that were omitted. Maintain strict chronological order and use each character\'s verified COMPLETE FULL NAME or natural Burmese transliteration (or contextual/visual designation like "ဆိုင်ရှင်", "မန်နေဂျာ", "အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား" if unnamed) consistently. NEVER write "Man 1", "Man 2", "Woman 1", "Person A", or "အမျိုးသား (၁)", never duplicate adjacent beats, never invent dialogue or character identities, and output clean spoken Burmese.';

  const prompt = `The initial Myanmar Movie Recap draft for a ${durationSeconds.toFixed(2)}s video currently estimates ${currentEstimatedSeconds.toFixed(2)}s vs the ~${targetDurationSeconds.toFixed(2)}s (90%) target.

Expand ONLY the ${candidates.length} underfilled beat(s) listed below so each reaches close to its TARGET_WORDS and target beat seconds naturally:
${characterRosterBlock ? `\n${characterRosterBlock}\n` : ''}
${storyAnalysisMy ? `\nStory Context:\n${storyAnalysisMy}\n` : ''}
${candidateBlock}

Strict Rules:
1. Return "segments" containing ONLY the exact ${candidates.length} beat id(s) listed above in chronological order.
2. Add missing story explanations, character motivations/reactions, and any important unincluded transcript dialogue (in conversational Burmese quotes '...').
3. Maintain strict Character Identity & Natural Naming: ALWAYS use the verified COMPLETE FULL NAME/contextual designation instead of truncated names, generic pronouns, or temporary labels ("Man 1", "Person A", "အမျိုးသား (၁)"). Never invent unverified names or relationships.
4. NEVER repeat or paraphrase lines already covered in Previous Beat or Next Beat.
5. NEVER fabricate dialogue if no transcript speech exists in that beat's window — expand only with observable scene details and story continuity.
6. Keep output clean spoken Burmese (NO "Narration:", NO "Dialogue:", NO markdown).`;

  return { systemInstruction, prompt };
}

export interface CharacterConsistencyAudit {
  knownNames: string[];
  usedKnownNames: string[];
  missedKnownNames: string[];
  missedFullNames: string[];
  bannedLabelHits: string[];
  bannedLabelBeatIds: string[];
  missedRegistryDesignations: string[];
  genericPronounCount: number;
  pronounHeavyBeatIds: string[];
  needsConsistencyPass: boolean;
}

const GENERIC_BURMESE_PRONOUN_RE = /(?:^|[\s'"“”‘’])(သူတို့|သူမ|အဲဒီလူ|အဲ့ဒီလူ|ထိုသူ|အဲဒီကောင်လေး|အဲ့ဒီကောင်လေး|အဲဒီကောင်မလေး|အဲ့ဒီကောင်မလေး|ကောင်လေး|ကောင်မလေး|သူက|သူ့ကို|သူ့အား|သူ့|သူ)(?=[\s'"“”‘’။,.!?ကကိုမှာကနေတွင်နဲ့နှင့်မှလည်းပဲ]|$)/g;

/**
 * Audits a generated Movie Recap script for character identity consistency, full names,
 * contextual designations, and banned generic detection labels ("Man 1", "Person A", "အမျိုးသား (၁)").
 */
export function auditRecapCharacterConsistency(
  segments: RecapGeneratedSegment[],
  verifiedCharacters: VerifiedCharacterProfile[],
  characterRegistry: CharacterRegistryEntry[] = []
): CharacterConsistencyAudit {
  const knownNames = verifiedCharacters.map((c) => c.canonicalName).filter(Boolean);
  const fullText = segments.map((s) => String(s.myanmarText || '')).join(' ');
  const fullLower = fullText.toLowerCase();

  const usedKnownNames: string[] = [];
  const missedKnownNames: string[] = [];
  const missedFullNames: string[] = [];

  for (const profile of verifiedCharacters) {
    const canonLower = profile.canonicalName.toLowerCase();
    const hasExactFull = Boolean(canonLower && fullLower.includes(canonLower));
    const regMatch = characterRegistry.find(
      (r) => r.verifiedOriginalName?.toLowerCase() === canonLower
    );
    const terms = [
      profile.canonicalName,
      ...profile.aliases,
      ...(regMatch ? [regMatch.burmeseName, ...regMatch.aliases] : []),
    ].filter(Boolean);
    const matchedAny = terms.some((t) => fullLower.includes(t.toLowerCase()));
    if (matchedAny) {
      usedKnownNames.push(profile.canonicalName);
    } else {
      missedKnownNames.push(profile.canonicalName);
    }
    const isMultiPartFullName =
      profile.canonicalName.trim().split(/\s+/).length >= 2 || profile.aliases.length > 0;
    const hasBurmeseTranslit = Boolean(regMatch?.burmeseName && fullLower.includes(regMatch.burmeseName.toLowerCase()));
    if (isMultiPartFullName && !hasExactFull && !hasBurmeseTranslit) {
      missedFullNames.push(profile.canonicalName);
    }
  }

  const bannedLabelHitsAll: string[] = [];
  const bannedLabelSeen = new Set<string>();
  const bannedLabelBeatIds: string[] = [];
  let genericPronounCount = 0;
  const pronounHeavyBeatIds: string[] = [];

  const allRecognizedTerms = [
    ...verifiedCharacters.flatMap((p) => [p.canonicalName, ...p.aliases]),
    ...characterRegistry.flatMap((r) => [
      r.verifiedOriginalName || '',
      r.burmeseName,
      ...r.aliases,
      r.verifiedOccupationOrTitle || '',
      r.visualDescription || '',
    ]),
  ]
    .map((t) => String(t || '').trim())
    .filter((t) => t.length >= 2 && !isSingleBareGenericNoun(t));

  for (const seg of segments) {
    const txt = String(seg.myanmarText || '');
    const beatBanned = findBannedGenericCharacterLabels(txt);
    if (beatBanned.length > 0) {
      bannedLabelBeatIds.push(seg.id);
      for (const hit of beatBanned) {
        if (!bannedLabelSeen.has(hit.toLowerCase())) {
          bannedLabelSeen.add(hit.toLowerCase());
          bannedLabelHitsAll.push(hit);
        }
      }
    }

    const pronounMatches = txt.match(GENERIC_BURMESE_PRONOUN_RE);
    const countInBeat = pronounMatches ? pronounMatches.length : 0;
    genericPronounCount += countInBeat;

    const beatLower = txt.toLowerCase();
    const mentionsAnyKnown = allRecognizedTerms.some((term) => beatLower.includes(term.toLowerCase()));
    if (countInBeat >= 2 && !mentionsAnyKnown) {
      pronounHeavyBeatIds.push(seg.id);
    }
  }

  const missedRegistryDesignations: string[] = [];
  for (const entry of characterRegistry) {
    if (entry.verifiedOriginalName) continue; // already tracked above
    const entryTerms = [
      entry.burmeseName,
      ...entry.aliases,
      entry.verifiedOccupationOrTitle || '',
      entry.visualDescription || '',
    ].filter((t) => t && !isSingleBareGenericNoun(t));
    if (entryTerms.length > 0 && !entryTerms.some((t) => fullLower.includes(t.toLowerCase()))) {
      missedRegistryDesignations.push(entry.burmeseName);
    }
  }

  const hasAnyRegistryContext = verifiedCharacters.length > 0 || characterRegistry.length > 0;
  const needsConsistencyPass =
    bannedLabelHitsAll.length > 0 ||
    (hasAnyRegistryContext &&
      (missedKnownNames.length > 0 ||
        missedFullNames.length > 0 ||
        missedRegistryDesignations.length > 0 ||
        pronounHeavyBeatIds.length >= Math.max(2, Math.ceil(segments.length * 0.4))));

  return {
    knownNames,
    usedKnownNames,
    missedKnownNames,
    missedFullNames,
    bannedLabelHits: bannedLabelHitsAll,
    bannedLabelBeatIds,
    missedRegistryDesignations,
    genericPronounCount,
    pronounHeavyBeatIds,
    needsConsistencyPass,
  };
}

/**
 * Builds a pre-final verification & refinement prompt to make COMPLETE character names, nicknames,
 * contextual designations, relationships, professional ranks, and natural Burmese storytelling consistent
 * throughout the recap while eliminating temporary detection labels ("Man 1", "Person A", "အမျိုးသား (၁)").
 */
export function buildRecapCharacterConsistencyPrompt(params: {
  beats: RecapBeat[];
  segments: RecapGeneratedSegment[];
  verifiedCharacters: VerifiedCharacterProfile[];
  characterRegistry?: CharacterRegistryEntry[];
  audit: CharacterConsistencyAudit;
  timestampedSegments?: TimestampedTranscriptItem[];
  scenes?: SceneSummary[];
}): { systemInstruction: string; prompt: string } {
  const {
    beats,
    segments,
    verifiedCharacters,
    characterRegistry = [],
    audit,
    timestampedSegments = [],
    scenes = [],
  } = params;

  const rosterBlock = formatCharacterRegistryPromptBlock(characterRegistry, verifiedCharacters);
  const beatSummary = segments
    .map((seg, idx) => {
      const b = beats[idx];
      const windowLabel = b ? `[${b.start.toFixed(2)}s -> ${b.end.toFixed(2)}s]` : '';
      return `- Beat id="${seg.id}" ${windowLabel}: "${seg.myanmarText}"`;
    })
    .join('\n');

  const transcriptLines = formatTimestampedTranscriptContext(timestampedSegments, 3600, 60);
  const sceneNotes = scenes
    .slice(0, 16)
    .map((sc) => {
      const charInfo = Array.isArray(sc.characters) && sc.characters.length > 0 ? ` [${sc.characters.join(', ')}]` : '';
      return `- [${formatClock(Number(sc.timestamp || 0))}]${charInfo} ${String(sc.descriptionMy || '').trim()}`;
    })
    .join('\n');

  const systemInstruction =
    'You are performing a pre-final Character Identity & Natural Burmese Naming refinement pass on a Myanmar Movie Recap script. Preserve every scene event, chronological order, quoted character dialogue, and overall ~90% narration length. Eliminate ALL temporary detection labels ("Man 1", "Man 2", "Woman 1", "Person A", "Person B", "အမျိုးသား (၁)", "အမျိုးသား (၂)", "အမျိုးသမီး (၁)") and repetitive generic pronouns ("သူ", "သူမ", "သူတို့", "အဲဒီလူ"). Replace them with verified COMPLETE FULL NAMES / natural Burmese transliterations from the Character Registry, OR accurate evidence-backed contextual designations ("ဆိုင်ရှင်", "မန်နေဂျာ", "ရဲအရာရှိ", "ဆရာဝန်", "အမျိုးသားဝန်ထမ်း", "အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား", "သူ့ရဲ့အဖော်") using smooth natural Burmese sentence structures.';

  const prompt = `Review and refine this Myanmar Movie Recap draft ONLY for Character Identity, Natural Burmese Naming, and Consistency before final delivery.

${rosterBlock || '(No named characters verified — use accurate contextual occupations, relationships, or clear visual descriptions from scenes below, and NEVER write "Man 1", "Woman 1", "Person A", or "အမျိုးသား (၁)")'}
${audit.bannedLabelHits.length > 0 ? `\nCRITICAL — Banned generic detection labels found in draft (MUST REPLACE ALL OF THEM naturally): ${audit.bannedLabelHits.join(', ')} (in beats: ${audit.bannedLabelBeatIds.join(', ')})` : ''}
${audit.missedFullNames.length > 0 ? `\nFULL names missing or truncated to partial names in draft (MUST use COMPLETE FULL NAME): ${audit.missedFullNames.join(', ')}` : ''}
${audit.missedKnownNames.length > 0 ? `\nVerified characters completely missing in draft: ${audit.missedKnownNames.join(', ')}` : ''}
${audit.missedRegistryDesignations.length > 0 ? `\nContextual/visual character designations from Character Registry missing in draft: ${audit.missedRegistryDesignations.join(', ')}` : ''}
${audit.pronounHeavyBeatIds.length > 0 ? `\nBeats relying heavily on generic pronouns/nouns: ${audit.pronounHeavyBeatIds.join(', ')}` : ''}
${transcriptLines ? `\nSource Transcript Reference:\n${transcriptLines}\n` : ''}
${sceneNotes ? `\nSource Scene Reference:\n${sceneNotes}\n` : ''}
Current Draft Beats (${segments.length} beats):
${beatSummary}

Natural Naming & Consistency Rules:
1. Whenever a character's REAL FULL NAME, Burmese transliteration, nickname, title, rank, honorific, or relationship is verified in the Character Registry/transcript/scenes, ALWAYS write that exact verified name consistently.
2. When a character's real name is unknown, ALWAYS use an appropriate evidence-backed contextual designation ("ဆိုင်ရှင်", "စားသောက်ဆိုင်ပိုင်ရှင်", "မန်နေဂျာ", "ရဲအရာရှိ", "ဆရာဝန်", "အမျိုးသားဝန်ထမ်း", "အဓိကဇာတ်ကောင်", "သူ့ရဲ့အဖော်") or clear visual description ("အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား").
3. STRICTLY FORBIDDEN: Never output "Man 1", "Man 2", "Woman 1", "Person A", "Person B", "အမျိုးသား (၁)", "အမျိုးသား ၂", or similar temporary labels. Rewrite stiff sentences naturally in conversational spoken Burmese connecting actions, dialogue, and emotions smoothly.
4. Keep character identities 100% consistent across all beats — never swap names, confuse similar-looking people, or invent unverified family relations or occupations.
5. Preserve existing plot points, chronological order, quoted conversational dialogues, and approximate length per beat.
6. Return "segments" with EXACTLY ${segments.length} items matching each input beat id in order (with myanmarText and emoji).`;

  return { systemInstruction, prompt };
}

function normalizeClauseForDedup(clause: string): string {
  return cleanRecapSpokenText(clause)
    .replace(/[\s'"“”‘’။,.!?…\-:;()]/g, '')
    .toLowerCase();
}

/**
 * Validates and cleans final recap segments before returning from /api/generate-script:
 * - Preserves exact beat order & IDs
 * - Strips structural label leaks ("Narration:", "Dialogue:")
 * - Removes duplicated clauses/dialogue lines across beats
 * - Ensures every beat has non-empty spoken Burmese fallback
 */
export function validateAndRefineRecapSegments(params: {
  beats: RecapBeat[];
  rawSegments: Array<{ id?: string; myanmarText?: string; emoji?: string }>;
  videoDurationSeconds: number;
  voiceSpeed: VoiceSpeed;
}): RecapValidationResult {
  const { beats, rawSegments, videoDurationSeconds, voiceSpeed } = params;
  const byId = new Map<string, { myanmarText?: string; emoji?: string }>();
  for (const seg of rawSegments) {
    if (seg?.id) {
      byId.set(String(seg.id), seg);
    }
  }

  const seenClauses = new Set<string>();
  let removedDuplicateCount = 0;
  let dialogueLineCount = 0;
  const warnings: string[] = [];

  const refined: RecapGeneratedSegment[] = beats.map((beat, idx) => {
    const candidate = byId.get(beat.id) || rawSegments[idx];
    const cleaned = cleanRecapSpokenText(candidate?.myanmarText || '');
    const emoji = String(candidate?.emoji || '🎬').trim() || '🎬';

    // Split on Burmese/Latin sentence boundaries while keeping delimiters
    const rawClauses = cleaned
      .split(/(?<=[။!?])\s+/)
      .map((s) => s.trim())
      .filter(Boolean);

    const keptClauses: string[] = [];
    for (const clause of rawClauses) {
      const key = normalizeClauseForDedup(clause);
      if (key.length >= 10 && seenClauses.has(key)) {
        removedDuplicateCount += 1;
        continue;
      }
      if (key.length >= 10) {
        seenClauses.add(key);
      }
      keptClauses.push(clause);
    }

    let finalText = keptClauses.join(' ').trim();
    if (!finalText) {
      finalText = cleaned || String(beat.contextText || '').trim();
      if (cleaned) {
        warnings.push(`Beat ${beat.id} fell back after duplicate filtering`);
      } else {
        warnings.push(`Beat ${beat.id} was empty and used context fallback`);
      }
    }

    if (/['"“”‘’][^'"“”‘’]{2,}['"“”‘’]/.test(finalText)) {
      dialogueLineCount += 1;
    }

    return {
      id: beat.id,
      myanmarText: finalText,
      emoji,
    };
  });

  const estimate = estimateRecapNarrationCoverage(
    beats,
    refined,
    videoDurationSeconds,
    voiceSpeed
  );

  if (estimate.coverageRatio < 0.72) {
    warnings.push(
      `Estimated narration duration (${estimate.estimatedDurationSeconds}s) is below 72% of 90% target (${estimate.targetDurationSeconds}s)`
    );
  }

  return {
    segments: refined,
    estimatedDurationSeconds: estimate.estimatedDurationSeconds,
    targetDurationSeconds: estimate.targetDurationSeconds,
    coverageRatio: estimate.coverageRatio,
    dialogueLineCount,
    removedDuplicateCount,
    warnings,
  };
}

export interface RecapActualDurationAdjustTarget {
  beat: RecapBeat;
  mode: 'expand' | 'tighten';
  currentText: string;
  currentEmoji: string;
  actualTtsSeconds: number;
  targetTtsSeconds: number;
  maxWindowSeconds: number;
  matchingTranscriptLines: string[];
  matchingSceneNotes: string[];
  previousBeatText: string;
  nextBeatText: string;
}

/**
 * Builds an actual-TTS-duration-driven refinement prompt (used AFTER measuring real TTS WAV lengths):
 * expands genuinely underfilled beats with real missed story explanations/dialogue, and tightens
 * overly long monologue beats so scene speed synchronization stays natural and closely matches visuals.
 */
export function buildRecapDurationAdjustmentPrompt(params: {
  durationSeconds: number;
  actualTotalTtsSeconds: number;
  targetTotalTtsSeconds: number;
  targets: RecapActualDurationAdjustTarget[];
  storyAnalysisMy?: string;
  verifiedCharacters?: VerifiedCharacterProfile[];
  characterRegistry?: CharacterRegistryEntry[];
}): { systemInstruction: string; prompt: string } {
  const {
    durationSeconds,
    actualTotalTtsSeconds,
    targetTotalTtsSeconds,
    targets,
    storyAnalysisMy = '',
    verifiedCharacters = [],
    characterRegistry = [],
  } = params;

  const characterRosterBlock = formatCharacterRegistryPromptBlock(characterRegistry, verifiedCharacters);

  const targetBlocks = targets
    .map((t) => {
      const actionLabel =
        t.mode === 'expand'
          ? `EXPAND (~${t.actualTtsSeconds.toFixed(2)}s measured -> aim ~${t.targetTtsSeconds.toFixed(2)}s for ${t.maxWindowSeconds.toFixed(2)}s scene)`
          : `TIGHTEN CONCISELY (~${t.actualTtsSeconds.toFixed(2)}s measured is much longer than ${t.maxWindowSeconds.toFixed(2)}s scene -> aim ~${(t.maxWindowSeconds * 1.4).toFixed(2)}s so scene slow-down stays smooth)`;

      const lines = [
        `### Beat id="${t.beat.id}" (${t.beat.sceneId || 'scene'}) [${t.beat.start.toFixed(2)}s -> ${t.beat.end.toFixed(2)}s] — ${actionLabel}`,
        `Current Draft: "${t.currentText}"`,
      ];
      if (t.previousBeatText) {
        lines.push(`Previous Beat (DO NOT repeat): "${t.previousBeatText}"`);
      }
      if (t.nextBeatText) {
        lines.push(`Next Beat (DO NOT repeat): "${t.nextBeatText}"`);
      }
      if (t.matchingTranscriptLines.length > 0) {
        lines.push(`Source Transcript:\n${t.matchingTranscriptLines.join('\n')}`);
      } else if (t.beat.contextText) {
        lines.push(`Scene Context: "${t.beat.contextText}"`);
      }
      if (t.matchingSceneNotes.length > 0) {
        lines.push(`Visual Scene Notes:\n${t.matchingSceneNotes.join('\n')}`);
      }
      return lines.join('\n');
    })
    .join('\n\n');

  const systemInstruction =
    'You are refining specific Myanmar Movie Recap beats based on ACTUAL measured TTS audio durations so each scene stays naturally aligned with its AI voice narration (video playback speed adapts dynamically per scene to match the AI voice). For EXPAND beats, add real missed story explanations, character motivations/reactions, and unincluded transcript dialogues matching that exact visual scene without repetition or filler. For TIGHTEN beats, rewrite crisply in natural spoken Burmese keeping core plot events, verified Character Registry FULL NAMES or contextual/visual designations ("ဆိုင်ရှင်", "မန်နေဂျာ", "အညိုရောင်ဝတ်စုံနဲ့ အမျိုးသား"), and crucial dialogue quotes. NEVER write "Man 1", "Person A", or "အမျိုးသား (၁)", never shorten full character names, and never invent unverified dialogue or names.';

  const prompt = `Measured AI voice total for this ${durationSeconds.toFixed(2)}s video is currently ${actualTotalTtsSeconds.toFixed(2)}s (90% depth guide = ${targetTotalTtsSeconds.toFixed(2)}s; video speed adapts per scene to match AI voice).

Adjust ONLY the ${targets.length} beat(s) listed below:
${characterRosterBlock ? `\n${characterRosterBlock}\n` : ''}
${storyAnalysisMy ? `\nChronological Story Context:\n${storyAnalysisMy}\n` : ''}
${targetBlocks}

Requirements:
1. Return "segments" containing ONLY the exact ${targets.length} beat id(s) listed above in chronological order (with id, myanmarText, emoji).
2. Zero fabricated dialogue, zero invented character names, zero "Man 1"/"Person A"/"အမျိုးသား (၁)" detection labels, zero repeated lines from adjacent beats, and keep every beat strictly describing its own visual scene.
3. Preserve natural spoken conversational Burmese with COMPLETE FULL CHARACTER NAMES or evidence-backed contextual designations and clean quotes '...' for dialogue.`;

  return { systemInstruction, prompt };
}

/**
 * Distributes a manually edited single-string Myanmar recap script proportionally across
 * scene-anchored beats so per-beat scene windows remain intact even after manual textarea edits.
 */
export function distributeEditedScriptAcrossBeats(
  scriptText: string,
  beats: RecapBeat[],
  existingSegments: RecapGeneratedSegment[] = []
): RecapGeneratedSegment[] {
  const cleaned = cleanRecapSpokenText(scriptText);
  if (beats.length === 0) return [];
  if (!cleaned) {
    return beats.map((b, idx) => ({
      id: b.id,
      myanmarText: existingSegments[idx]?.myanmarText || b.contextText || '',
      emoji: existingSegments[idx]?.emoji || '🎬',
    }));
  }

  const sentences = cleaned
    .split(/(?<=[။!?])\s*/)
    .map((s) => s.trim())
    .filter(Boolean);

  if (sentences.length <= 1 || sentences.length < beats.length) {
    // Split on clause spaces/commas if fewer sentences than beats, or assign sequentially
    const tokens =
      sentences.length >= beats.length
        ? sentences
        : cleaned.split(/\s+/).filter(Boolean);

    if (tokens.length <= beats.length) {
      return beats.map((b, idx) => ({
        id: b.id,
        myanmarText: idx < tokens.length ? tokens[idx] : existingSegments[idx]?.myanmarText || '',
        emoji: existingSegments[idx]?.emoji || '🎬',
      }));
    }

    const totalWeight = beats.reduce((s, b) => s + Math.max(0.5, b.duration), 0);
    let tokenIdx = 0;
    return beats.map((b, idx) => {
      const share = Math.max(1, Math.round((Math.max(0.5, b.duration) / totalWeight) * tokens.length));
      const endIdx = idx === beats.length - 1 ? tokens.length : Math.min(tokens.length, tokenIdx + share);
      const slice = tokens.slice(tokenIdx, Math.max(tokenIdx, endIdx)).join(' ').trim();
      tokenIdx = endIdx;
      return {
        id: b.id,
        myanmarText: slice || existingSegments[idx]?.myanmarText || '',
        emoji: existingSegments[idx]?.emoji || '🎬',
      };
    });
  }

  // Group sentences cleanly by beat duration proportions
  const totalDur = beats.reduce((s, b) => s + Math.max(0.5, b.duration), 0);
  const totalSentenceChars = sentences.reduce((s, line) => s + Math.max(4, line.length), 0);
  const out: RecapGeneratedSegment[] = [];
  let sIdx = 0;
  let accumDur = 0;

  for (let i = 0; i < beats.length; i++) {
    const b = beats[i];
    accumDur += Math.max(0.5, b.duration);
    const targetCumulativeChars = (accumDur / totalDur) * totalSentenceChars;
    const collected: string[] = [];

    if (i === beats.length - 1) {
      while (sIdx < sentences.length) {
        collected.push(sentences[sIdx++]);
      }
    } else {
      let runningChars = sentences.slice(0, sIdx).reduce((sum, l) => sum + Math.max(4, l.length), 0);
      while (sIdx < sentences.length) {
        const remainingBeats = beats.length - 1 - i;
        const remainingSentences = sentences.length - sIdx;
        if (remainingSentences <= remainingBeats && collected.length >= 1) break;
        collected.push(sentences[sIdx]);
        runningChars += Math.max(4, sentences[sIdx].length);
        sIdx += 1;
        if (runningChars >= targetCumulativeChars && collected.length >= 1) break;
      }
    }

    out.push({
      id: b.id,
      myanmarText: collected.join(' ').trim() || existingSegments[i]?.myanmarText || '',
      emoji: existingSegments[i]?.emoji || '🎬',
    });
  }

  return out;
}

/**
 * Extracts quoted character dialogue phrases from mixed Burmese narration+dialogue text.
 */
export function extractQuotedDialogueSegment(text: string): string | undefined {
  const matches = String(text || '').match(/['"“”‘’]([^'"“”‘’]{2,})['"“”‘’]/g);
  if (!matches || matches.length === 0) return undefined;
  return matches.join(' ').trim();
}

export const STRICT_RECAP_SCENE_MATCH_THRESHOLD = 0.6;

interface CharacterMatchEntry {
  canonicalName: string;
  aliases: string[];
}

function escapeRegexLiteral(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function textExplicitlyMentionsTerm(text: string, term: string): boolean {
  const cleanText = String(text || '');
  const cleanTerm = String(term || '').trim();
  if (!cleanText || cleanTerm.length < 2) return false;

  if (BURMESE_CHAR_TEST_RE.test(cleanTerm)) {
    return cleanText.toLowerCase().includes(cleanTerm.toLowerCase());
  }

  const pattern = new RegExp(`(?:^|[^\\p{L}\\p{N}])${escapeRegexLiteral(cleanTerm)}(?:$|[^\\p{L}\\p{N}])`, 'iu');
  return pattern.test(cleanText);
}

function buildCharacterMatchDictionary(
  verifiedCharacters: VerifiedCharacterProfile[],
  scenes: SceneSummary[],
  beats: RecapBeat[],
  characterRegistry: CharacterRegistryEntry[] = []
): { entries: CharacterMatchEntry[]; aliasToCanonical: Map<string, string> } {
  const merged = new Map<string, CharacterMatchEntry>();

  const upsert = (canonical: string, aliases: string[] = []) => {
    const cleanCanon = cleanRawCharacterString(canonical);
    if (!cleanCanon || isBannedGenericCharacterLabel(cleanCanon)) return;
    const key = cleanCanon.toLowerCase();
    const existing = merged.get(key);
    if (existing) {
      for (const al of aliases) {
        const cleanAl = cleanRawCharacterString(al);
        if (
          cleanAl &&
          !isBannedGenericCharacterLabel(cleanAl) &&
          cleanAl.toLowerCase() !== key &&
          !existing.aliases.some((x) => x.toLowerCase() === cleanAl.toLowerCase())
        ) {
          existing.aliases.push(cleanAl);
        }
      }
      return;
    }
    merged.set(key, {
      canonicalName: cleanCanon,
      aliases: aliases
        .map((a) => cleanRawCharacterString(a))
        .filter((a) => a && !isBannedGenericCharacterLabel(a) && a.toLowerCase() !== key),
    });
  };

  for (const profile of verifiedCharacters) {
    upsert(profile.canonicalName, profile.aliases || []);
  }
  for (const reg of characterRegistry) {
    const canon = reg.verifiedOriginalName || reg.burmeseName;
    const extra = [
      ...(reg.burmeseName && reg.burmeseName !== canon ? [reg.burmeseName] : []),
      ...(reg.aliases || []),
      ...(reg.visualDescription && reg.visualDescription !== canon ? [reg.visualDescription] : []),
    ];
    upsert(canon, extra);
  }
  for (const sc of scenes) {
    for (const ch of sc.characters || []) {
      upsert(String(ch || ''));
    }
  }
  for (const b of beats) {
    for (const ch of b.characters || []) {
      upsert(String(ch || ''));
    }
  }

  const aliasToCanonical = new Map<string, string>();
  const ambiguousAliases = new Set<string>();

  for (const entry of merged.values()) {
    aliasToCanonical.set(entry.canonicalName.toLowerCase(), entry.canonicalName);
    for (const al of entry.aliases) {
      const alLower = al.toLowerCase();
      const prev = aliasToCanonical.get(alLower);
      if (prev && prev !== entry.canonicalName) {
        ambiguousAliases.add(alLower);
        aliasToCanonical.delete(alLower);
      } else if (!ambiguousAliases.has(alLower)) {
        aliasToCanonical.set(alLower, entry.canonicalName);
      }
    }
  }

  return { entries: [...merged.values()], aliasToCanonical };
}

function extractNarrationCharacters(
  text: string,
  dict: { entries: CharacterMatchEntry[]; aliasToCanonical: Map<string, string> }
): string[] {
  const cleanText = String(text || '').trim();
  if (!cleanText || dict.entries.length === 0) return [];

  const found: string[] = [];
  const seen = new Set<string>();

  for (const entry of dict.entries) {
    if (textExplicitlyMentionsTerm(cleanText, entry.canonicalName)) {
      const key = entry.canonicalName.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        found.push(entry.canonicalName);
      }
      continue;
    }

    const matchedSafeAlias = entry.aliases.some((al) => {
      const resolved = dict.aliasToCanonical.get(al.toLowerCase());
      return resolved === entry.canonicalName && textExplicitlyMentionsTerm(cleanText, al);
    });
    if (matchedSafeAlias) {
      const key = entry.canonicalName.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        found.push(entry.canonicalName);
      }
    }
  }

  return found;
}

function getSceneVisualCharacters(
  scene: SceneSummary,
  dict: { entries: CharacterMatchEntry[]; aliasToCanonical: Map<string, string> }
): string[] {
  const rawChars = Array.isArray(scene.characters)
    ? scene.characters.map((c) => cleanRawCharacterString(String(c || ''))).filter(Boolean)
    : [];

  if (rawChars.length > 0) {
    const normalized: string[] = [];
    const seen = new Set<string>();
    for (const ch of rawChars) {
      const resolved = dict.aliasToCanonical.get(ch.toLowerCase()) || ch;
      const key = resolved.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        normalized.push(resolved);
      }
    }
    return normalized;
  }

  // Fallback ONLY when structured scene.characters is absent: check visual description/storyEvent (never off-screen dialogueRef)
  const visualText = [scene.descriptionMy, scene.storyEvent].filter(Boolean).join(' ').trim();
  return extractNarrationCharacters(visualText, dict);
}

interface ScoredSceneCandidate {
  scene: SceneSummary;
  visualChars: string[];
  matchedChars: string[];
  coverage: number;
  precision: number;
  confidence: number;
  isSameSceneId: boolean;
  overlapDur: number;
  isTemporalMatch: boolean;
  temporalDist: number;
}

/**
 * Selects scenes for a narration beat using a strict character visual-presence threshold:
 * when the narration audio references specific character(s), scenes where those character(s)
 * are NOT visually present are strictly filtered out and prioritized behind/replaced by scenes
 * where they ARE visually present.
 */
function selectStrictScenesForBeat(params: {
  beat: RecapBeat;
  narrationText: string;
  scenes: SceneSummary[];
  dict: { entries: CharacterMatchEntry[]; aliasToCanonical: Map<string, string> };
  strictThreshold: number;
}): {
  selectedScenes: SceneSummary[];
  narrationChars: string[];
  characterRefs: string[];
  sceneMatchConfidence: number;
  sceneMatchMode: NonNullable<RecapSceneMapping['sceneMatchMode']>;
} {
  const { beat, narrationText, scenes, dict, strictThreshold } = params;
  const narrationChars = extractNarrationCharacters(narrationText, dict);
  const beatStart = Number(beat.start || 0);
  const beatEnd = Math.max(beatStart + 0.1, Number(beat.end || beatStart + 1));
  const beatSpan = Math.max(0.5, beatEnd - beatStart);
  const beatMid = (beatStart + beatEnd) / 2;
  const beatSceneIds = beat.sceneId ? new Set(beat.sceneId.split('+').map((s) => s.trim()).filter(Boolean)) : new Set<string>();

  if (scenes.length === 0) {
    return {
      selectedScenes: [],
      narrationChars,
      characterRefs: [...new Set([...(beat.characters || []), ...narrationChars])],
      sceneMatchConfidence: 0,
      sceneMatchMode: narrationChars.length > 0 ? 'temporal_fallback' : 'temporal_strict',
    };
  }

  const scored: ScoredSceneCandidate[] = scenes.map((sc) => {
    const scStart = typeof sc.startTime === 'number' && Number.isFinite(sc.startTime) ? sc.startTime : sc.timestamp;
    const scEnd =
      typeof sc.endTime === 'number' && Number.isFinite(sc.endTime) && sc.endTime > scStart
        ? sc.endTime
        : sc.timestamp;
    const scMid = (scStart + scEnd) / 2;

    const isSameSceneId = Boolean(sc.sceneId && beatSceneIds.has(sc.sceneId));
    const overlapDur = Math.max(0, Math.min(beatEnd, scEnd) - Math.max(beatStart, scStart));
    const pointInside = sc.timestamp >= beatStart - 0.15 && sc.timestamp <= beatEnd + 0.15;
    const isTemporalMatch = isSameSceneId || overlapDur > 0.05 || pointInside;
    const temporalDist = Math.abs(scMid - beatMid);

    const visualChars = getSceneVisualCharacters(sc, dict);
    const visualLowerSet = new Set(visualChars.map((c) => c.toLowerCase()));

    const matchedChars = narrationChars.filter((nc) => visualLowerSet.has(nc.toLowerCase()));
    const coverage = narrationChars.length > 0 ? matchedChars.length / narrationChars.length : 0;
    const precision = visualChars.length > 0 ? matchedChars.length / visualChars.length : 0;
    const temporalScore =
      overlapDur > 0.05
        ? 1.0
        : isSameSceneId
          ? 0.9
          : pointInside
            ? 0.85
            : Math.max(0, 1 - temporalDist / Math.max(12, beatSpan * 4));

    const confidence =
      narrationChars.length > 0
        ? matchedChars.length > 0
          ? Number((coverage * 0.72 + precision * 0.18 + temporalScore * 0.1).toFixed(4))
          : Number((temporalScore * 0.1).toFixed(4))
        : Number((isTemporalMatch ? 1.0 : temporalScore * 0.4).toFixed(4));

    return {
      scene: sc,
      visualChars,
      matchedChars,
      coverage,
      precision,
      confidence,
      isSameSceneId,
      overlapDur,
      isTemporalMatch,
      temporalDist,
    };
  });

  if (narrationChars.length > 0) {
    const strictCandidates = scored
      .filter((c) => c.matchedChars.length > 0 && c.confidence >= strictThreshold)
      .sort((a, b) => {
        if (b.coverage !== a.coverage) return b.coverage - a.coverage;
        if (Math.abs(b.confidence - a.confidence) > 0.03) return b.confidence - a.confidence;
        if (Number(b.isTemporalMatch) !== Number(a.isTemporalMatch)) {
          return Number(b.isTemporalMatch) - Number(a.isTemporalMatch);
        }
        if (a.temporalDist !== b.temporalDist) return a.temporalDist - b.temporalDist;
        return Number(b.isSameSceneId) - Number(a.isSameSceneId);
      });

    if (strictCandidates.length > 0) {
      const best = strictCandidates[0];
      const topTemporalSameCoverage = strictCandidates.filter(
        (c) => c.isTemporalMatch && c.coverage >= best.coverage && c.confidence >= Math.max(strictThreshold, best.confidence - 0.08)
      );
      const chosenPool =
        topTemporalSameCoverage.length > 0
          ? topTemporalSameCoverage
          : strictCandidates.filter(
              (c) =>
                c.coverage >= best.coverage &&
                c.confidence >= Math.max(strictThreshold, best.confidence - 0.08) &&
                Math.abs(c.temporalDist - best.temporalDist) <= 0.5
            );

      const finalPool = chosenPool.length > 0 ? chosenPool : [best];
      const selectedScenes = [...finalPool]
        .map((c) => c.scene)
        .sort((a, b) => a.timestamp - b.timestamp);
      const sceneVisualSet = finalPool.flatMap((c) => c.visualChars);
      const characterRefs = [...new Set([...narrationChars, ...sceneVisualSet])];

      return {
        selectedScenes,
        narrationChars,
        characterRefs,
        sceneMatchConfidence: Number(finalPool[0].confidence.toFixed(3)),
        sceneMatchMode: best.coverage >= 0.99 ? 'character_visual_strict' : 'character_partial_strict',
      };
    }

    // Check if any scene at least visually contains one narrated character (even below strict threshold)
    const partialCandidates = scored
      .filter((c) => c.matchedChars.length > 0)
      .sort((a, b) => {
        if (b.matchedChars.length !== a.matchedChars.length) return b.matchedChars.length - a.matchedChars.length;
        if (b.confidence !== a.confidence) return b.confidence - a.confidence;
        return a.temporalDist - b.temporalDist;
      });

    if (partialCandidates.length > 0) {
      const bestPartial = partialCandidates[0];
      const chosenPartial = partialCandidates.filter(
        (c) =>
          c.matchedChars.length === bestPartial.matchedChars.length &&
          c.isTemporalMatch === bestPartial.isTemporalMatch &&
          Math.abs(c.confidence - bestPartial.confidence) <= 0.06
      );
      const selectedScenes = chosenPartial.map((c) => c.scene).sort((a, b) => a.timestamp - b.timestamp);
      const characterRefs = [...new Set([...narrationChars, ...chosenPartial.flatMap((c) => c.visualChars)])];

      return {
        selectedScenes,
        narrationChars,
        characterRefs,
        sceneMatchConfidence: Number(bestPartial.confidence.toFixed(3)),
        sceneMatchMode: 'character_partial_strict',
      };
    }

    // Zero visual matches anywhere in scenes -> temporal fallback, keeping characterRefs truthful to narrationText
    const temporalFallback = scored
      .filter((c) => c.isTemporalMatch)
      .sort((a, b) => a.temporalDist - b.temporalDist);
    return {
      selectedScenes: temporalFallback.map((c) => c.scene),
      narrationChars,
      characterRefs: [...new Set(narrationChars)],
      sceneMatchConfidence: 0,
      sceneMatchMode: 'temporal_fallback',
    };
  }

  // Narration without named character references -> tight temporal match
  const temporalStrict = scored
    .filter((c) => c.isTemporalMatch)
    .sort((a, b) => a.temporalDist - b.temporalDist);
  const chosenTemporal =
    temporalStrict.length > 0
      ? temporalStrict
      : [[...scored].sort((a, b) => a.temporalDist - b.temporalDist)[0]];

  const selectedScenes = chosenTemporal.map((c) => c.scene).sort((a, b) => a.timestamp - b.timestamp);
  const sceneVisualRefs = chosenTemporal.flatMap((c) => c.visualChars);
  const characterRefs =
    sceneVisualRefs.length > 0 ? [...new Set(sceneVisualRefs)] : [...new Set(beat.characters || [])];

  return {
    selectedScenes,
    narrationChars: [],
    characterRefs,
    sceneMatchConfidence: Number((chosenTemporal[0]?.confidence ?? 0).toFixed(3)),
    sceneMatchMode: temporalStrict.length > 0 ? 'temporal_strict' : 'temporal_fallback',
  };
}

/**
 * Builds structured Scene-to-Script & TTS alignment mappings for every Movie Recap beat,
 * applying a strict character-visual-presence threshold so narration segments about specific
 * character(s) match ONLY scenes where those character(s) are visually present.
 */
export function buildRecapSceneMappings(params: {
  beats: RecapBeat[];
  segments: RecapGeneratedSegment[];
  scenes?: SceneSummary[];
  verifiedCharacters?: VerifiedCharacterProfile[];
  characterRegistry?: CharacterRegistryEntry[];
  schedule?: LockedVideoRecapScheduleResult | null;
  strictMatchThreshold?: number;
}): RecapSceneMapping[] {
  const {
    beats,
    segments,
    scenes = [],
    verifiedCharacters = [],
    characterRegistry = [],
    schedule = null,
    strictMatchThreshold = STRICT_RECAP_SCENE_MATCH_THRESHOLD,
  } = params;
  const clampedThreshold = Math.min(1.0, Math.max(0.1, Number(strictMatchThreshold) || STRICT_RECAP_SCENE_MATCH_THRESHOLD));
  const stages = assignRecapStoryStages(beats);
  const segById = new Map(segments.map((s) => [s.id, s]));
  const slotByBeatId = new Map((schedule?.slots || []).map((sl) => [sl.beatId, sl]));
  const dict = buildCharacterMatchDictionary(verifiedCharacters, scenes, beats, characterRegistry);

  return beats.map((beat, idx) => {
    const seg = segById.get(beat.id) || segments[idx];
    const slot = slotByBeatId.get(beat.id);
    const narrationText = cleanRecapSpokenText(seg?.myanmarText || '');
    const dialogueText = extractQuotedDialogueSegment(narrationText);

    const strictMatch = selectStrictScenesForBeat({
      beat,
      narrationText,
      scenes,
      dict,
      strictThreshold: clampedThreshold,
    });

    const matchingScenes = strictMatch.selectedScenes;
    const primaryScene = matchingScenes[0];

    let mappedStart = Number(beat.start.toFixed(2));
    let mappedEnd = Number(beat.end.toFixed(2));
    if (
      matchingScenes.length > 0 &&
      (strictMatch.sceneMatchMode === 'character_visual_strict' ||
        strictMatch.sceneMatchMode === 'character_partial_strict')
    ) {
      const explicitStarts = matchingScenes
        .map((sc) => sc.startTime)
        .filter((v): v is number => typeof v === 'number' && Number.isFinite(v));
      const explicitEnds = matchingScenes
        .map((sc) => sc.endTime)
        .filter((v): v is number => typeof v === 'number' && Number.isFinite(v));
      if (explicitStarts.length === matchingScenes.length && explicitEnds.length === matchingScenes.length) {
        const minStart = Number(Math.min(...explicitStarts).toFixed(2));
        const maxEnd = Number(Math.max(...explicitEnds).toFixed(2));
        if (maxEnd > minStart + 0.05) {
          mappedStart = minStart;
          mappedEnd = maxEnd;
        }
      }
    }

    const matchedSceneIds = matchingScenes.map((sc) => sc.sceneId).filter((id): id is string => Boolean(id));
    const storyEvent =
      matchingScenes.map((sc) => sc.storyEvent || sc.descriptionMy).filter(Boolean).join(' ').trim() ||
      beat.sceneDescriptionMy ||
      beat.contextText;

    return {
      beatId: beat.id,
      sceneId: primaryScene?.sceneId || beat.sceneId || `scene_${idx + 1}`,
      startTime: mappedStart,
      endTime: mappedEnd,
      storyStage: stages[idx] || 'story_development',
      characterRefs: strictMatch.characterRefs,
      storyEvent,
      narrationText,
      ...(dialogueText ? { dialogueText } : {}),
      ...(matchedSceneIds.length > 0 ? { matchedSceneIds } : {}),
      sceneMatchConfidence: strictMatch.sceneMatchConfidence,
      sceneMatchMode: strictMatch.sceneMatchMode,
      ...(slot
        ? {
            narrationStart: slot.actualStart,
            narrationEnd: slot.actualEnd,
            actualTtsDuration: slot.fittedDuration,
            targetTtsDuration: slot.targetBeatDuration,
            tempoApplied: slot.tempoRatio,
            videoPlaybackRate: slot.videoPlaybackRate,
            setptsFactor: slot.setptsFactor,
            alignmentStatus: slot.alignmentStatus,
          }
        : {}),
    };
  });
}

const BURMESE_CHAR_RE = /[\u1000-\u109F]/g;
const LEAKED_LABEL_RE = /(?:^|\s)\*{0,2}(?:Narration|Dialogue|Voiceover|Storyteller)\s*:\*{0,2}/i;

/**
 * Mandatory Pre-Render Movie Recap Quality Validation Gate:
 * Verifies story accuracy, character consistency, natural dialogue integration, scene alignment,
 * timestamp continuity, AI voice-synced per-scene playback speed, full ending coverage,
 * and Burmese prose quality before final export.
 */
export function validateRecapQuality(params: {
  beats: RecapBeat[];
  segments: RecapGeneratedSegment[];
  mappings: RecapSceneMapping[];
  originalVideoDuration: number;
  actualTtsDuration: number; // 0 if running pre-TTS script validation
  videoPlaybackRate?: number;
  silenceCutApplied?: boolean;
  verifiedCharacters?: VerifiedCharacterProfile[];
  characterRegistry?: CharacterRegistryEntry[];
  timestampedSegments?: TimestampedTranscriptItem[];
  hasTtsAudio?: boolean;
}): RecapQualityValidation {
  const {
    beats,
    segments,
    mappings,
    originalVideoDuration,
    actualTtsDuration,
    videoPlaybackRate = 1.0,
    silenceCutApplied = false,
    verifiedCharacters = [],
    characterRegistry = [],
    timestampedSegments = [],
    hasTtsAudio = actualTtsDuration > 0,
  } = params;

  const safeVideoDur = Math.max(1, Number.isFinite(originalVideoDuration) ? originalVideoDuration : 12);
  const targetRecapDuration = computeRecapTargetDurationSeconds(safeVideoDur);
  const measuredOrEst = hasTtsAudio
    ? Math.max(0, actualTtsDuration)
    : estimateRecapNarrationCoverage(beats, segments, safeVideoDur, 'normal').estimatedDurationSeconds;
  const durationDiffSeconds = Number((measuredOrEst - targetRecapDuration).toFixed(2));
  const coverageRatio =
    targetRecapDuration > 0 ? Number((measuredOrEst / targetRecapDuration).toFixed(3)) : 1;

  const checks: RecapQualityCheckItem[] = [];
  const fullText = segments.map((s) => String(s.myanmarText || '').trim()).join(' ').trim();

  // 1. Dynamic Scene-Voice Video Sync (Adapts playback speed cleanly per scene to match AI voice without dropping scenes)
  const validPlaybackRange =
    Number.isFinite(videoPlaybackRate) && videoPlaybackRate >= 0.15 && videoPlaybackRate <= 6.5;
  const speedSyncOk = validPlaybackRange && !silenceCutApplied && mappings.length > 0;
  checks.push({
    key: 'video_speed_lock',
    passed: speedSyncOk,
    severity: speedSyncOk ? 'pass' : 'critical',
    messageMy: speedSyncOk
      ? `AI အသံအရှည်နှင့် Scene တစ်ခုချင်းစီ၏ ဗီဒီယိုအမြန်နှုန်းကို တိကျစွာ ချိန်ညှိထားပါသည် (Playback: ${videoPlaybackRate.toFixed(2)}x)`
      : silenceCutApplied
        ? 'Movie Recap တွင် Silence Cut မသုံးရပါ — Scene တိုင်းကို AI အသံနှင့် တိုက်ရိုက်ချိန်ညှိရပါမည်'
        : `AI အသံနှင့် ဗီဒီယိုအမြန်နှုန်း ချိန်ညှိမှု မမှန်ကန်ပါ (Playback: ${videoPlaybackRate}x)`,
  });

  // 2. Story Accuracy & Coverage
  const nonEmptyBeats = segments.filter((s) => String(s.myanmarText || '').trim().length >= 6).length;
  const storyAccuracyOk = beats.length > 0 && nonEmptyBeats === beats.length;
  checks.push({
    key: 'story_accuracy',
    passed: storyAccuracyOk,
    severity: storyAccuracyOk ? 'pass' : nonEmptyBeats === 0 ? 'critical' : 'warning',
    messageMy: storyAccuracyOk
      ? `ဇာတ်လမ်းအပိုင်း (${nonEmptyBeats}/${beats.length}) စလုံး ပြည့်စုံစွာ ပါဝင်ပါသည်`
      : `ဇာတ်လမ်းအပိုင်း (${beats.length - nonEmptyBeats}) ခု စာသားလိုအပ်နေပါသည်`,
  });

  // 3. Character Identity & Natural Naming Consistency (verifying real names / contextual designations & forbidding Man 1 / အမျိုးသား (၁))
  const charAudit = auditRecapCharacterConsistency(segments, verifiedCharacters, characterRegistry);
  const hasBannedLabels = charAudit.bannedLabelHits.length > 0;
  const hasRegistryOrNames = verifiedCharacters.length > 0 || characterRegistry.length > 0;
  const charOk = !hasBannedLabels && (!hasRegistryOrNames || !charAudit.needsConsistencyPass);
  const charIssueNames = [
    ...new Set([
      ...charAudit.missedKnownNames,
      ...charAudit.missedFullNames,
      ...charAudit.missedRegistryDesignations,
    ]),
  ];
  const displayRosterNames = [
    ...new Set([
      ...charAudit.usedKnownNames,
      ...characterRegistry.map((r) => r.burmeseName).filter(Boolean),
    ]),
  ];
  checks.push({
    key: 'character_consistency',
    passed: charOk,
    severity: charOk ? 'pass' : 'warning',
    messageMy: hasBannedLabels
      ? `ယာယီဇာတ်ကောင် Label များ (${charAudit.bannedLabelHits.join(', ')}) ပါဝင်နေပါသည် — သဘာဝကျသော အမည် သို့မဟုတ် အခန်းကဏ္ဍသို့ ပြောင်းလဲသင့်ပါသည်`
      : !hasRegistryOrNames
        ? 'ဇာတ်ကောင်နာမည်အထောက်အထား မပါသဖြင့် မြင်တွေ့ရသော အခန်းကဏ္ဍအတိုင်း ရေးသားထားပါသည်'
        : charOk
          ? `ဇာတ်ကောင်နာမည်နှင့် အခန်းကဏ္ဍ (${displayRosterNames.slice(0, 5).join(', ')}) တစ်သမတ်တည်း ကိုက်ညီပါသည်`
          : `ဇာတ်ကောင်အမည်/အခန်းကဏ္ဍ (${charIssueNames.join(', ') || 'pronoun-heavy beats'}) ထည့်သွင်းသုံးစွဲရန် သတိပြုပါ`,
  });

  // 4. Dialogue Integration
  const hasSpokenTranscript = hasSubstantiveTranscript(
    timestampedSegments.map((t) => t.text).join(' '),
    timestampedSegments
  );
  const quotedCount = segments.filter((s) => /['"“”‘’][^'"“”‘’]{2,}['"“”‘’]/.test(s.myanmarText || '')).length;
  const dialogueOk = !hasSpokenTranscript || quotedCount >= 1;
  checks.push({
    key: 'dialogue_integration',
    passed: dialogueOk,
    severity: dialogueOk ? 'pass' : 'warning',
    messageMy: !hasSpokenTranscript
      ? 'မူရင်းအသံစကားပြော မပါသဖြင့် မြင်ကွင်းအမှန်အတိုင်း ပြန်လည်ပြောပြထားပါသည်'
      : dialogueOk
        ? `အရေးပါသော ဇာတ်ကောင်စကားပြော (${quotedCount} နေရာ) သဘာဝကျစွာ ထည့်သွင်းထားပါသည်`
        : 'မူရင်းစကားပြော ပါဝင်သော်လည်း တိုက်ရိုက်စကားပြောကိုးကားချက် နည်းပါးနေပါသည်',
  });

  // 5. Scene Alignment
  const overflowCount = mappings.filter((m) => m.alignmentStatus === 'overflow_warning').length;
  const missingAudioCount = mappings.filter((m) => m.alignmentStatus === 'missing_audio').length;
  const sceneAlignOk = missingAudioCount === 0 && overflowCount <= Math.max(1, Math.floor(mappings.length * 0.25));
  checks.push({
    key: 'scene_alignment',
    passed: sceneAlignOk,
    severity: missingAudioCount > 0 ? 'critical' : sceneAlignOk ? 'pass' : 'warning',
    messageMy:
      missingAudioCount > 0
        ? `Scene (${missingAudioCount}) ခုတွင် TTS အသံဖိုင် ပျောက်ဆုံးနေပါသည်`
        : overflowCount === 0
          ? `Scene (${mappings.length}) ခုလုံး AI အသံနှင့် ဗီဒီယိုမြင်ကွင်း တိကျစွာ ကိုက်ညီပါသည်`
          : `Scene (${overflowCount}) ခုတွင် စကားပြောရှည်နေ၍ အမြန်နှုန်းချိန်ညှိပေးထားပါသည်`,
  });

  // 6. Timestamp Continuity (original scenes within [0 .. safeVideoDur]; narration output monotonic across adapted timeline)
  let continuityValid = mappings.length > 0;
  let prevNarEnd = -0.01;
  const maxVoiceTimelineDur = Math.max(
    safeVideoDur * 6.0,
    hasTtsAudio ? actualTtsDuration + 5.0 : safeVideoDur * 6.0
  );
  for (const m of mappings) {
    if (m.endTime <= m.startTime || m.startTime < 0 || m.endTime > safeVideoDur + 0.15) {
      continuityValid = false;
      break;
    }
    if (typeof m.narrationStart === 'number' && typeof m.narrationEnd === 'number') {
      if (
        m.narrationStart < prevNarEnd - 0.02 ||
        m.narrationEnd < m.narrationStart ||
        m.narrationEnd > maxVoiceTimelineDur + 0.5
      ) {
        continuityValid = false;
        break;
      }
      prevNarEnd = m.narrationEnd;
    }
  }
  checks.push({
    key: 'timestamp_continuity',
    passed: continuityValid,
    severity: continuityValid ? 'pass' : 'critical',
    messageMy: continuityValid
      ? 'Timestamp အစီအစဉ်နှင့် Scene အချိန်ဆက်စပ်မှု မှန်ကန်ပါသည်'
      : 'Timestamp အစီအစဉ် ထပ်နေခြင်း သို့မဟုတ် Scene အပိုင်းအခြား မှားယွင်းနေပါသည်',
  });

  // 7. Actual TTS Duration & Pacing Depth vs 90% guide
  const durationAcceptable = !hasTtsAudio || (coverageRatio >= 0.45 && coverageRatio <= 1.85);
  const durationCriticallyBroken = hasTtsAudio && (actualTtsDuration <= 0.3 || coverageRatio < 0.15);
  checks.push({
    key: 'tts_duration_target',
    passed: durationAcceptable && !durationCriticallyBroken,
    severity: durationCriticallyBroken ? 'critical' : durationAcceptable ? 'pass' : 'warning',
    messageMy: hasTtsAudio
      ? `AI အသံအရှည် ${measuredOrEst.toFixed(1)}s (လမ်းညွှန် 90% = ${targetRecapDuration.toFixed(1)}s · ဗီဒီယိုအမြန်နှုန်း ${videoPlaybackRate.toFixed(2)}x)`
      : `ခန့်မှန်းစကားပြောအရှည် ${measuredOrEst.toFixed(1)}s (လမ်းညွှန် 90% = ${targetRecapDuration.toFixed(1)}s)`,
  });

  // 8. Full Ending Coverage
  const lastBeat = beats[beats.length - 1];
  const lastSeg = segments[segments.length - 1];
  const lastMapping = mappings[mappings.length - 1];
  const fullEndingCovered = Boolean(
    lastBeat &&
      lastSeg &&
      String(lastSeg.myanmarText || '').trim().length >= 8 &&
      (!lastMapping || lastMapping.storyStage === 'full_ending') &&
      lastBeat.end >= safeVideoDur - 1.0
  );
  checks.push({
    key: 'full_ending',
    passed: fullEndingCovered,
    severity: fullEndingCovered ? 'pass' : 'warning',
    messageMy: fullEndingCovered
      ? 'ဇာတ်လမ်းနောက်ဆုံးအခန်းနှင့် Full Ending အပြည့်အစုံ ပါဝင်ပါသည်'
      : 'ဇာတ်သိမ်းပိုင်း (Full Ending) စာသား တိုနေသဖြင့် ထပ်မံစစ်ဆေးပါ',
  });

  // 9. Burmese Language Quality
  const burmeseCount = (fullText.match(BURMESE_CHAR_RE) || []).length;
  const hasLeaks = LEAKED_LABEL_RE.test(fullText);
  const burmeseQualityOk = burmeseCount >= Math.max(8, segments.length * 4) && !hasLeaks;
  checks.push({
    key: 'burmese_quality',
    passed: burmeseQualityOk,
    severity: burmeseCount === 0 ? 'critical' : burmeseQualityOk ? 'pass' : 'warning',
    messageMy: burmeseQualityOk
      ? 'သဘာဝကျသော မြန်မာစကားပြော Recap စတိုင် မှန်ကန်ပါသည်'
      : hasLeaks
        ? 'စာသားထဲတွင် Narration/Dialogue label များ ကျန်ရှိနေပါသည်'
        : 'မြန်မာစကားလုံး ပါဝင်မှု နည်းပါးနေပါသည်',
  });

  const criticalErrors = checks.filter((c) => c.severity === 'critical').map((c) => c.messageMy);
  const warnings = checks.filter((c) => c.severity === 'warning').map((c) => c.messageMy);

  let score = 100;
  for (const c of checks) {
    if (c.severity === 'critical') score -= 30;
    else if (c.severity === 'warning') score -= 8;
  }
  score = Math.max(0, Math.min(100, score));

  const canRender = criticalErrors.length === 0;
  const passed = canRender && warnings.length === 0;

  return {
    passed,
    canRender,
    score,
    originalVideoDuration: Number(safeVideoDur.toFixed(2)),
    targetRecapDuration,
    actualTtsDuration: Number(measuredOrEst.toFixed(2)),
    durationDiffSeconds,
    coverageRatio,
    videoSpeedLocked: Number(videoPlaybackRate.toFixed(2)),
    fullEndingCovered,
    checks,
    warnings,
    criticalErrors,
  };
}

