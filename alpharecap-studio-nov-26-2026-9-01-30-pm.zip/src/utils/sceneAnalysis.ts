import type { CharacterRegistryEntry, SceneAnalysisProvider, SceneCharacterHint, SceneSummary } from '../types/studio';
import {
  buildCharacterRegistry,
  buildRecapMixedNarrationPrompt,
  computeRecapTargetDurationSeconds,
  extractVerifiedCharacterClues,
  isBannedGenericCharacterLabel,
  type RecapMixedPromptInput,
} from './recapScript';
import { extractErrorText, isModelNotFoundError, isQuotaRateLimitError, isTransientNetworkError } from './retry';

export const GROQ_VISION_MAX_IMAGES_PER_REQUEST = 3;

export const PROVIDER_STATUS_MY = {
  geminiActive: 'Gemini API အသုံးပြုနေသည်',
  geminiDone: 'Gemini API ဖြင့် ဇာတ်လမ်းစစ်ဆေးပြီးစီးပါပြီ',
  switchingToGroq: 'Groq AI သို့ အလိုအလျောက် ပြောင်းလဲနေသည်',
  groqDone: 'Groq AI ဖြင့် ဇာတ်လမ်းစစ်ဆေးပြီးစီးပါပြီ',
  bothUnavailable:
    'Gemini API နှင့် Groq AI နှစ်ခုလုံး ခေတ္တအသုံးပြု၍မရပါ — ပြီးစီးထားသော Scene များကို သိမ်းဆည်းထားပြီး ခေတ္တစောင့်၍ ပြန်စစ်ဆေးနိုင်ပါသည်',
} as const;

export interface ExtractedFrameMeta {
  index: number;
  timestamp: number;
  imageUrl: string;
  jpgPath: string;
  ppmBytes?: Uint8Array | null;
}

export interface SceneAnalysisCheckpoint {
  videoSignature: string;
  frames: Array<{ index: number; timestamp: number; imageUrl: string; filename: string }>;
  completedScenes: SceneSummary[];
  storyAnalysisMy: string;
  characterRegistry?: CharacterRegistryEntry[];
  activeProvider: SceneAnalysisProvider;
  fallbackUsed: boolean;
  groqVisionModel: string | null;
  status: 'in_progress' | 'completed' | 'error';
  lastErrorMy?: string;
  updatedAt: number;
}

/**
 * Computes evenly spaced representative timestamps across the full video [0.25s .. duration - 0.25s],
 * avoiding 0.00s fade-in black frames while covering beginning, middle, and ending chronologically.
 */
export function computeRepresentativeFrameTimestamps(
  durationSeconds: number,
  options?: { minFrames?: number; maxFrames?: number; intervalSeconds?: number }
): number[] {
  const safeDur = Number.isFinite(durationSeconds) && durationSeconds > 0 ? durationSeconds : 12;
  const minFrames = Math.max(2, options?.minFrames ?? 4);
  const maxFrames = Math.max(minFrames, options?.maxFrames ?? 20);
  const interval = Math.max(1.2, options?.intervalSeconds ?? 2.5);

  const count = Math.min(maxFrames, Math.max(minFrames, Math.round(safeDur / interval)));
  if (safeDur <= 1.2) {
    return [Number((safeDur * 0.25).toFixed(2)), Number((safeDur * 0.75).toFixed(2))];
  }

  const startPad = Math.min(0.4, safeDur * 0.04);
  const endPad = Math.min(0.4, safeDur * 0.04);
  const span = Math.max(0.4, safeDur - startPad - endPad);

  const timestamps: number[] = [];
  for (let i = 0; i < count; i++) {
    const ratio = count === 1 ? 0.5 : i / (count - 1);
    const ts = Number((startPad + ratio * span).toFixed(2));
    if (timestamps.length === 0 || ts > timestamps[timestamps.length - 1] + 0.05) {
      timestamps.push(ts);
    }
  }
  return timestamps;
}

function parsePpmPixelOffset(bytes: Uint8Array): { offset: number; width: number; height: number } | null {
  if (bytes.length < 16 || bytes[0] !== 0x50 || bytes[1] !== 0x36) return null; // P6 binary PPM
  let idx = 2;
  const tokens: string[] = [];
  while (idx < bytes.length && tokens.length < 3) {
    while (idx < bytes.length && (bytes[idx] === 0x20 || bytes[idx] === 0x0a || bytes[idx] === 0x0d || bytes[idx] === 0x09)) {
      idx++;
    }
    if (idx < bytes.length && bytes[idx] === 0x23) {
      while (idx < bytes.length && bytes[idx] !== 0x0a) idx++;
      continue;
    }
    let tok = '';
    while (
      idx < bytes.length &&
      bytes[idx] !== 0x20 &&
      bytes[idx] !== 0x0a &&
      bytes[idx] !== 0x0d &&
      bytes[idx] !== 0x09
    ) {
      tok += String.fromCharCode(bytes[idx]);
      idx++;
    }
    if (tok) tokens.push(tok);
  }
  if (tokens.length < 3) return null;
  const width = Number(tokens[0]);
  const height = Number(tokens[1]);
  const maxVal = Number(tokens[2]);
  if (!Number.isFinite(width) || !Number.isFinite(height) || maxVal <= 0) return null;
  if (idx < bytes.length) idx++; // skip single whitespace byte after maxVal
  return { offset: idx, width, height };
}

/**
 * Computes normalized mean absolute difference (0..1) between two P6 PPM frames.
 */
export function computePpmFrameDifference(ppmA: Uint8Array | null | undefined, ppmB: Uint8Array | null | undefined): number {
  if (!ppmA || !ppmB) return 1;
  const metaA = parsePpmPixelOffset(ppmA);
  const metaB = parsePpmPixelOffset(ppmB);
  if (!metaA || !metaB || metaA.width !== metaB.width || metaA.height !== metaB.height) {
    return 1;
  }

  const lenA = ppmA.length - metaA.offset;
  const lenB = ppmB.length - metaB.offset;
  const sampleBytes = Math.min(lenA, lenB);
  if (sampleBytes <= 0) return 1;

  let diffSum = 0;
  let count = 0;
  const stride = Math.max(1, Math.floor(sampleBytes / 2400));
  for (let i = 0; i < sampleBytes; i += stride) {
    diffSum += Math.abs(ppmA[metaA.offset + i] - ppmB[metaB.offset + i]);
    count++;
  }
  return count > 0 ? diffSum / (count * 255) : 1;
}

/**
 * Removes consecutive near-duplicate frames while preserving original timestamps and minimum story coverage.
 */
export function deduplicateExtractedFrames<T extends { timestamp: number; ppmBytes?: Uint8Array | null }>(
  frames: T[],
  minDiffThreshold = 0.04,
  minMinimumFrames = 3
): T[] {
  if (frames.length <= minMinimumFrames) {
    return [...frames].sort((a, b) => a.timestamp - b.timestamp);
  }

  const sorted = [...frames].sort((a, b) => a.timestamp - b.timestamp);
  const kept: T[] = [sorted[0]];

  for (let i = 1; i < sorted.length; i++) {
    const candidate = sorted[i];
    const prevKept = kept[kept.length - 1];
    const isLast = i === sorted.length - 1;
    const diff = computePpmFrameDifference(prevKept.ppmBytes, candidate.ppmBytes);
    if (diff >= minDiffThreshold || isLast) {
      // Avoid keeping identical final frame unless we're below minimum coverage
      if (isLast && diff < minDiffThreshold && kept.length >= minMinimumFrames) {
        continue;
      }
      kept.push(candidate);
    }
  }

  // If video is very static and almost all frames were skipped, ensure minimum evenly-spaced timestamps remain
  if (kept.length < Math.min(minMinimumFrames, sorted.length)) {
    const fallbackIndices = new Set<number>([0, Math.floor((sorted.length - 1) / 2), sorted.length - 1]);
    return [...fallbackIndices]
      .sort((a, b) => a - b)
      .map((idx) => sorted[idx]);
  }

  return kept;
}

/**
 * Splits extracted frames into small batches compatible with Groq vision image limits (<= 4 per request).
 */
export function partitionFramesIntoBatches<T>(
  frames: T[],
  batchSize = GROQ_VISION_MAX_IMAGES_PER_REQUEST
): T[][] {
  const safeBatchSize = Math.max(1, Math.min(GROQ_VISION_MAX_IMAGES_PER_REQUEST, Math.floor(batchSize || 3)));
  const batches: T[][] = [];
  for (let i = 0; i < frames.length; i += safeBatchSize) {
    batches.push(frames.slice(i, i + safeBatchSize));
  }
  return batches;
}

function sanitizeSceneCharacterHints(hints?: SceneCharacterHint[]): SceneCharacterHint[] {
  if (!Array.isArray(hints) || hints.length === 0) return [];
  const cleaned: SceneCharacterHint[] = [];
  for (const h of hints) {
    if (!h || typeof h !== 'object') continue;
    const rawNameOrRole = String(h.nameOrRole || '').replace(/\s+/g, ' ').trim();
    const orig = String(h.originalName || '').replace(/\s+/g, ' ').trim();
    const myName = String(h.burmeseName || '').replace(/\s+/g, ' ').trim();
    const occ = String(h.occupationOrTitle || '').replace(/\s+/g, ' ').trim();
    const rel = String(h.relationship || '').replace(/\s+/g, ' ').trim();
    const vis = String(h.visualDescription || '').replace(/\s+/g, ' ').trim();

    const safeNameOrRole = isBannedGenericCharacterLabel(rawNameOrRole)
      ? [myName, occ, vis, rel].find((v) => v && !isBannedGenericCharacterLabel(v)) || ''
      : rawNameOrRole;
    if (!safeNameOrRole && !orig && !myName && !occ && !vis) continue;

    cleaned.push({
      nameOrRole: safeNameOrRole || myName || orig || occ || vis,
      ...(orig && !isBannedGenericCharacterLabel(orig) ? { originalName: orig } : {}),
      ...(myName && !isBannedGenericCharacterLabel(myName) ? { burmeseName: myName } : {}),
      ...(Array.isArray(h.aliases) && h.aliases.length > 0
        ? { aliases: h.aliases.map((a) => String(a || '').trim()).filter((a) => a && !isBannedGenericCharacterLabel(a)) }
        : {}),
      ...(occ && !isBannedGenericCharacterLabel(occ) ? { occupationOrTitle: occ } : {}),
      ...(rel && !isBannedGenericCharacterLabel(rel) ? { relationship: rel } : {}),
      ...(vis && !isBannedGenericCharacterLabel(vis) ? { visualDescription: vis } : {}),
      ...(h.confidence ? { confidence: h.confidence } : {}),
    });
  }
  return cleaned;
}

/**
 * Merges completed scene summaries into strict chronological order by index/timestamp without duplicates.
 */
export function mergeScenesChronologically(
  existing: SceneSummary[],
  incoming: SceneSummary[]
): SceneSummary[] {
  const byIndex = new Map<number, SceneSummary>();

  const normalizeEntry = (sc: SceneSummary): SceneSummary => {
    const cleanHints = sanitizeSceneCharacterHints(sc.characterRegistryHints);
    const rawChars = Array.isArray(sc.characters)
      ? sc.characters.map((c) => String(c || '').trim()).filter(Boolean)
      : [];
    const normalizedChars: string[] = [];
    const seenChars = new Set<string>();
    for (const c of rawChars) {
      if (isBannedGenericCharacterLabel(c)) continue;
      if (!seenChars.has(c.toLowerCase())) {
        seenChars.add(c.toLowerCase());
        normalizedChars.push(c);
      }
    }
    for (const h of cleanHints) {
      const label = h.originalName || h.burmeseName || h.nameOrRole;
      if (label && !isBannedGenericCharacterLabel(label) && !seenChars.has(label.toLowerCase())) {
        seenChars.add(label.toLowerCase());
        normalizedChars.push(label);
      }
    }

    return {
      ...sc,
      timestamp: Number(Number(sc.timestamp || 0).toFixed(2)),
      descriptionMy: String(sc.descriptionMy).trim(),
      ...(sc.sceneId ? { sceneId: String(sc.sceneId).trim() } : {}),
      ...(typeof sc.startTime === 'number' && Number.isFinite(sc.startTime)
        ? { startTime: Number(Math.max(0, sc.startTime).toFixed(2)) }
        : {}),
      ...(typeof sc.endTime === 'number' && Number.isFinite(sc.endTime)
        ? { endTime: Number(Math.max(0, sc.endTime).toFixed(2)) }
        : {}),
      ...(normalizedChars.length > 0 ? { characters: normalizedChars } : {}),
      ...(cleanHints.length > 0 ? { characterRegistryHints: cleanHints } : {}),
      ...(Array.isArray(sc.actions) && sc.actions.length > 0
        ? { actions: sc.actions.map((a) => String(a || '').trim()).filter(Boolean) }
        : {}),
      ...(sc.dialogueRef ? { dialogueRef: String(sc.dialogueRef).trim() } : {}),
      ...(sc.storyEvent ? { storyEvent: String(sc.storyEvent).trim() } : {}),
    };
  };

  for (const sc of existing) {
    if (!sc || typeof sc.index !== 'number' || !String(sc.descriptionMy || '').trim()) continue;
    byIndex.set(sc.index, normalizeEntry(sc));
  }

  for (const sc of incoming) {
    if (!sc || typeof sc.index !== 'number' || !String(sc.descriptionMy || '').trim()) continue;
    byIndex.set(sc.index, normalizeEntry(sc));
  }

  return [...byIndex.values()].sort((a, b) => {
    if (a.timestamp !== b.timestamp) return a.timestamp - b.timestamp;
    return a.index - b.index;
  });
}

/**
 * Upgrades partial/short character references in scene `characters[]` lists (e.g. "Ethan", "Miller")
 * to their consolidated FULL canonical names across all scenes + transcript (e.g. "Detective Ethan Hunt"),
 * and attaches any verified full characters explicitly referenced in that scene's text/dialogue.
 */
export function resolveSceneCharacterFullNames(
  scenes: SceneSummary[],
  transcriptText = '',
  transcriptSegments: Array<{ start: number; end: number; text: string }> = []
): SceneSummary[] {
  if (!Array.isArray(scenes) || scenes.length === 0) return [];

  const roster = extractVerifiedCharacterClues({
    transcript: transcriptText,
    timestampedSegments: transcriptSegments,
    scenes,
  });

  if (roster.length === 0) return scenes;

  const aliasToFull = new Map<string, string>();
  const ambiguousLowerTerms = new Set<string>();

  for (const profile of roster) {
    const canonLower = profile.canonicalName.toLowerCase();
    aliasToFull.set(canonLower, profile.canonicalName);
    for (const al of profile.aliases) {
      const alLower = al.toLowerCase();
      if (!alLower || alLower === canonLower) continue;
      const existingTarget = aliasToFull.get(alLower);
      if (existingTarget && existingTarget !== profile.canonicalName) {
        ambiguousLowerTerms.add(alLower);
        aliasToFull.delete(alLower);
      } else if (!ambiguousLowerTerms.has(alLower)) {
        aliasToFull.set(alLower, profile.canonicalName);
      }
    }
  }

  return scenes.map((sc) => {
    const resolvedSet = new Set<string>();
    const rawChars = Array.isArray(sc.characters) ? sc.characters : [];
    for (const rawChar of rawChars) {
      const cleaned = String(rawChar || '').replace(/\s+/g, ' ').trim();
      if (!cleaned || isBannedGenericCharacterLabel(cleaned)) continue;
      const upgraded = aliasToFull.get(cleaned.toLowerCase());
      resolvedSet.add(upgraded || cleaned);
    }

    const combinedText = [sc.descriptionMy, sc.storyEvent, sc.dialogueRef]
      .filter(Boolean)
      .join(' ')
      .toLowerCase();

    if (combinedText) {
      for (const profile of roster) {
        const canonLower = profile.canonicalName.toLowerCase();
        if (combinedText.includes(canonLower)) {
          resolvedSet.add(profile.canonicalName);
          continue;
        }
        // Only infer via unambiguous alias if not already holding an unrelated fuller match
        for (const al of profile.aliases) {
          const alLower = al.toLowerCase();
          if (alLower.length >= 3 && !ambiguousLowerTerms.has(alLower)) {
            const escaped = alLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            if (new RegExp(`(?:^|[^a-z0-9])${escaped}(?:$|[^a-z0-9])`, 'i').test(combinedText)) {
              resolvedSet.add(profile.canonicalName);
              break;
            }
          }
        }
      }
    }

    const nextChars = [...resolvedSet];
    return {
      ...sc,
      ...(nextChars.length > 0 ? { characters: nextChars } : {}),
    };
  });
}

/**
 * Assigns explicit contiguous [startTime, endTime] windows and structured sceneIds across [0 .. videoDurationSeconds],
 * binding overlapping transcript dialogue lines and resolving full character names per scene without altering chronological order.
 */
export function assignChronologicalSceneWindows(
  scenes: SceneSummary[],
  videoDurationSeconds: number,
  transcriptSegments: Array<{ start: number; end: number; text: string }> = []
): SceneSummary[] {
  const safeDur = Math.max(0.5, Number.isFinite(videoDurationSeconds) ? videoDurationSeconds : 12);
  const sorted = mergeScenesChronologically([], scenes);
  if (sorted.length === 0) return [];

  const cleanTranscript = (transcriptSegments || [])
    .map((s) => ({
      start: Math.max(0, Number(s.start || 0)),
      end: Math.min(safeDur, Math.max(Number(s.start || 0), Number(s.end || safeDur))),
      text: String(s.text || '').replace(/\s+/g, ' ').trim(),
    }))
    .filter((s) => s.text.length > 0);

  const windowed = sorted.map((sc, i) => {
    const prevTs = i > 0 ? sorted[i - 1].timestamp : 0;
    const nextTs = i + 1 < sorted.length ? sorted[i + 1].timestamp : safeDur;
    const computedStart = i === 0 ? 0 : Number(((prevTs + sc.timestamp) / 2).toFixed(2));
    const computedEnd =
      i === sorted.length - 1
        ? Number(safeDur.toFixed(2))
        : Number(Math.max(computedStart + 0.2, (sc.timestamp + nextTs) / 2).toFixed(2));

    const startTime =
      typeof sc.startTime === 'number' && Number.isFinite(sc.startTime)
        ? Number(Math.max(0, Math.min(safeDur, sc.startTime)).toFixed(2))
        : computedStart;
    const endTime =
      typeof sc.endTime === 'number' && Number.isFinite(sc.endTime) && sc.endTime > startTime
        ? Number(Math.min(safeDur, sc.endTime).toFixed(2))
        : computedEnd;

    const overlappingDialogue = cleanTranscript
      .filter((t) => t.end > startTime - 0.3 && t.start < endTime + 0.3)
      .map((t) => t.text)
      .join(' ')
      .trim();

    return {
      ...sc,
      sceneId: sc.sceneId || `scene_${i + 1}`,
      startTime,
      endTime,
      storyEvent: sc.storyEvent || sc.descriptionMy,
      dialogueRef: sc.dialogueRef || (overlappingDialogue ? overlappingDialogue : undefined),
    };
  });

  const transcriptText = cleanTranscript.map((s) => s.text).join('\n');
  return resolveSceneCharacterFullNames(windowed, transcriptText, cleanTranscript);
}

/**
 * Determines the earliest batch index that still contains unanalyzed frames so resume skips completed work.
 */
export function computeResumeBatchIndex(
  frames: Array<{ index: number; timestamp: number }>,
  completedScenes: SceneSummary[],
  batchSize = GROQ_VISION_MAX_IMAGES_PER_REQUEST
): number {
  const batches = partitionFramesIntoBatches(frames, batchSize);
  const doneIndices = new Set(
    completedScenes
      .filter((s) => String(s.descriptionMy || '').trim().length > 0)
      .map((s) => s.index)
  );

  for (let b = 0; b < batches.length; b++) {
    const allDone = batches[b].every((frame) => doneIndices.has(frame.index));
    if (!allDone) return b;
  }
  return batches.length;
}

/**
 * Detects Gemini 429 RESOURCE_EXHAUSTED, daily quota exhaustion, or rate-limit errors.
 */
export function isGeminiQuotaExhaustedError(err: unknown): boolean {
  if (isQuotaRateLimitError(err)) return true;
  const text = extractErrorText(err).toLowerCase();
  return (
    text.includes('daily') && text.includes('quota') ||
    text.includes('exceeded your current quota') ||
    text.includes('generativelanguage.googleapis.com/generate_content_free_tier')
  );
}

/**
 * Selects verified Groq vision models actually present on the configured Groq account.
 * Picks qwen/qwen3.8-27b ONLY if available in availableModelIds; never calls unverified unsupported models blindly.
 */
export function selectGroqVisionModelCandidates(availableModelIds: string[]): string[] {
  const cleanAvailable = [...new Set(availableModelIds.map((m) => String(m || '').trim()).filter(Boolean))];
  if (cleanAvailable.length === 0) {
    // Only if model-listing endpoint could not be queried, try standard current Groq multimodal vision models
    return [
      'meta-llama/llama-4-scout-17b-16e-instruct',
      'meta-llama/llama-4-maverick-17b-128e-instruct',
    ];
  }

  const availableSet = new Set(cleanAvailable);
  const selected: string[] = [];
  const pushIfAvailable = (id: string) => {
    if (availableSet.has(id) && !selected.includes(id)) {
      selected.push(id);
    }
  };

  // 1. Requested Qwen vision model only if enabled on account
  pushIfAvailable('qwen/qwen3.8-27b');

  // 2. Any other Qwen vision/VL model present on account
  for (const id of cleanAvailable) {
    if (/qwen.*(?:vl|vision|3\.8)/i.test(id) && !selected.includes(id)) {
      selected.push(id);
    }
  }

  // 3. Verified Groq Llama-4 multimodal vision models (native image_url support)
  pushIfAvailable('meta-llama/llama-4-scout-17b-16e-instruct');
  pushIfAvailable('meta-llama/llama-4-maverick-17b-128e-instruct');

  // 4. Legacy or alternative Groq vision models if still active on account
  pushIfAvailable('llama-3.2-90b-vision-preview');
  pushIfAvailable('llama-3.2-11b-vision-preview');

  for (const id of cleanAvailable) {
    if (/(?:vision|llava|pixtral|multimodal)/i.test(id) && !selected.includes(id)) {
      selected.push(id);
    }
  }

  return selected;
}

export function isProviderAuthError(err: unknown): boolean {
  const text = extractErrorText(err).toLowerCase();
  return (
    text.includes('401') ||
    text.includes('403') ||
    text.includes('invalid_api_key') ||
    text.includes('invalid api key') ||
    text.includes('incorrect api key') ||
    text.includes('unauthorized') ||
    text.includes('permission_denied')
  );
}

export function classifySceneProviderError(
  provider: SceneAnalysisProvider,
  err: unknown
): { kind: 'quota' | 'auth' | 'model_unavailable' | 'transient' | 'other'; errorMy: string } {
  const label = provider === 'gemini' ? 'Gemini API' : 'Groq AI';
  if (isProviderAuthError(err)) {
    return {
      kind: 'auth',
      errorMy: `${label} API Key မှားယွင်းနေပါသည် သို့မဟုတ် သက်တမ်းကုန်နေပါသည် (401 Invalid API Key)`,
    };
  }
  if (isGeminiQuotaExhaustedError(err)) {
    return {
      kind: 'quota',
      errorMy:
        provider === 'gemini'
          ? 'Gemini API 429 Quota ပြည့်သွားပါသည် (RESOURCE_EXHAUSTED)'
          : 'Groq AI Vision Quota / Rate Limit ပြည့်သွားပါသည် — ခေတ္တစောင့်ပြီး ထပ်မံစစ်ဆေးပါ',
    };
  }
  if (isModelNotFoundError(err)) {
    return {
      kind: 'model_unavailable',
      errorMy: `${label} Vision Model ကို အကောင့်တွင် အသုံးပြု၍မရပါ`,
    };
  }
  if (isTransientNetworkError(err)) {
    return {
      kind: 'transient',
      errorMy: `${label} နှင့် ချိတ်ဆက်မှု ယာယီပြတ်တောက်သွားပါသည်`,
    };
  }
  const rawMsg = extractErrorText(err).trim();
  return {
    kind: 'other',
    errorMy: `${label} စစ်ဆေးရာတွင် အမှားဖြစ်ပွားပါသည်${rawMsg ? ` (${rawMsg.slice(0, 120)})` : ''}`,
  };
}

export function formatSceneProviderStatusMy(
  provider: SceneAnalysisProvider,
  phase: 'analyzing' | 'switching' | 'completed'
): string {
  if (phase === 'switching') return PROVIDER_STATUS_MY.switchingToGroq;
  if (phase === 'completed') {
    return provider === 'groq' ? PROVIDER_STATUS_MY.groqDone : PROVIDER_STATUS_MY.geminiDone;
  }
  return provider === 'groq' ? PROVIDER_STATUS_MY.switchingToGroq : PROVIDER_STATUS_MY.geminiActive;
}

export { buildCharacterRegistry, computeRecapTargetDurationSeconds };

export type RecapPromptInput = RecapMixedPromptInput;

/**
 * Builds the Movie Recap prompt enforcing Mixed Narration + Natural Character Dialogue Integration
 * with TARGET_WORDS pacing and the 90% target narration duration.
 */
export function buildRecapNaturalDialoguePrompt(input: RecapPromptInput): {
  systemInstruction: string;
  prompt: string;
  targetDurationSeconds: number;
} {
  return buildRecapMixedNarrationPrompt(input);
}
